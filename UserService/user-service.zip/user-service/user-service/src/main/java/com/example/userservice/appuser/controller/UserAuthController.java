package com.example.userservice.appuser.controller;

import com.example.userservice.appuser.dto.LoginRequest;
import com.example.userservice.appuser.service.AppUserService;
import com.example.userservice.registration.dto.RegistrationRequest;
import com.example.userservice.registration.service.RegistrationService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping(path = "/auth")
public class UserAuthController {

    @Autowired
    private RegistrationService registrationService;
    @Autowired
    private AppUserService appUserService;
    @Autowired
    private AuthenticationManager authenticationManager;

    @CrossOrigin
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody RegistrationRequest request) {
        try {
            Long id = registrationService.register(request);
            return ResponseEntity.status(HttpStatus.CREATED).body("User saved with id " + id + " check your email to confirm the account");

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @CrossOrigin
    // on login the user generate a new jwt token given its email
    @PostMapping("/token")
    public ResponseEntity<?> getJwtToken(@RequestBody LoginRequest request){

        Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(),request.getPassword()));
        log.info("login request: {}",request);
        if(authenticate.isAuthenticated()){
            return new ResponseEntity<>(appUserService.generateJwtToken(request.getEmail()),HttpStatus.CREATED) ;
        }else{
            return new ResponseEntity<>("invalid access",HttpStatus.BAD_REQUEST);
        }
    }

    @CrossOrigin
    @GetMapping("/validate")
    public ResponseEntity<?> validateJwtToken(@RequestParam("token") String token){

        if(appUserService.validateJwtToken(token)){
            log.info("jwt token validated");
            return new ResponseEntity<>("validated",HttpStatus.OK);
        }
        else {
            return new ResponseEntity<>("not valid",HttpStatus.BAD_REQUEST);
        }
    }

    @CrossOrigin
    @GetMapping("/extractUsernameFromJwt")
    public ResponseEntity<?> extractUsernameFromJwt(@RequestParam("token") String token){
        try {
            String usernameFromJwtToken = appUserService.extractUsernameFromJwtToken(token);
            log.info("username extracted: {}", usernameFromJwtToken);

            return new ResponseEntity<>(usernameFromJwtToken, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("cannot extract username from jwt",HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }



}
