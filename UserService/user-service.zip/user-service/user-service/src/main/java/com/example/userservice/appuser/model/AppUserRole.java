package com.example.userservice.appuser.model;

public enum AppUserRole {
    USER,
    ADMIN
}
