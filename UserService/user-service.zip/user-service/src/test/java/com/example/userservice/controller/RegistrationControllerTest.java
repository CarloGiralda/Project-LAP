package com.example.userservice.controller;

import com.example.userservice.registration.dto.RegistrationRequest;
import com.example.userservice.registration.service.RegistrationFieldValidator;
import com.example.userservice.registration.service.RegistrationService;
import com.example.userservice.webui.RegistrationController;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@WebMvcTest(controllers = RegistrationController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
public class RegistrationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RegistrationService registrationService;

    @MockBean
    private RegistrationFieldValidator registrationFieldValidator;


    @Autowired
    private ObjectMapper objectMapper;


    private RegistrationRequest requestDto;

    @BeforeEach
    public void init(){
        // set value used for all tests
        requestDto = new RegistrationRequest("test", "test", "test@gmail.com","password");
    }

    @Test
    public void RegistrationController_createUser_returnUser() throws Exception {

        when(registrationFieldValidator.testEmail(requestDto.getEmail())).thenReturn(true);
        when(registrationFieldValidator.testName(requestDto.getFirstName())).thenReturn(true);
        when(registrationFieldValidator.testName(requestDto.getLastName())).thenReturn(true);

        mockMvc.perform(post("/registration")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("firstName", requestDto.getFirstName())
                .param("lastName", requestDto.getLastName())
                .param("email", requestDto.getEmail())
                .param("password", requestDto.getPassword())
        ).andExpect(status().isFound());

    }

}
