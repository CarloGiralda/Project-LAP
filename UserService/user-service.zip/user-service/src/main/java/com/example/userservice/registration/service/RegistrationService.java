package com.example.userservice.registration.service;

import com.example.userservice.appuser.model.AppUser;
import com.example.userservice.appuser.model.AppUserRole;
import com.example.userservice.appuser.service.AppUserService;
import com.example.userservice.registration.dto.RegistrationRequest;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@AllArgsConstructor
public class RegistrationService {

    private final AppUserService appUserService;
    private final RegistrationFieldValidator fieldValidator;

    // TODO use the value returned by register
    public void register(RegistrationRequest request) {
        boolean isValidEmail = fieldValidator.testEmail(request.getEmail());
        boolean isValidFirstName = fieldValidator.testName(request.getFirstName());
        boolean isValidLastName = fieldValidator.testName(request.getLastName());

        // TODO remove

        if (!isValidEmail || !isValidFirstName || !isValidLastName) {
            log.info("email :{},username:{}, lastname{}", isValidEmail, isValidFirstName, isValidLastName);
            throw new IllegalStateException("Invalid registration data");
        }

        appUserService.signUpUser(
                new AppUser(
                        request.getFirstName(),
                        request.getLastName(),
                        request.getEmail(),
                        request.getPassword(),
                        AppUserRole.USER
                )
        );

    }
}
