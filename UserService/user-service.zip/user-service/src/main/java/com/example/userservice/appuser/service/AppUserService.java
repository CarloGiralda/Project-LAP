package com.example.userservice.appuser.service;

import com.example.userservice.appuser.model.AppUser;
import com.example.userservice.appuser.repository.UserRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@AllArgsConstructor
public class AppUserService implements UserDetailsService {

    private final static String USER_NOT_FOUND_MSG = "user with email %s not found";
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;


    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        return userRepository
                .findByEmail(email)
                .orElseThrow(
                        () -> new UsernameNotFoundException(String.format(USER_NOT_FOUND_MSG, email))
                );
    }

/*
    public void updatePassword(String password, Long userId){
        userRepository.updatePassword(bCryptPasswordEncoder.encode(password), userId);
    }
*/

    public void signUpUser(AppUser appUser) {
        boolean userExists = userRepository.findByEmail(appUser.getEmail()).isPresent();
        if (userExists) {
            throw new IllegalStateException("user already exists");
        }
        // if user doesn't exist encode the password
        String encodedPassword = bCryptPasswordEncoder.encode(appUser.getPassword());
        appUser.setPassword(encodedPassword);

        // save is a method provided by jpa infrastructure
        appUser =  userRepository.save(appUser);

        log.info("user registered with ID: {}",appUser.getId());
        // TODO: implement email sending and enable account
    }

/*
    public int enableAppUser(String email) {
        return userRepository.enableAppUser(email);
    }
*/
}
