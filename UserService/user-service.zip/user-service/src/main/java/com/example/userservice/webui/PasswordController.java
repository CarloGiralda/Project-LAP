package com.example.userservice.webui;


import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PasswordController {

    @GetMapping("/forget-password")
    public String forgetPassword(){
        return "forget-password";
    }


}
