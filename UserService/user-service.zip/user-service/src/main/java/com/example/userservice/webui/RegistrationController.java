package com.example.userservice.webui;

import com.example.userservice.registration.dto.RegistrationRequest;
import com.example.userservice.registration.service.RegistrationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Controller
@RequestMapping("/registration")
@AllArgsConstructor
public class RegistrationController {

    private RegistrationService registrationService;



    @GetMapping
    public String showRegistrationForm(Model model){
        model.addAttribute("registerRequest", new RegistrationRequest());
        return "registration";
    }

    @PostMapping
    public String register(@ModelAttribute("registerRequest") RegistrationRequest request){
        try {
            log.info("register request: {}", request);
            registrationService.register(request);
            return "redirect:/registration?success";

        } catch (IllegalStateException e){
            log.error("Error during registration: {}", e.getMessage());
            return "redirect:/registration?invalid";
        }
    }

}
