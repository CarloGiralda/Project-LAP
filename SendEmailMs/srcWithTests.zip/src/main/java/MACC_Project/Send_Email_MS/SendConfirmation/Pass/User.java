package MACC_Project.Send_Email_MS.SendConfirmation.Pass;


import lombok.*;

import javax.persistence.*;


@Getter
@Entity
@NoArgsConstructor(force = true)
@AllArgsConstructor
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private  String email;
    public String firstName;
    public  String lastName;
    public  String residence;
    public  String password;
    private  UserRole role;
    public  String contact;


}