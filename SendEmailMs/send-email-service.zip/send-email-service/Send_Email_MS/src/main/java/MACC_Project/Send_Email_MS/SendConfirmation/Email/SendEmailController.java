package MACC_Project.Send_Email_MS.SendConfirmation.Email;


import MACC_Project.Send_Email_MS.SendConfirmation.Pass.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;


@Slf4j
@RestController
@RequestMapping(path="/email")
@AllArgsConstructor
public class SendEmailController {

    private  SendEmailService emailSender;
    private  UserService user;



    //TEST
    private  UserRepository users;
    //TEST_END


    @PostMapping(path = "/sendEmail")
    public ResponseEntity<String> sendConfirmationEmail(@RequestBody SendRequest request) {
        try {
            String result =  emailSender.send(request.getEmail(), request.getFirstName(), request.getConfirmationToken());
            return ResponseEntity.ok(result);
        } catch (Exception e){
            log.error("error sending confirmation email ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send email for account confirmation");
        }
    }


    @GetMapping(path = "/recovery")
    public ResponseEntity<String> sendRecoveryEmail(@RequestParam("email") String email) {
        // Generate random password
        String pass=UUID.randomUUID().toString();
        log.info("Sending Recovery Email...");

        // update password with a new random value
        if(user.updatePass(email, pass)!=1){
            log.error("Recovery Procedure Failed due to internal error");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to recover password");
        }

        // send back by email
        if(emailSender.send(email, pass, "Recovery") == null)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send recovery password email");

        log.info("Done, Recovery email has been sent to your registered email address");
        return ResponseEntity.ok("Recovery password email has been sent correctly");
    }
    //TEST TODO CHANGE TO RET COLLECTION OF USERS
/*    @GetMapping(path = "api/userSetting")
    public String userSettings() {
       LOGGER.info("Showing all names of registered users...");
        User us= user.all();
        return "Done all users are: "+us.getFirstName();
    }

   @PostMapping("api/userSetting")
    public User addOneEmployee(@RequestBody SendRequest request) {
       //REMOVE IF NOT TEST
        User us= new User(1L,request.getFirstName(),request.getLastName(),request.getEmail(),request.getPassword(),request.getResidence(), request.getContact(),UserRole.USER,false,true);
       return users.save(us);
    }*/

    //TEST_END
    @PostMapping(path = "/userSettings/modify")
    public ResponseEntity<String> modifyUserSettings(@RequestBody SendRequest request, @RequestHeader("Logged-In-User") String username) {
        try {
            log.info("updating user settings for user {}", username);
            if (user.updateNonNullFields(request) != 1) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to modify user settings");
            } else {
                return ResponseEntity.ok("User settings modified successfully");
            }
        } catch (Exception e){
            log.error("Error modifying user settings", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }

    }


}

