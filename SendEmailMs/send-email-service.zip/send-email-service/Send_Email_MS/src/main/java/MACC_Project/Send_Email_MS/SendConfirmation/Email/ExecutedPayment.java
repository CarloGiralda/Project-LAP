package MACC_Project.Send_Email_MS.SendConfirmation.Email;


import lombok.*;

@Getter
@Setter
@AllArgsConstructor
public class ExecutedPayment {

    private String sender;
    private String receiver;
    private Long price;

}
