package MACC_Project.Send_Email_MS.SendConfirmation.Email;

public enum EmailType {
    RECOVERY,
    CONFIRMATION,
    PAYMENT
}
