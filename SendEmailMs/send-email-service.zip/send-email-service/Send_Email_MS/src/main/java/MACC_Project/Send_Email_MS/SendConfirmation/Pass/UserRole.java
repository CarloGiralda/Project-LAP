package MACC_Project.Send_Email_MS.SendConfirmation.Pass;

public enum UserRole {
    USER,
    ADMIN
}
