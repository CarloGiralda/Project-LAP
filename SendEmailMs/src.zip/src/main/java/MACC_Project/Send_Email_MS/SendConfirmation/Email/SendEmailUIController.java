package MACC_Project.Send_Email_MS.SendConfirmation.Email;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SendEmailUIController {
    @RequestMapping(path="/welcome")
    public String getWelcomePage(){
        return "templates/UserSettings/loginForm.html";
    }
    @RequestMapping(path="/confirmation")
    public String getConfirmationPage(){
        return "templates/Email/confirmationEmail.html";
    }
    @RequestMapping(path="/upload")
    public String getUploadPage(){
        return "templates/Upload/upload.html";
    }
    @RequestMapping(path="/userSettings")
    public String getUserSettingsPage(){
        return "templates/UserSettings/userSettings.html";
    }

}
//  fails by default

