package MACC_Project.Send_Email_MS.SendConfirmation.FileUpload;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
@Service
public class UploadService {


    public String handleFileUpload(MultipartFile file,String file1, Path path) throws IOException {
        File destinationFolder = new File(String.valueOf(path));
        if (!destinationFolder.exists()) {
            if(!destinationFolder.mkdirs())
                return "uploadUnsucccessful";

        }
        File newFile = new File(destinationFolder,file1);
        if (! newFile.exists()) {
            if(!newFile.createNewFile())
                return "uploadUnsucccessful";
        }
        file.transferTo(newFile.toPath());
        System.out.println("PDF file saved successfully: " + path);
        // Construct the destination file path
        String destinationFilePath = path + File.separator + "user.pdf";

        // Create input and output streams for file copying
        System.out.println(path+file.getName());
        try (InputStream inputStream = new FileInputStream(path+"/"+file.getName());
             OutputStream outputStream = new FileOutputStream(destinationFilePath)) {

            // Buffer to hold data during the copy process
            byte[] buffer = new byte[1024];
            int bytesRead;

            // Copy data from the input stream to the output stream
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }

        return "uploadSuccessful";
    }


}

