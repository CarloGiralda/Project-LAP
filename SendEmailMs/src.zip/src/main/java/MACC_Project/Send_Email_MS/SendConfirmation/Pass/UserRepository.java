package MACC_Project.Send_Email_MS.SendConfirmation.Pass;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer> {



    @Transactional
    @Modifying
    @Query(value = "UPDATE User u  " +
            "SET u.password = ?1 WHERE u.email = ?2")
    int updatePass(@Param("password") String password,
                   @Param("email") String  email);

    @Transactional
    @Modifying
    @Query(value = "UPDATE User u " +
            "SET u.firstName =?1 WHERE u.email =?2")
    int updateFirstName(@Param("firstName") String firstName,
                        @Param("email") String email);

    @Transactional
    @Modifying
    @Query(value = "UPDATE User u  " +
            "SET u.lastName = ?1 WHERE u.email = ?2")
    int updateLastName(@Param("lastName") String lastName,
                       @Param("email") String  email);

    @Transactional
    @Modifying
    @Query(value = "UPDATE User u  " +
            "SET u.residence = ?1 WHERE u.email = ?2")
    int updateResidence(@Param("residence") String residence,
                       @Param("email") String  email);

    @Transactional
    @Modifying
    @Query(value = "UPDATE User u  " +
            "SET u.contact = ?1 WHERE u.email = ?2")
    int updateContact(@Param("contact") String contact,
                        @Param("email") String  email);


    @Query(value = "SELECT * FROM USERS u",
            nativeQuery = true)
    User show();


    Optional<UserDetails> findByEmail(String email);
}
