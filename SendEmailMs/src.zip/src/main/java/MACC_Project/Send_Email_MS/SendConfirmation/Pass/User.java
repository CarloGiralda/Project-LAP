package MACC_Project.Send_Email_MS.SendConfirmation.Pass;


import lombok.*;

import javax.persistence.*;


@Getter
@Entity
@NoArgsConstructor(force = true)
@AllArgsConstructor
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private final String email;
    private final String firstName;
    private final String lastName;
    private final String residence;
    private final String password;
    private final UserRole role;
    private final String contact;


}