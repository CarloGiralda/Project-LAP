package MACC_Project.Send_Email_MS;

import MACC_Project.Send_Email_MS.SendConfirmation.Email.SendRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Path;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest(classes = MACC_Project.Send_Email_MS.SendConfirmation.SendEmailMsApplication.class)
@AutoConfigureMockMvc
class IntegrationTests {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void sendRecoveryEmail() throws Exception {
        String email="bordingianmarco@virgilio.it";
        // First insert the user for testing purposes
        SendRequest request=new SendRequest("Gianmarco","Bordin","bordingianmarco@virgilio.it","ciao","","","");
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:8081/api/userSetting")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)).accept(MediaType.APPLICATION_JSON);
        MvcResult result1 = mvc.perform(requestBuilder).andReturn();
        Assertions.assertEquals("{\"id\":1,\"firstName\":\"Gianmarco\",\"lastName\":\"Bordin\",\"email\":\"bordingianmarco@virgilio.it\",\"password\":\"ciao\",\"residence\":\"\",\"contact\":\"\",\"appUserRole\":\"USER\",\"locked\":false,\"enabled\":true}", result1.getResponse().getContentAsString());
        MvcResult result2 = mvc.perform(get("http://localhost:8081/api/recovery/pass").queryParam("email",email)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn();
        Assertions.assertEquals("Done, Recovery email has been sent to your registered email address", result2.getResponse().getContentAsString());
    }

    @Test
    void modifyUserSettings() throws Exception {

        // First insert the user for testing purposes
        SendRequest request=new SendRequest("Gianmarco","Bordin","bordingianmarco@virgilio.it","ciao","","","");
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:8081/api/userSetting")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)).accept(MediaType.APPLICATION_JSON);
        MvcResult result1 = mvc.perform(requestBuilder).andReturn();
        Assertions.assertEquals("{\"id\":1,\"firstName\":\"Gianmarco\",\"lastName\":\"Bordin\",\"email\":\"bordingianmarco@virgilio.it\",\"password\":\"ciao\",\"residence\":\"\",\"contact\":\"\",\"appUserRole\":\"USER\",\"locked\":false,\"enabled\":true}", result1.getResponse().getContentAsString());
        SendRequest request2=new SendRequest("GIAN","Bordin","bordingianmarco@virgilio.it","ciao","firstName","","");
        RequestBuilder requestBuilder2 = MockMvcRequestBuilders.post("http://localhost:8081/api/userSettings/modify")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request2)).accept(MediaType.TEXT_PLAIN);
        MvcResult result2 = mvc.perform(requestBuilder2).andReturn();
        Assertions.assertEquals("Done, User Settings Modified", result2.getResponse().getContentAsString());
    }

    @Test
    void sendConfirmationEmail() throws Exception {
        SendRequest request=new SendRequest("Gianmarco","Bordin","bordingianmarco@virgilio.it","ciao","","","");
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:8081/api/email/sendEmail")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)).accept(MediaType.TEXT_PLAIN);
        MvcResult result1 = mvc.perform(requestBuilder).andReturn();
        Assertions.assertEquals("Done", result1.getResponse().getContentAsString());
        // testing confirmation token
        /*
        String testToken="DUMMY";
        MvcResult result2 = mvc.perform(get("http://localhost:8081/api/confirmation/confirm").queryParam("token",testToken)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn();
        Assertions.assertEquals("Token Confirmed", result2.getResponse().getContentAsString());
    */
    }



    @Test
    void handleFileUpload() throws Exception {
        File file =  new File("/Users/applem2/Downloads/Send_Email_MS/dummy.pdf");
        Path path = Path.of("Downloads");
        String fileName = FilenameUtils.getName(file.getName());
        byte[] bytes = FileUtils.readFileToByteArray((File) file);
        MockMultipartFile mockMultipartFile = new MockMultipartFile("file", "file", MediaType.MULTIPART_FORM_DATA_VALUE, bytes);
        MvcResult result= mvc.perform(multipart("http://localhost:8081/api/upload/file").file(mockMultipartFile))
                .andExpect(status().isOk())
                .andExpect(content().string("Done, File Uploaded!"))
                .andDo(print()).andReturn();
        Assertions.assertEquals("Done, File Uploaded!", result.getResponse().getContentAsString());
    }
}




