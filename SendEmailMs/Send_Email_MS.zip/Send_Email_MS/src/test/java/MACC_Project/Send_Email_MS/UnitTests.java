package MACC_Project.Send_Email_MS;

import MACC_Project.Send_Email_MS.SendConfirmation.Email.SendEmailController;
import MACC_Project.Send_Email_MS.SendConfirmation.Email.SendEmailService;
import MACC_Project.Send_Email_MS.SendConfirmation.Email.SendRequest;
import MACC_Project.Send_Email_MS.SendConfirmation.FileUpload.UploadService;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.TokenService;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.UserRepository;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Path;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SendEmailController.class)
@ContextConfiguration("/test-context.xml")
class UnitTests {

	@Autowired
	private MockMvc mockMvc;
	@Autowired
	private  ObjectMapper objectMapper;

	//private final SendEmailController sendEmailController;
	@MockBean
	private  SendEmailService emailSender;
	@MockBean
	private  UploadService upload;
	@MockBean
	private  UserService user;

	@MockBean
	private TokenService token;
	@MockBean
	private  UserRepository users;


	@BeforeEach
	void setUp(WebApplicationContext wac) {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}

	@Test
	void sendRecoveryEmail() throws Exception {
		String email="bordingianmarco@virgilio.it";
		when(emailSender.send(any(String.class), any(String.class),anyString())).thenReturn("Done");
		when(user.updatePass(any(String.class), any(String.class))).thenReturn(1);
		MvcResult result = mockMvc.perform(get("http://localhost:8081/api/recovery/pass").queryParam("email",email)
						.accept(MediaType.APPLICATION_JSON))
				.andReturn();
		Assertions.assertEquals("Done, Recovery email has been sent to your registered email address", result.getResponse().getContentAsString());
	}


	@Test
	void modifyUserSettings() throws Exception {
		SendRequest request=new SendRequest("Gianmarco","Bordin","bordingianmarco@virgilio.it","ciao","","","");
		when(user.updateNonNullFields(any(SendRequest.class))).thenReturn(1);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:8081/api/userSettings/modify")
				.accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(request)).accept(MediaType.TEXT_PLAIN);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		Assertions.assertEquals("Done, User Settings Modified", result.getResponse().getContentAsString());
	}


	@Test
	void sendConfirmationEmail() throws Exception {
		SendRequest request=new SendRequest("Gianmarco","Bordin","bordingianmarco@virgilio.it","ciao","","","");
		when(emailSender.send(any(String.class),any(String.class), anyString())).thenReturn("Done");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:8081/api/email/sendEmail")
				.accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(request)).accept(MediaType.TEXT_PLAIN);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
			Assertions.assertEquals("Done", result.getResponse().getContentAsString());
			}


	@Test
	void handleFileUpload() throws Exception {
			File file =  new File("/Users/applem2/Downloads/Send_Email_MS/dummy.pdf");
			Path path = Path.of("Downloads");
			MultipartFile mfile = new MockMultipartFile("test.pdf", new FileInputStream("/Users/applem2/Downloads/Send_Email_MS/dummy.pdf"));
			when(upload.handleFileUpload(any(MultipartFile.class),anyString(),eq(path))).thenReturn("uploadSuccessful");
			String fileName = FilenameUtils.getName(file.getName());
			byte[] bytes = FileUtils.readFileToByteArray((File) file);
			MockMultipartFile mockMultipartFile = new MockMultipartFile("file", fileName, MediaType.MULTIPART_FORM_DATA_VALUE, bytes);
			MvcResult result= mockMvc.perform(multipart("http://localhost:8081/api/upload/file").file(mockMultipartFile))
			.andExpect(status().isOk())
			.andExpect(content().string("Done, File Uploaded!"))
			.andDo(print()).andReturn();
		Assertions.assertEquals("Done, File Uploaded!", result.getResponse().getContentAsString());

	}

}
