package MACC_Project.Send_Email_MS.SendConfirmation.Pass;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
@Transactional(readOnly = true)
public interface TokenRepository
        extends JpaRepository<Token, Long> {

    Token findByToken(String token);

}