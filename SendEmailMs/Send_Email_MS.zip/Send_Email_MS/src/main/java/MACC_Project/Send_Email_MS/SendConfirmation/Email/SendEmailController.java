package MACC_Project.Send_Email_MS.SendConfirmation.Email;

import MACC_Project.Send_Email_MS.SendConfirmation.FileUpload.UploadService;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.*;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.springframework.web.bind.annotation.*;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Objects;
import java.util.UUID;

@RestController
@AllArgsConstructor
public class SendEmailController {

    private  SendEmailService emailSender;
    private  UserService user;
    private TokenService tokenService;
    private  UploadService upload;
    //TEST
    private  UserRepository users;
//TEST_END
    final Logger LOGGER = LoggerFactory
            .getLogger(SendEmailController.class);


    @PostMapping(path = "api/email/sendEmail")
    public String sendConfirmationEmail(@RequestBody SendRequest request) {
        LOGGER.info("Saving token...");
        String tok = UUID.randomUUID().toString();
        Token token = new Token(tok);
        tokenService.saveToken(token);
        return emailSender.send(request.getEmail(), request.getFirstName(), tok);
    }


    @GetMapping(path = "api/confirmation/confirm")
    public String confirmEmailToken(@RequestParam("token") String token)  {
        LOGGER.info("Confirming Token...");
        Token t=tokenService.getToken(token);
        String ret=emailSender.confirmToken(t.getToken(),token);
        if(Objects.equals(ret,"Token Confirmed")){
            tokenService.deleteToken(t);
        }
        return ret;
    }

    @GetMapping(path = "api/recovery/pass")
    public String sendRecoveryEmail(@RequestParam("email") String email) {
        String pass=UUID.randomUUID().toString();
        LOGGER.info("Sending Recovery Email...");
        if(user.updatePass(email, pass)!=1){
            LOGGER.error("Recovery Procedure Failed due to internal error");
            return "500 INTERNAL SERVER ERROR";
        }
        if(emailSender.send(email, pass, "Recovery")==null)
            return "500 INTERNAL SERVER ERROR";
        return "Done, Recovery email has been sent to your registered email address";
    }
//TEST TODO CHANGE TO RET COLLECTION OF USERS
    @GetMapping(path = "api/userSetting")
    public String userSettings() {
       LOGGER.info("Showing all names of registered users...");
        User us= user.all();
        return "Done all users are: "+us.getFirstName();
    }

   @PostMapping("api/userSetting")
    public User addOneEmployee(@RequestBody SendRequest request) {
       //REMOVE IF NOT TEST
        User us= new User(1L,request.getFirstName(),request.getLastName(),request.getEmail(),request.getPassword(),request.getResidence(), request.getContact(),UserRole.USER,false,true);
       return users.save(us);
    }

//TEST_END
    @PostMapping(path = "api/userSettings/modify")
    public String modifyUserSettings(@RequestBody SendRequest request) {
        LOGGER.info("Sending Confirmation Email...");
                if(user.updateNonNullFields(request)!=1) {
                    return "500 INTERNAL SERVER ERROR";
                }else{
                    return "Done, User Settings Modified";
                }

        }


    @PostMapping("api/upload/file")
    public String handleFileUpload(@RequestPart("file") MultipartFile file) throws IOException {
        Path path = Path.of("Downloads");
        String fileName = file.getOriginalFilename();
        if(!"uploadSuccessful".equals(upload.handleFileUpload(file,fileName, path))) return "500 INTERNAL SERVER ERROR";
        else
            return "Done, File Uploaded!";
    }
}

