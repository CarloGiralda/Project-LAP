package MACC_Project.Send_Email_MS.SendConfirmation.Pass;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Objects;


@Service
@AllArgsConstructor
public class TokenService {

    private final TokenRepository confirmationTokenRepository;

    public void saveToken(Token token) {
        confirmationTokenRepository.save(token);
    }

    public Token getToken(String token) {
        Token ret=confirmationTokenRepository.findByToken(token);
        if(!Objects.isNull(ret))
            return ret;
        else {
            return new Token("Token not recognized, token does not exist");
        }
    }

    public void deleteToken(Token token) {
        confirmationTokenRepository.delete(token);
    }

}