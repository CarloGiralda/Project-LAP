package MACC_Project.Send_Email_MS.SendConfirmation.Pass;


import lombok.*;
import javax.persistence.*;


@Setter
@Getter
@Entity
@NoArgsConstructor(force = true)
@Table(name="tokens")
public class Token {


    @SequenceGenerator(
            name = "token_sequence",
            sequenceName = "token_sequence",
            allocationSize = 1
    )
    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "token_sequence"
    )
    private Long id;
    @Getter
    private String token;

    public Token(String token) {
        this.token = token;
    }

}