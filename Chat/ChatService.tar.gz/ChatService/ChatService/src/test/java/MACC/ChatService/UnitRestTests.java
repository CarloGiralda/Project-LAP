package MACC.ChatService;


import MACC.ChatService.controller.ChatRestController;
import MACC.ChatService.model.ChatMessage;
import MACC.ChatService.model.ChatService;
import MACC.ChatService.model.MappingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;

import static MACC.ChatService.model.ChatMessage.MessageType.CHAT;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ChatRestController.class)
@ContextConfiguration("/test-context2.xml")
class UnitRestTests {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private  ObjectMapper objectMapper;

    //private final SendEmailController sendEmailController;
    @MockBean
    private ChatService chatService;
    @MockBean
    private MappingService mappingService;



    @BeforeEach
    void setUp(WebApplicationContext wac) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    void loadAllChat() throws Exception {
        ChatMessage chat1=new ChatMessage(1L,"hello","sender","receiver","AAAAA",CHAT);
        ChatMessage chat2=new ChatMessage(2L,"hello2","receiver","sender","BBBBB",CHAT);
        Collection<ChatMessage> msgs=new ArrayList<>();
        msgs.add(chat1);
        msgs.add(chat2);
        when(chatService.getChatMessages(any(String.class),any(String.class))).thenReturn(msgs);
        MvcResult result = mockMvc.perform(get("http://localhost:8080/messages/sender/receiver/AAAAA")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn();
        Assertions.assertEquals(new Gson().toJson(msgs), result.getResponse().getContentAsString());
    }

}
