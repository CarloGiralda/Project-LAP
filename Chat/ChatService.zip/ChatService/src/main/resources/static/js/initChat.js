// Function to perform the GET request




  function performGetRequest(receiverValue) {
      // Replace 'https://example.com/api' with the actual URL you want to send the GET request to
      //var url = 'localhost:8080/m';
      var senderValue = document.querySelector('#sender').textContent;
      console.log(receiverValue);
     // var receiverValue = document.querySelector('#'+'${chat.receiver}').textContent;
      // Construct the URL with parameters
      var fullUrl = `/m?sender=${senderValue}&receiver=${receiverValue}`;
      console.log(fullUrl);
      const userChatResponse = fetch(fullUrl)
       .then(function (response) {
       	// The API call was successful!
       	return response.text();
       }).then(function (html) {

         	// Convert the HTML string into a document object
         	var parser = new DOMParser();
         	var doc = parser.parseFromString(html, 'text/html');
         	document.open();
                    document.write(html);
                    document.close();

         }).catch(function (err) {
         	// There was an error
         	console.warn('Something went wrong.', err);
         });

  }
