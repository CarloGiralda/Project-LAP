package MACC.ChatService.controller;

import MACC.ChatService.model.Chat;
import MACC.ChatService.model.ChatMessage;
import MACC.ChatService.model.ChatService;
import MACC.ChatService.model.MappingService;
import com.google.gson.Gson;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;

@Controller
@AllArgsConstructor
public class ChatController {

    private final ChatService chatService;
    private final MappingService mappingService;

    @Autowired
    private final SimpMessagingTemplate simpMessagingTemplate;//remove if test



    @CrossOrigin("*")
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String initChatsPage(Model model,@RequestParam String sender) {
        model.addAttribute("sender", sender);
        Collection<Chat> chats= chatService.getChats(sender);
        Iterator<Chat> iterator = chats.iterator();
        while (iterator.hasNext()) {
             Chat it=iterator.next();
             if(Objects.equals(it.getReceiver(),sender)){
                 String temp=it.getSender();
                 it.setSender(it.getReceiver());
                 it.setReceiver(temp);
             }
        }
        model.addAttribute("chats", chats);
        return "formPage";
    }


    @CrossOrigin("*")
    @RequestMapping(value = "/m", method = RequestMethod.GET)
    public String messages(Model model,@RequestParam String sender,@RequestParam String receiver) {
        model.addAttribute("sender", sender);
        model.addAttribute("receiver", receiver);
        System.out.println(sender+"------"+receiver);
        return "index";
    }


    @MessageMapping("/secured/room")
    public void sendSpecific(@Payload ChatMessage msg)  {
        // Store the message
        chatService.saveChatMessage(msg);
        // To same user
        // Update sender session ID
        mappingService.updateSession(msg.getSender(), msg.getSessionId());
        simpMessagingTemplate.convertAndSend("/secured/user/queue/specific-user-user"+msg.getSessionId(),msg);//remove if test
        // To receiver
        // Get receiver session ID
        String rSessionId= mappingService.getSession(msg.getReceiver());
        simpMessagingTemplate.convertAndSend("/secured/user/queue/specific-user-user"+rSessionId,msg);//remove if test

    }
}