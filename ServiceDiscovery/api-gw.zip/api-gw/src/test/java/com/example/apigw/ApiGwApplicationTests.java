package com.example.apigw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGwApplicationTests {

	@Test
	void contextLoads() {
	}

}
