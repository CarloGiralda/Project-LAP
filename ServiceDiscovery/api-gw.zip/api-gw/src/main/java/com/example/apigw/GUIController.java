package com.example.apigw;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Objects;
//TODO VERIFY IF NEEDED
@Controller
public class GUIController {
    @RequestMapping(path="/RentCars")
    public String getWelcomePage(){
        return "index.html";
    }
    @RequestMapping(path="/api/email")
    public String getConfirmationPage(){
        return "templates/Email/confirmationEmail.html";
    }
    @RequestMapping(path="/api/upload")
    public String getUploadPage(){
        return "templates/Upload/upload.html";
    }
    @RequestMapping(path="api/userSettings")
    public String getUserSettingsPage(){
        return "templates/UserSettings/userSettings.html";
    }
    @RequestMapping(path="/pages")
    public String getSuccessPage(@Param("type") String type){
        return "templates/"+ type +".html";
    }

}