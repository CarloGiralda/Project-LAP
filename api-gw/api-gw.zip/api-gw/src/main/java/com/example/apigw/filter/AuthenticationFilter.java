package com.example.apigw.filter;

import com.netflix.discovery.converters.Auto;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    @Autowired
    private RouteValidator routeValidator;

    @Auto
    private RestTemplate template;

    public AuthenticationFilter() {
        super(Config.class);
    }


    @Override
    public GatewayFilter apply(Config config) {
        return ((exchange, chain) -> {

            ServerHttpRequest request = exchange.getRequest();

            if(routeValidator.isSecured.test(request)){

                //check if header contains header
                if(!request.getHeaders().containsKey(HttpHeaders.AUTHORIZATION)){
                    throw new RuntimeException("missing authorization error");
                }

                // if authentication is in the header get it
                String authHeader = request.getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
                if (authHeader!=null && authHeader.startsWith("Bearer")){
                    authHeader = authHeader.substring(7);
                }
                try {
                    // REST call to AUTH service, user-service is known through service discovery eureka server
                    template.getForObject("http://USER-SERVICE/auth/validate?token="+authHeader, String.class);
                    log.info("JWT token validated: {}", authHeader);

                    //exchange.getRequest()
                      //      .mutate()
                        //    .header("loggedInUser");


                } catch (Exception e){
                    // CUSTOMIZE with
                    throw new RuntimeException("unauthorized access to application");
                }


            }
            return chain.filter(exchange);
        });
    }

    public static class Config{

    }
}
