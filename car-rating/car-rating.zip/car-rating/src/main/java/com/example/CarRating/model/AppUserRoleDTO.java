package com.example.CarRating.model;

public enum AppUserRoleDTO {
    USER,
    ADMIN
}
