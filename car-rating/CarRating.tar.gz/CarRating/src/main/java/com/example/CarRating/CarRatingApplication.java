package com.example.CarRating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarRatingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarRatingApplication.class, args);
	}

}
