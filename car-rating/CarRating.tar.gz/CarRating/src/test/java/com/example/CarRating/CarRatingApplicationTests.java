package com.example.CarRating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRatingApplicationTests {

	@Test
	void contextLoads() {
	}

}
