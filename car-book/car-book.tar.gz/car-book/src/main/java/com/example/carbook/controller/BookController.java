package com.example.carbook.controller;

import com.example.carbook.model.Car;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RequestMapping(path = "/book")
@RestController
public class BookController {
    @PostMapping(path = "/{offerId}")
    public Car bookCar(@PathVariable Long offerId, Car car) {
        // TODO dummy
        return new Car(1L, "PW", 2020L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "M", 4L, "M", "M", "A", Car.Size.Big, 4L, Car.Engine.Diesel, Car.Transmission.Automatic, 1L, 1L);
    }

    @GetMapping(path = "/listoffers")
    public ArrayList<Car> listBookedCar() {
        // TODO dummy
        Car car = new Car(1L, "PW", 2020L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "M", 4L, "M", "M", "A", Car.Size.Big, 4L, Car.Engine.Diesel, Car.Transmission.Automatic, 1L, 1L);
        ArrayList<Car> cars = new ArrayList<>();
        cars.add(car);
        return cars;
    }
}
