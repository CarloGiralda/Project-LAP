package com.example.carbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
