package com.example.CarSearch.controller;

import com.example.CarSearch.model.*;
import com.example.CarSearch.service.SearchService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.isA;
import static org.mockito.Mockito.when;

@WebMvcTest(controllers = SearchController.class)
public class SearchControllerTest {
    @MockBean
    private SearchService searchService;
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void shouldReturnTrueIfTheCarIsReturned() throws Exception {

        Car car = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", Car.Classification.CityCar, 4L, Car.Engine.Electric, Car.Transmission.Automatic);
        car.setCid(1L);
        Offer offer = new Offer(1602288000L, 1602288000L, "10.5", "test@gmail.com", "41.8933203/12.4829321");
        offer.setOid(1L);
        Utilities ut = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");
        ut.setUtid(1L);
        SearchDTO dto = new SearchDTO(car, offer, ut);

        ObjectMapper omdto = new ObjectMapper();
        omdto.findAndRegisterModules();
        String dtoAsString = omdto.writeValueAsString(dto);

        List<SearchDTO> list = new ArrayList<>();
        list.add(dto);

        when(searchService.getCar(ArgumentMatchers.any())).thenReturn(list);

        mockMvc.perform(MockMvcRequestBuilders.post("/carsearch/searchbar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(dtoAsString))
                .andExpect(MockMvcResultMatchers.status().is(200))
                .andExpect(MockMvcResultMatchers.jsonPath("$.*", isA(ArrayList.class)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[*].cid", containsInAnyOrder(1)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[*].brand", containsInAnyOrder("Tesla")))
                .andExpect(MockMvcResultMatchers.jsonPath("$[*].pricePerHour", containsInAnyOrder("10.5")));
    }

    @Test
    public void shouldReturnFalseIfNoCarIsReturned() throws Exception {
        SearchDTO dto = new SearchDTO();

        ObjectMapper omdto = new ObjectMapper();
        omdto.findAndRegisterModules();
        String dtoAsString = omdto.writeValueAsString(dto);

        when(searchService.getCar(ArgumentMatchers.any())).thenReturn(null);

        mockMvc.perform(MockMvcRequestBuilders.post("/carsearch/searchbar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(dtoAsString))
                .andExpect(MockMvcResultMatchers.status().is(404));
    }

    @Test
    public void shouldReturnOneCarFromItsId() throws Exception {
        Long input_id = 1L;

        Car car = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", Car.Classification.CityCar, 4L, Car.Engine.Electric, Car.Transmission.Automatic);
        car.setCid(1L);
        Offer offer = new Offer(1602288000L, 1602288000L, "10.5", "test@gmail.com", "41.8933203/12.4829321");
        offer.setOid(1L);
        Utilities ut = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");
        ut.setUtid(1L);
        SearchDTO dto = new SearchDTO(car, offer, ut);
        List<SearchDTO> dtos = new ArrayList<>();
        dtos.add(dto);

        when(searchService.getSearchDTOById(ArgumentMatchers.any(Long.class))).thenReturn(dtos);

        mockMvc.perform(MockMvcRequestBuilders.get("/carsearch/getCarById/" + input_id))
                .andExpect(MockMvcResultMatchers.status().is(200));
    }

    @Test
    public void shouldReturnACarNameFromItsId() throws Exception {
        Long input_id = 1L;

        String response = "Tesla,S";

        when(searchService.getCarById(ArgumentMatchers.any(Long.class))).thenReturn(response);

        mockMvc.perform(MockMvcRequestBuilders.get("/carsearch/getCarNameById/" + input_id))
                .andExpect(MockMvcResultMatchers.status().is(200));
    }

    // TODO check the JSONARRAY, because it is likely the problem
    @Test
    public void shouldReturnAListOfCarsWithinARange() throws Exception {
        String position = "41.8933203/12.4829321";
        Long range = 10L;

        JsonArray expectedResponse = new JsonArray();
        JsonObject object = new JsonObject();
        object.addProperty("lat",41.8933203);
        object.addProperty("lon",12.4829321);
        object.addProperty("name","TeslaS");
        object.addProperty("id",0);
        object.addProperty("cid",1L);
        expectedResponse.add(object);

        when(searchService.getCarsInsideRange(ArgumentMatchers.any(String.class), ArgumentMatchers.any(Long.class))).thenReturn(expectedResponse);

        mockMvc.perform(MockMvcRequestBuilders.get("/carsearch/getCarsWithinRange?position=" + position + "&range=" + range))
                .andExpect(MockMvcResultMatchers.status().is(200));
    }
}
