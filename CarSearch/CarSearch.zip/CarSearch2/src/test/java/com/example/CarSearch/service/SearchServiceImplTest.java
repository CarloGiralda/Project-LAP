package com.example.CarSearch.service;

import com.example.CarSearch.model.*;
import com.example.CarSearch.repository.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class SearchServiceImplTest {
    @Mock
    private SearchRepo searchRepo;
    @Mock
    private CarRepo carRepo;

    @Test
    @DisplayName("Should pass if a list of searchdto (car, offer and utilities) is returned")
    void shouldReturnTrueIfADTOIsReturned() {
        SearchServiceImpl ssi = new SearchServiceImpl(searchRepo, carRepo);

        Car car = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", Car.Classification.CityCar, 4L, Car.Engine.Electric, Car.Transmission.Automatic);

        Offer offer = new Offer(1602288000L, 1602288000L, "10.5", "test@gmail.com", "41.8933203/12.4829321");

        Utilities ut = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");

        // this is the searchdto in input
        SearchDTO dto = new SearchDTO (car, offer, ut);
        // this is the expected result of the repository
        List<SearchDTO> expectedResponse = new ArrayList<>();
        expectedResponse.add(dto);

        Mockito.when(searchRepo.getCarOfferUtFromSearchDTO(ArgumentMatchers.any())).thenReturn(expectedResponse);

        List<SearchDTO> actualResponse = ssi.getCar(dto);

        Assertions.assertEquals(expectedResponse.get(0).getCar().getBrand(), actualResponse.get(0).getCar().getBrand());
        Assertions.assertEquals(expectedResponse.get(0).getCar().getEngine(), actualResponse.get(0).getCar().getEngine());
        Assertions.assertEquals(expectedResponse.get(0).getOffer().getPricePerHour(), actualResponse.get(0).getOffer().getPricePerHour());
        Assertions.assertEquals(expectedResponse.get(0).getOffer().getFromDate(), actualResponse.get(0).getOffer().getFromDate());
        Assertions.assertEquals(expectedResponse.get(0).getUtilities().getBluetooth(), actualResponse.get(0).getUtilities().getBluetooth());
        Assertions.assertEquals(expectedResponse.get(0).getUtilities().getDescription(), actualResponse.get(0).getUtilities().getDescription());
    }

    @Test
    @DisplayName("Should pass a DTO is returned")
    void shouldReturnADTOFromItsId() {
        SearchServiceImpl ssi = new SearchServiceImpl(searchRepo, carRepo);

        Long input_id = 1L;

        Car car = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", Car.Classification.CityCar, 4L, Car.Engine.Electric, Car.Transmission.Automatic);
        car.setCid(1L);
        Offer offer = new Offer(1602288000L, 1602288000L, "10.5", "test@gmail.com", "41.8933203/12.4829321");
        offer.setOid(1L);
        Utilities ut = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");
        ut.setUtid(1L);

        SearchDTO dto = new SearchDTO (car, offer, ut);
        // this is the expected result of the repository
        List<SearchDTO> expectedResponse = new ArrayList<>();
        expectedResponse.add(dto);

        Mockito.when(searchRepo.getCarOfferUtFromId(ArgumentMatchers.any(Long.class))).thenReturn(expectedResponse);

        List<SearchDTO> actualResponse = ssi.getSearchDTOById(input_id);

        Assertions.assertEquals(expectedResponse.get(0).getCar().getBrand(), actualResponse.get(0).getCar().getBrand());
        Assertions.assertEquals(expectedResponse.get(0).getCar().getEngine(), actualResponse.get(0).getCar().getEngine());
        Assertions.assertEquals(expectedResponse.get(0).getOffer().getPricePerHour(), actualResponse.get(0).getOffer().getPricePerHour());
        Assertions.assertEquals(expectedResponse.get(0).getOffer().getFromDate(), actualResponse.get(0).getOffer().getFromDate());
        Assertions.assertEquals(expectedResponse.get(0).getUtilities().getBluetooth(), actualResponse.get(0).getUtilities().getBluetooth());
        Assertions.assertEquals(expectedResponse.get(0).getUtilities().getDescription(), actualResponse.get(0).getUtilities().getDescription());
    }

    @Test
    @DisplayName("Should pass if a string containing both model and brand of a car is returned")
    void shouldReturnAStringContainingModelAndBrandOfACarFromItsId() {
        SearchServiceImpl ssi = new SearchServiceImpl(searchRepo, carRepo);

        Long input_id = 1L;

        String response = "Tesla,S";

        Mockito.when(carRepo.findCarById(ArgumentMatchers.any(Long.class))).thenReturn(response);

        String actualResponse = ssi.getCarById(input_id);

        Assertions.assertEquals(response, actualResponse);
    }

    @Test
    @DisplayName("Should pass if a list of cars is returned")
    void shouldReturnAllCarsInsideARange() {
        SearchServiceImpl ssi = new SearchServiceImpl(searchRepo, carRepo);

        String position = "41.8933203/12.4829321";
        Long range = 1L;

        Car car1 = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", Car.Classification.CityCar, 4L, Car.Engine.Electric, Car.Transmission.Automatic);
        car1.setCid(1L);
        Offer offer1 = new Offer(1602288000L, 1602288000L, "10.5", "test@gmail.com", "41.8933203/12.4829321");
        offer1.setOid(1L);
        Utilities ut1 = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");
        ut1.setUtid(1L);
        SearchDTO dto1 = new SearchDTO(car1, offer1, ut1);

        Car car2 = new Car("PK555AW", 2020L, Car.PollutionLevel.EURO2, Car.Fuel.Electric, "Fiat", 4L,
                "Cinquecento", Car.Classification.CityCar, 2L, Car.Engine.Electric, Car.Transmission.Automatic);
        car2.setCid(1L);
        Offer offer2 = new Offer(1602288000L, 1602288000L, "10.5", "test@gmail.com", "45.4641943/9.1896346");
        offer2.setOid(1L);
        Utilities ut2 = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");
        ut2.setUtid(1L);
        SearchDTO dto2 = new SearchDTO(car2, offer2, ut2);

        List<SearchDTO> dtos = new ArrayList<>();
        dtos.add(dto1);
        dtos.add(dto2);

        Mockito.when(searchRepo.getCars()).thenReturn(dtos);

        JsonArray expectedResponse = new JsonArray();

        JsonObject object = new JsonObject();
        object.addProperty("lat","41.8933203");
        object.addProperty("lon","12.4829321");
        object.addProperty("name","TeslaS");
        object.addProperty("id",0);
        object.addProperty("cid",1L);

        expectedResponse.add(object);

        JsonArray actualResponse = ssi.getCarsInsideRange(position, range);

        Assertions.assertEquals(expectedResponse.get(0).getAsJsonObject().get("lat"), actualResponse.get(0).getAsJsonObject().get("lat"));
        Assertions.assertEquals(expectedResponse.get(0).getAsJsonObject().get("lon"), actualResponse.get(0).getAsJsonObject().get("lon"));
        Assertions.assertEquals(expectedResponse.get(0).getAsJsonObject().get("name"), actualResponse.get(0).getAsJsonObject().get("name"));
        Assertions.assertEquals(expectedResponse.get(0).getAsJsonObject().get("id"), actualResponse.get(0).getAsJsonObject().get("id"));
        Assertions.assertEquals(expectedResponse.get(0).getAsJsonObject().get("cid"), actualResponse.get(0).getAsJsonObject().get("cid"));
    }
}