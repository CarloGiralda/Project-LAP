package com.example.CarSearch.service;

import com.example.CarSearch.model.CarPreviewDTO;
import com.example.CarSearch.model.SearchDTO;
import com.google.gson.JsonArray;

import java.util.List;

public interface SearchService {
    List<SearchDTO> getCar(SearchDTO dto);
    CarPreviewDTO getCarPreview(Long carId);
    public List<SearchDTO> getSearchDTOById(Long id);
    String getCarById(Long id);
    JsonArray getCarsInsideRange(String position, Long range);
}
