package com.example.CarSearch.service;

import com.example.CarSearch.model.*;
import com.example.CarSearch.repository.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SearchServiceImpl implements SearchService {
    private final SearchRepo searchRepo;
    private final CarRepo carRepo;

    public SearchServiceImpl(SearchRepo searchRepo, CarRepo carRepo) {
        this.searchRepo = searchRepo;
        this.carRepo = carRepo;
    }
    
    @Override
    public List<SearchDTO> getCar(SearchDTO dto) {
        List<SearchDTO> dtos = searchRepo.getCarOfferUtFromSearchDTO(dto);
        if (dtos.isEmpty()) {
            return null;
        }
        return dtos;
    }

    @Override
    public List<SearchDTO> getSearchDTOById(Long id) {
        return searchRepo.getCarOfferUtFromId(id);
    }

    @Override
    public String getCarById(Long id) {
        return carRepo.findCarById(id);
    }

    @Override
    public List<SearchDTO> getCarsInsideRange(String position, Long range) {
        List<SearchDTO> cars = searchRepo.getCars();
        List<SearchDTO> carsInsideRange = new ArrayList<>();
        String[] lat_lon = position.split(",");
        // latitude is lat_lon[0]
        // longitude is lat_lon[1]
        for (int i = 0; i < cars.size(); i++) {
            String zone = cars.get(i).getOffer().getZoneLocation();
            String[] car_lat_lon = zone.split(",");
            // distance(x,y) = ( (x1-y1)^2 + (x2-y2)^2 )^0.5
            double distance = Math.pow((Math.pow(Double.parseDouble(lat_lon[0]) - Double.parseDouble(car_lat_lon[0]), 2) + Math.pow(Double.parseDouble(lat_lon[1]) - Double.parseDouble(car_lat_lon[1]), 2)), 0.5);
            if (distance < range) {
                carsInsideRange.add(cars.get(i));
            }
        }
        return carsInsideRange;
    }
}
