package com.example.CarSearch.config;

import com.example.CarSearch.repository.SearchRepo;
import com.example.CarSearch.repository.SearchRepoImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
    @Bean
    public SearchRepo searchRepo() {
        return new SearchRepoImpl();
    }
}
