package com.example.CarSearch.service;

import com.example.CarSearch.model.*;
import com.example.CarSearch.repository.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class SearchServiceImplTest {
    @Mock
    private SearchRepo searchRepo;

    @Test
    @DisplayName("Should pass if a list of searchdto (car, offer and utilities) is returned")
    void shouldReturnTrueIfADTOIsReturned() {
        SearchServiceImpl ssi = new SearchServiceImpl(searchRepo);

        Car car = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", "nothing", "Roma", Car.Size.Small, 4L, Car.Engine.Electric, Car.Transmission.Automatic);

        Offer offer = new Offer(LocalDate.of(2020,10,10), LocalDate.of(2020,10,10), "10.5");

        Utilities ut = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");

        // this is the searchdto in input
        SearchDTO dto = new SearchDTO (car, offer, ut);
        // this is the expected result of the repository
        List<SearchDTO> expectedResponse = new ArrayList<>();
        expectedResponse.add(dto);

        Mockito.when(searchRepo.getCarOfferUtFromSearchDTO(ArgumentMatchers.any())).thenReturn(expectedResponse);

        List<SearchDTO> actualResponse = ssi.getCar(dto);

        Assertions.assertEquals(expectedResponse.get(0).getCar().getBrand(), actualResponse.get(0).getCar().getBrand());
        Assertions.assertEquals(expectedResponse.get(0).getCar().getEngine(), actualResponse.get(0).getCar().getEngine());
        Assertions.assertEquals(expectedResponse.get(0).getOffer().getPricePerDay(), actualResponse.get(0).getOffer().getPricePerDay());
        Assertions.assertEquals(expectedResponse.get(0).getOffer().getFromDate(), actualResponse.get(0).getOffer().getFromDate());
        Assertions.assertEquals(expectedResponse.get(0).getUtilities().getBluetooth(), actualResponse.get(0).getUtilities().getBluetooth());
        Assertions.assertEquals(expectedResponse.get(0).getUtilities().getDescription(), actualResponse.get(0).getUtilities().getDescription());
    }

    @Test
    @DisplayName("Should pass if null is returned")
    void shouldReturnNullIfNoDTOIsFound() {
        SearchServiceImpl ssi = new SearchServiceImpl(searchRepo);

        Car car = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", "nothing", "Roma", Car.Size.Small, 4L, Car.Engine.Electric, Car.Transmission.Automatic);

        Offer offer = new Offer(LocalDate.of(2020,10,10), LocalDate.of(2020,10,10), "10.5");

        Utilities ut = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");

        // this is the searchdto in input
        SearchDTO dto = new SearchDTO (car, offer, ut);
        // this is the expected result of the repository
        List<SearchDTO> expectedResponse = new ArrayList<>();

        Mockito.when(searchRepo.getCarOfferUtFromSearchDTO(ArgumentMatchers.any())).thenReturn(expectedResponse);

        List<SearchDTO> actualResponse = ssi.getCar(dto);

        Assertions.assertNull(actualResponse);
    }
}