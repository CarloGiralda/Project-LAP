package com.example.CarSearch.controller;

import com.example.CarSearch.model.*;
import com.example.CarSearch.service.SearchService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;
import java.util.ArrayList;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.isA;
import static org.mockito.Mockito.when;

@WebMvcTest(controllers = SearchController.class)
public class SearchControllerTest {
    @MockBean
    private SearchService searchService;
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void shouldPostCar() throws Exception {

        Car car = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", "nothing", "Roma", Car.Size.Small, 4L, Car.Engine.Electric, Car.Transmission.Automatic);
        Offer offer = new Offer(LocalDate.of(2020,10,10), LocalDate.of(2020,10,10), "10.5");
        Utilities ut = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");
        SearchDTO dto = new SearchDTO(car, offer, ut);

        ObjectMapper omdto = new ObjectMapper();
        omdto.findAndRegisterModules();
        String dtoAsString = omdto.writeValueAsString(dto);

        ArrayList<Car> cars = new ArrayList<>();
        cars.add(car);
        ArrayList<Offer> offers = new ArrayList<>();
        offers.add(offer);
        ArrayList<Utilities> uts = new ArrayList<>();
        uts.add(ut);
        ResponseDTO rdto = new ResponseDTO(cars, offers, uts);

        when(searchService.getCar(ArgumentMatchers.any())).thenReturn(rdto);

        mockMvc.perform(MockMvcRequestBuilders.post("/carsearch/searchbar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(dtoAsString))
                .andExpect(MockMvcResultMatchers.status().is(200))
                .andExpect(MockMvcResultMatchers.jsonPath("$.*", isA(ArrayList.class)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[*][*].plateNum", containsInAnyOrder("PK543WQ")))
                .andExpect(MockMvcResultMatchers.jsonPath("$[*][*].fromDate", containsInAnyOrder("2020-10-10")))
                .andExpect(MockMvcResultMatchers.jsonPath("$[*][*].airConditioning", containsInAnyOrder(true)));
    }
}
