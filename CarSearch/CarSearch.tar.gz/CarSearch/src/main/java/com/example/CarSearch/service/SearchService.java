package com.example.CarSearch.service;

import com.example.CarSearch.model.SearchDTO;

import java.util.List;

public interface SearchService {
    List<SearchDTO> getCar(SearchDTO dto);
    public List<SearchDTO> getSearchDTOById(Long id);
    String getCarById(Long id);
}
