package com.example.CarSearch.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ResponseDTO {
    private List<Car> cars;
    private List<Offer> offers;
    private List<Utilities> utilities;

    public ResponseDTO(List<Car> cars, List<Offer> offers, List<Utilities> utilities) {
        this.cars = cars;
        this.offers = offers;
        this.utilities = utilities;
    }

    public void addCar(Car car) { this.cars.add(car); }

    public void addOffer(Offer offer) { this.offers.add(offer); }

    public void addUtilities(Utilities utilities) { this.utilities.add(utilities); }
}
