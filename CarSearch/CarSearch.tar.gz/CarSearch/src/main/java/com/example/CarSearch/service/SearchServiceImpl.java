package com.example.CarSearch.service;

import com.example.CarSearch.model.*;
import com.example.CarSearch.repository.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SearchServiceImpl implements SearchService {
    private final SearchRepo searchRepo;
    private final CarRepo carRepo;

    public SearchServiceImpl(SearchRepo searchRepo, CarRepo carRepo) {
        this.searchRepo = searchRepo;
        this.carRepo = carRepo;
    }
    
    @Override
    public List<SearchDTO> getCar(SearchDTO dto) {
        List<SearchDTO> dtos = searchRepo.getCarOfferUtFromSearchDTO(dto);
        if (dtos.isEmpty()) {
            return null;
        }
        return dtos;
    }

    @Override
    public List<SearchDTO> getSearchDTOById(Long id) {
        return searchRepo.getCarOfferUtFromId(id);
    }

    @Override
    public String getCarById(Long id) {
        return carRepo.findCarById(id);
    }
}
