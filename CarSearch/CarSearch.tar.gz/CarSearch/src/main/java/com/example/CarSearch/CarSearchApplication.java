package com.example.CarSearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarSearchApplication.class, args);
	}

}
