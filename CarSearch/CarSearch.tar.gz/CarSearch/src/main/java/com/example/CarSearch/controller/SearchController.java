package com.example.CarSearch.controller;

import com.example.CarSearch.model.*;
import com.example.CarSearch.service.SearchService;
import jakarta.ws.rs.Path;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@RequestMapping(path = "/carsearch")
@RestController
public class SearchController {
    private SearchService searchService;

    public SearchController(SearchService searchService) {
        super();
        this.searchService = searchService;
    }

    @PostMapping(path = "/searchbar")
    public ResponseEntity<?> searchForm(@RequestBody SearchDTO sdto) {
        List<SearchDTO> cars = searchService.getCar(sdto);
        ArrayList<ReturnDTO> response = new ArrayList<>();
        for (SearchDTO car : cars) {
            response.add(new ReturnDTO(car.getCar().getCid(),
                    car.getCar().getBrand(),
                    car.getCar().getModel(),
                    car.getOffer().getPricePerDay()));
        }
        if (response != null) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping(path = "/getCarById/{id}")
    public ResponseEntity<?> getCarById(@PathVariable Long id) {
        List<SearchDTO> search = searchService.getSearchDTOById(id);
        if (search.size() != 1) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        SearchDTO response = search.get(0);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/getCarNameById/{id}")
    public ResponseEntity<?> returnName(@PathVariable Long id) {
        String car = searchService.getCarById(id);
        String[] names = car.split(",");
        String carName = names[0] + " model " + names[1];
        return new ResponseEntity<>(carName, HttpStatus.OK);
    }
}
