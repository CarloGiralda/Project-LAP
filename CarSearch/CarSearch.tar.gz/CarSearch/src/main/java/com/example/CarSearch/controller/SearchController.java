package com.example.CarSearch.controller;

import com.example.CarSearch.model.*;
import com.example.CarSearch.service.SearchService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RequestMapping(path = "/carsearch")
@RestController
public class SearchController {
    private SearchService searchService;

    public SearchController(SearchService searchService) {
        super();
        this.searchService = searchService;
    }

    @CrossOrigin(origins = {"http://localhost:8081", "http://localhost:8080"})
    @PostMapping(path = "/searchbar")
    // TODO insert ---@RequestHeader("Logged-In-User") String username---
    public ResponseEntity<?> searchForm(@RequestBody SearchDTO sdto) {
        ResponseDTO response = searchService.getCar(sdto);
        if (response != null) {
            ArrayList<List> list = new ArrayList<>();
            list.add(response.getCars());
            list.add(response.getOffers());
            list.add(response.getUtilities());
            return new ResponseEntity<>(list, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
