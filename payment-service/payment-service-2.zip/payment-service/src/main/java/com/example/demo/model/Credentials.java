package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "credentials")
public class Credentials {
    @Id
    private String username;
    @Column(length = 1024)
    private String publicKey;
    @Column(length = 1024)
    private String privateKey;
}
