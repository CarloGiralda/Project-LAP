package com.example.demo.service;

import com.example.demo.model.Credentials;
import com.example.demo.repository.CredentialsRepo;
import lombok.AllArgsConstructor;
import org.bouncycastle.util.encoders.Base64;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;

@Service
@AllArgsConstructor
public class PaymentService {
    private CredentialsRepo credentialsRepo;

    public Credentials retrieveCredentials(String username) {
        return credentialsRepo.findByUsername(username);
    }

    public String createSignature(String privKey, String data) throws NoSuchAlgorithmException, SignatureException, InvalidKeySpecException, InvalidKeyException, UnsupportedEncodingException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashedData = digest.digest(data.getBytes(StandardCharsets.UTF_8));

        String privateKeyPEM = privKey
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replaceAll(System.lineSeparator(), "")
                .replace("-----END PRIVATE KEY-----", "");

        byte[] keyBytes = Base64.decode(privateKeyPEM.getBytes("utf-8"));
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory fact = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = fact.generatePrivate(keySpec);

        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        signature.update(hashedData);
        byte[] signedHash = signature.sign();

        return Base64.toBase64String(signedHash);
    }
}
