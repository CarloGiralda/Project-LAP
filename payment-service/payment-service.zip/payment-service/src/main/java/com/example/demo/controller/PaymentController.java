package com.example.demo.controller;

import com.example.demo.dto.PaymentDTO;
import com.example.demo.model.Credentials;
import com.example.demo.model.Payment;
import com.example.demo.service.DiscoveryClientService;
import com.example.demo.service.PaymentService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;

@RestController
public class PaymentController {
    private PaymentService paymentService;
    @Autowired
    private DiscoveryClientService discoveryClientService;
    @Autowired
    private RestTemplate restTemplate;

    public PaymentController(PaymentService paymentService) {
        super();
        this.paymentService = paymentService;
    }

    @PostMapping(path = "/createTransaction")
    public ResponseEntity<?> insertTransaction(@RequestBody PaymentDTO paymentDTO) throws UnsupportedEncodingException, NoSuchAlgorithmException, SignatureException, InvalidKeySpecException, InvalidKeyException {
        Credentials sender = paymentService.retrieveCredentials(paymentDTO.getSender_username());
        Credentials receiver = paymentService.retrieveCredentials(paymentDTO.getReceiver_username());

        String signature = paymentService.createSignature(sender.getPrivate_key(), sender.getPublic_key() + receiver.getPublic_key() + paymentDTO.getPrice());

        Payment payment = new Payment(sender.getPublic_key(), receiver.getPublic_key(), paymentDTO.getPrice(), signature);

        String blockchainUrl = discoveryClientService.getServiceUrl("BLOCKCHAIN-SERVICE");
        String transactionUrl = blockchainUrl + "/blockchain/addTransaction";

        ResponseEntity<String> blockchainResponseEntity = restTemplate.postForEntity(transactionUrl, payment, String.class);
        if (blockchainResponseEntity.getStatusCode() != HttpStatus.OK){
            throw new RuntimeException("error, transaction has been refused");
        }
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }
}
