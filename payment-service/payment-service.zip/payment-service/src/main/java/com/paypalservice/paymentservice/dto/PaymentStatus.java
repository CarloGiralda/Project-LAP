package com.paypalservice.paymentservice.dto;

public enum PaymentStatus {
    SUCCESS,
    ERROR
}
