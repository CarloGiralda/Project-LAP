package com.paypalservice.paymentservice.controller;

import com.paypalservice.paymentservice.dto.CompletedOrder;
import com.paypalservice.paymentservice.dto.PaymentOrder;
import com.paypalservice.paymentservice.dto.PaymentStatus;
import com.paypalservice.paymentservice.service.PaypalService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@AllArgsConstructor
@RequestMapping(path = "/payment")
public class PaymentController {

    private PaypalService paypalService;

    @PostMapping(path = "/create")
    public ResponseEntity<?> createPayment(@RequestParam("amount") BigDecimal amount, @RequestHeader("Logged-In-User") String username){

        // TODO in the frontend code the payment response entity, also set the return url as a parameter

        PaymentOrder paymentOrder = paypalService.createPayment(amount);
        if (paymentOrder.getStatus() == PaymentStatus.SUCCESS) {

            return new ResponseEntity<>(paymentOrder, HttpStatus.OK);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("cannot create the payment");
        }
    }

    @PostMapping(path = "/execute")
    public ResponseEntity<?> completePayment(@RequestParam("token") String token) {
        CompletedOrder completedOrder = paypalService.completePayment(token);
        if (completedOrder.getStatus() == PaymentStatus.SUCCESS) {
            return new ResponseEntity<>(completedOrder, HttpStatus.OK);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("cannot execute the payment");

        }
    }
}
