INSERT INTO credentials(username, private_key, public_key) VALUES
    ('test1@gmail.com','test','test'),
    ('test2@gmail.com','test','test'),
    ('test3@gmail.com','test','test'),
    ('test4@gmail.com','test','test'),
    ('test5@gmail.com','test','test');
