function generateCarList() {
    const getUrl = "http://localhost:8080/carinsert/listcars?user=" + sessionStorage.getItem( "username" );
    const token = getCookie( "jwtToken" );

    console.log("sending list car request")
    fetch(getUrl, {
        method: 'GET',
        headers: {
            'Authorization': "Bearer " + token
        }
    })
        .then(function(response) {
            return response.json();
        })
        .then(function(body) {
            // TODO

            const cardContainer = document.getElementById( 'cardInsertedCarList' );

            console.log(body)
            for(let x= 0; x < body.length; x++) {

                const card = createCard(
                    String(body[x]["car"]["brand"]) + ' ' + String(body[x]["car"]["model"]),
                    ["Price: " + String(body[x]["offer"]["pricePerHour"]) + "$/hour"],
                    ["http://localhost:8081/carinsert/modify/" + body[x]["car"]["cid"]],
                    body[x]["car"]["image"]
                )
                cardContainer.appendChild(card);

            }

        });
}