package MACC.GUI.Gui;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CarBookController {

    @RequestMapping(path = "/start")
    public String start(){
        return "templates/CarBook/start";
    }
    @RequestMapping(path = "/book/{id}")
    public String reservation(@PathVariable String id){
        return "templates/CarBook/reservationForm";
    }
    @RequestMapping(path = "/extend")
    public String extendReservation(){
        return "templates/CarBook/extend";
    }
    @RequestMapping(path = "/show")
    public String show(){
        return "templates/CarBook/show";
    }
    @RequestMapping(path = "/showOffer")
    public String showOffer(){
        return "templates/CarBook/showOffer2";
    }
    @RequestMapping(path = "/bookings")
    public String bookings(){
        return "templates/CarBook/bookings";
    }
    @RequestMapping(path = "/bookingResult/{res}")
    public String successfulBooking(@PathVariable String res, Model model) {
        if (res.equals("success")) {
            model.addAttribute("successMessage", "SuccessMessage");
        } else {
            model.addAttribute("errorMessage", "");
        }
        return "templates/CarBook/successfulBooking";
    }
}
