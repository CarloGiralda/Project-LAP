let notificationWSUrl = 'http://localhost:8080/sockjs?user='
let notificationCount = 0

const notificationDropDown = document.getElementById('NotificationList')
const notificationBell = document.getElementById('notificationBell')
const bellLink = document.getElementById("bellLink")

// Reset notification count when user click on it
bellLink.addEventListener("click", function () {

    if (notificationCount > 0) {
        notificationCount = 0
        notificationBell.textContent = ""
        const noNotificationItem = document.getElementById('0')

        if (noNotificationItem){
            notificationDropDown.removeChild(noNotificationItem)
        }

    }
    const liElements = notificationDropDown.getElementsByTagName('li').length
    if(liElements === 0){

        addLiItem("No notification","NO_NOTIFICATION")
    }
})


document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const signupLink = document.getElementById('signupLink')
    const loginLink = document.getElementById('loginLink')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')
    const chatLink = document.getElementById('chatLink')
    const insert = document.getElementById('carInsertion')


    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && signupLink && loginLink && usernameDisplay) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        chatLink.style.display = 'block'
        insert.style.display = 'block'
        userDropDown.style.display = 'block'
        signupLink.style.display = 'none'
        loginLink.style.display = 'none'


        // you can now start a ws connection for notification
        wsNotificationConnect()
    
    }

});

function wsNotificationConnect() {
    const token = getCookie("jwtToken");

    const username = sessionStorage.getItem("username");
    const socket = new SockJS(notificationWSUrl + encodeURIComponent(username));
    const stompClient = Stomp.over(socket);


    // connect to the stomp endpoint
    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);
        //updateNotificationDisplay();
        stompClient.subscribe('/user/topic/car-notification', function (message) {
            let response = JSON.parse(message.body)
            //console.log(response.carId, response.carName)
            showMessage(response);
        });

    });
}

function showMessage(message) {

    if (notificationDropDown && notificationBell) {

        notificationCount += 1
        notificationBell.textContent = notificationCount

        addLiItem(message.carName + " now available")

    }

}

function addLiItem(content, type){

    const newLi = document.createElement('li');
    const newLink = document.createElement('a');

    if (type === 'NO_NOTIFICATION') {
        // first item is the only one with the id so that you can remove it
        newLi.id = '0'
    }

    newLink.className = 'dropdown-item bold-text'
    newLink.href = '#' // TODO add the link of the corresponding car using the id

    const textElem = document.createElement('b')
    textElem.innerText = content

    newLink.appendChild(textElem)
    newLi.appendChild(newLink)
    notificationDropDown.appendChild(newLi)

}
