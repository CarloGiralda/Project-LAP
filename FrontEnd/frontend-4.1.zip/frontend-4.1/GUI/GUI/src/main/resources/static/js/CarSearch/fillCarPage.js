function fillPage() {
    // take the id of the car from the url
    var url = window.location.href;
    var path = url.split( '/');
    var id = path[path.length - 1];

    var x = findNumberOfCarInSessionStorage(id);
    if (x === -1) {
        throw new DOMException();
    }

    // TODO check names
    // set the name of the car
    var brandmodel = document.getElementById("brandmodel");
    brandmodel.innerHTML = String(sessionStorage.getItem("List: " + x + " / Type: car / Field: brand")) + " model " + String(sessionStorage.getItem("List: " + x + " / Type: car / Field: model"));
    // set the description of the car
    var desc = document.getElementById("desc");
    desc.innerHTML = String("NOTHING FOR NOW");
    // set the dates for renting the car
    var td = document.getElementById("td");
    var fd = document.getElementById("fd");
    td.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: offer / Field: toDate"));
    fd.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: offer / Field: fromDate"));
    // set the rent price of the car
    var price = document.getElementById("price");
    price.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: offer / Field: pricePerDay"));
    // set the evaluation of the car
    var mean = computeStars();
    var stars = document.getElementById("stars");
    stars.innerHTML = mean;
    // set the number of reviews
    var revs = document.getElementById("reviews");
    revs.innerHTML = sessionStorage.getItem("NumberOfReviews");
    // set all other details
    var year = document.getElementById("year");
    var pl = document.getElementById("pl");
    var fuel = document.getElementById("fuel");
    var pass = document.getElementById("pass");
    var size = document.getElementById("size");
    var cdn = document.getElementById("cdn");
    var pos = document.getElementById("pos");
    var trans = document.getElementById("trans");
    var engine = document.getElementById("engine");
    var av = document.getElementById("available");
    var dis = document.getElementById("dis");
    var assis = document.getElementById("assis");
    var ac = document.getElementById("ac");
    var sas = document.getElementById("sas");
    var ns = document.getElementById("ns");
    var pa = document.getElementById("pa");
    var bt = document.getElementById("bt");
    var usb = document.getElementById("usb");
    var cd = document.getElementById("cd");
    var radio = document.getElementById("radio");
    var cc = document.getElementById("cc");
    var pc = document.getElementById("pc");
    var sa = document.getElementById("sa");
    year.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: car / Field: year"));
    pl.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: car / Field: pollutionLevel"));
    fuel.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: car / Field: fuel"));
    pass.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: car / Field: passengers"));
    size.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: car / Field: size"));
    cdn.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: car / Field: carDoorNumber"));
    pos.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: car / Field: position"));
    trans.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: car / Field: transmission"));
    engine.innerHTML += String(sessionStorage.getItem("List: " + x + " / Type: car / Field: engine"));
    if (String(sessionStorage.getItem("List: " + x + " / Type: offer / Field: available")) === true) {
        av.innerHTML = "Available";
    } else {
        av.innerHTML = "Not Available";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: display")) === true) {
        dis.innerHTML = "Display";
    }
    assis.innerHTML = String(sessionStorage.getItem("List: 2 / Type: utilities / Field: assistant"));
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: airConditioning")) === true) {
        ac.innerHTML = "Air Conditioning";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: startAndStop")) === true) {
        sas.innerHTML = "Start And Stop";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: navigationSystem")) === true) {
        ns.innerHTML = "Navigation System";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: parkingAssistant")) === true) {
        pa.innerHTML = "Parking Assistant";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: bluetooth")) === true) {
        bt.innerHTML = "Bluetooth";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: usbPorts")) === true) {
        usb.innerHTML = "USB Ports";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: cdPlayer")) === true) {
        cd.innerHTML = "CD Player";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: radioAMFM")) === true) {
        radio.innerHTML = "RadioAMFM";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: cruiseControl")) === true) {
        cc.innerHTML = "Cruise Control";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: parkingCamera")) === true) {
        pc.innerHTML = "Parking Camera";
    }
    if (String(sessionStorage.getItem("List: " + x + " / Type: utilities / Field: surroundAudio")) === true) {
        sa.innerHTML = "Surround Audio";
    }
}

function computeStars() {
    var nor = sessionStorage.getItem("NumberOfReviews");
    var sum = 0;
    for (let i = 0; i < nor; i++) {
        sum += sessionStorage.getItem(i + " / stars");
    }
    return sum / nor;
}

function findNumberOfCarInSessionStorage(id) {
    for (var x = 0; x < sessionStorage.getItem("NumberOfLists"); x++) {
        var cid = sessionStorage.getItem("List: " + x + " / Type: car / Field: cid");
        if (parseInt(cid) === parseInt(id)) {
            return x;
        }
    }
    return -1;
}