function chatRequest() {
    var token = getCookie("jwtToken");
    var username = sessionStorage.getItem("username")

    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/chat?sender=" + username, true);

    xhr.setRequestHeader('Authorization', "Bearer " + token)

    xhr.send();
}