//import API_ENDPOINTS from "../api";
// import {createPayment} from "./payment";
document.addEventListener("DOMContentLoaded", function () {
    
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')
    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        userDropDown.style.display = 'block'

        const path = window.location.href.split( '/' );
        //const id = path[path.length - 1];
        //console.log( id );

        console.log("setting username")
        document.getElementById( "username" ).value = sessionStorage.getItem( "username" );
        document.getElementById( "cid" ).value = path[path.length - 1];

    }


    document.getElementById('reservationForm').addEventListener( 'submit', function (event) {

        event.preventDefault(); // Prevent the default form submission
        console.log( "starting reservation..." )
        console.log( "creating payment" )

        // Store form data in session storage
        storeFormData()

        // TODO here insert payment process
        //createPayment()


        // TODO payment works but form is not submitted because in createPayment you are redirected to another page
        // TODO simple solution could be: invert submitForm with createPayment, another solution is store in the local storage the form data
        // Here you can add logic for form submission and checking if something went wrong
        console.log("submitting form")
        submitFormInSequence();

        /*createPayment()
        /*console.log(1+2)
        console.log(3.4)
        a = 5
        console.log(a-2)*/

    } );



});

/*const url = window.location.href;
const path = url.split( '/' );
const id = path[path.length - 1];
console.log(id);

document.getElementById("username").value = sessionStorage.getItem("username");
document.getElementById("cid").value = id;
const token = getCookie( "jwtToken" );*/


function showSuccessMessage() {
    document.getElementById( 'reservationForm' ).style.display = 'none';
    const successMessage = document.getElementById( 'successMessage' );
    successMessage.textContent = "Reservation completed";
    successMessage.style.color = 'green';
}

function showErrorMessage() {
    const successMessage = document.getElementById( 'errorMessage' );
    successMessage.textContent = "Reservation not completed";
    successMessage.style.color = 'red';
}

function storeFormData(){
    sessionStorage.setItem('cid', document.getElementById( "cid" ).value);
    sessionStorage.setItem('username', document.getElementById('username').value);
    sessionStorage.setItem('fromDate', document.getElementById('fromDate').value);
    sessionStorage.setItem('toDate',document.getElementById('toDate').value);
    sessionStorage.setItem('toDate',document.getElementById('fromH').value);
    sessionStorage.setItem('toH',document.getElementById('toH').value);
    sessionStorage.setItem('description',document.getElementById('description').value);
}

async function submitFormInSequence () {

    const token = getCookie( "jwtToken" );

    const cid = sessionStorage.getItem( "cid" );
    const username = sessionStorage.getItem( 'username' );
    const fromDate = sessionStorage.getItem( 'fromDate' );
    const toDate = sessionStorage.getItem( 'toDate' );
    const fromH = sessionStorage.getItem( 'fromH' );
    const toH = sessionStorage.getItem( 'toH' );
    const desc = sessionStorage.getItem( 'description' );
    const today = new Date();
    const yyyy = today.getFullYear();
    let mm = today.getMonth() + 1; // Months start at 0!
    let dd = today.getDate();

    if (dd < 10) dd = '0' + dd;
    if (mm < 10) mm = '0' + mm;

    const formattedToday = dd + '-' + mm + '-' + yyyy;

    const madeDate = formattedToday;

    const successUrl = "http://localhost:8081/start";

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Specify the request type (GET or POST), URL, and whether it should be asynchronous
    xhr.open( "POST", "http://localhost:8080/reservation/book", true );

    // Set the request header to indicate that we are sending JSON
    xhr.setRequestHeader( "Content-Type", "application/json" );
    xhr.setRequestHeader( 'Authorization', 'Bearer ' + token )
    console.log("authorization header:" + "Bearer " + token)

    // Define the JSON data to be sent
    const jsonData = {
        cid: cid,
        madeDate: madeDate,
        from: fromDate,
        to: toDate,
        fromH: fromH,
        toH: toH,
        username: username,
        flag: madeDate,
        desc: desc
        // Add more key-value pairs as needed
    };
    console.log( jsonData );

    // Convert the JSON data to a string
    const jsonDataString = JSON.stringify( jsonData );
    console.log( jsonDataString );

    console.log("sending authorization header with token " + token)
    // Set up a callback function to handle the response
    xhr.onreadystatechange = function () {
        // Check if the request is complete (readyState 4) and if the status is OK (status 200)
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Parse the response JSON
            setTimeout( function () {
                window.location.href = successUrl; // Change this to the desired page
            }, 3000 );
            window.location.href = successUrl;

            // Verify the result or do something with the response
            console.log( "Response:", response );
        } else {
            showErrorMessage();
        }
    };

    // Send the JSON data as the request payload
    xhr.send( jsonDataString );

}

const PaymentOrderDTO = {
    status: '',
    paymentId: '',
    redirectUrl: ''
};

// Create payment
function createPayment() {

    // TODO dummy price, should be retrieved from car search form
    const price = "10.0"

    const token = getCookie("jwtToken");

    // extract the username from the jwt token
    fetch("http://localhost:8080/payment/create?amount=" + price, {
        method: 'POST',
        headers: {
            'Authorization': "Bearer " + token
        }
    })
        .then(response => response.json())
        .then(response => {

            // create dto object to retrieve data from payment endpoint
            const paymentDTO = Object.create(PaymentOrderDTO)
            paymentDTO.status = response.status;
            paymentDTO.paymentId = response.paymentId;
            paymentDTO.redirectUrl = response.redirectUrl;


            console.log('Status:', paymentDTO.status);
            console.log('Payment ID:', paymentDTO.paymentId);
            console.log('Redirect URL:', paymentDTO.redirectUrl);


            // redirect to PayPal authentication page
            window.location.href = paymentDTO.redirectUrl;


        })
        .catch(error => console.log(error));

}

