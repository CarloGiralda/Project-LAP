import API_ENDPOINTS from "../api";
const PaymentOrderDTO = {
    status: '',
    paymentId: '',
    redirectUrl: ''
};

export function createPayment() {

    // TODO dummy price, should be retrieved from car search form
    const price = "10.0"

    const token = getCookie("jwtToken");

    // extract the username from the jwt token
    fetch(API_ENDPOINTS.createPayment + "?amount=" + price, {
        method: 'POST',
        headers: {
            'Authorization': "Bearer " + token
        }
    })
        .then(response => response.json())
        .then(response => {

            // create dto object to retrieve data from payment endpoint
            const paymentDTO = Object.create(PaymentOrderDTO)
            paymentDTO.status = response.status;
            paymentDTO.paymentId = response.paymentId;
            paymentDTO.redirectUrl = response.redirectUrl;


            console.log('Status:', paymentDTO.status);
            console.log('Payment ID:', paymentDTO.paymentId);
            console.log('Redirect URL:', paymentDTO.redirectUrl);


            // redirect to PayPal authentication page
            window.location.href = paymentDTO.redirectUrl;


        })
        .catch(error => console.log(error));

}