package MACC.GUI.Gui;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GuiController {
    @RequestMapping(path="/api/email")
    public String getConfirmationPage(){
        return "templates/Email/confirmationEmail.html";
    }
    @RequestMapping(path="api/userSettings")
    public String getUserSettingsPage(){
        return "templates/UserSettings/userSettings.html";
    }
    @RequestMapping(path="/pages")
    public String getSuccessPage(@Param("type") String type){
        return "templates/"+ type +".html";
    }
    @RequestMapping(path="api/recovery")
    public String getRecoveryPage() { return "templates/UserSettings/recovery.html"; }
    @RequestMapping(path="/searchbar")
    public String getOfferForm() { return "templates/CarSearch/form.html"; }
    @RequestMapping(path="/listcars")
    public String getOfferForm() { return "templates/CarSearch/cars.html"; }
    @RequestMapping(path="/insertoffer")
    public String getOfferForm() { return "templates/CarInsertion/offerForm.html"; }
    @RequestMapping(path="/insertcar")
    public String getOfferForm() { return "templates/CarInsertion/carForm.html"; }
    @RequestMapping(path="/insertutilities")
    public String getOfferForm() { return "templates/CarInsertion/utilitiesForm.html"; }
    @RequestMapping(path="/success")
    public String getOfferForm() { return "templates/CarInsertion/success.html"; }
    @RequestMapping(path="/failed")
    public String getOfferForm() { return "templates/CarInsertion/failed.html"; }
}
