// Function to perform the GET request
  function performGetRequest(receiverValue) {
      var senderValue = document.querySelector('#sender').textContent;
      console.log(receiverValue);
      window.location.assign('/chat/m?sender='+senderValue+'&receiver='+receiverValue);
  }
