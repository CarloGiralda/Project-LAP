package MACC.GUI.Gui;

import MACC.GUI.dto.CompletedOrder;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;


@Slf4j
@Controller
@RequestMapping(path = "/payment")
@AllArgsConstructor
public class PaymentController {


    // TODO delete
    private static final String paymentServiceUrl = "http://localhost:8080/payment/execute";

    private RestTemplate restTemplate;


    @RequestMapping(path="/capture")
    public String completePayment(@RequestParam("token") String token, Model model){
        log.info("received payment token: {}", token);

        // Set token as parameter
        MultiValueMap<String, String> requestMap = new LinkedMultiValueMap<>();
        requestMap.add("token", token);

        // Set headers if needed
        HttpHeaders headers = new HttpHeaders();

        // Create the request entity with headers and the request map
        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(requestMap, headers);

        // Send the POST request to your backend service
        ResponseEntity<CompletedOrder> responseEntity = restTemplate.postForEntity(paymentServiceUrl, requestEntity, CompletedOrder.class);

        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            log.info("payment executed: {}", Objects.requireNonNull(responseEntity.getBody()).getStatus());
            model.addAttribute("successMessage", "You've successfully booked your car");

        } else {
            log.info("error");
            model.addAttribute("errorMessage", "An error occurred, retry later");
        }

        // TODO here redirect to js to store car data

        return "/templates/CarBook/successfulBooking";
    }


    @RequestMapping(path="/cancel")
    public String cancelPayment(){

        return "templates/index";
    }


}
