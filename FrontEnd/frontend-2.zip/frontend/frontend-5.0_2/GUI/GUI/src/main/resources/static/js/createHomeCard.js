function createCard(title, content, href, image) {
    const card = document.createElement('div')
    const cardBody = document.createElement('div')

    card.className = 'card m-2';
    cardBody.className = 'card-body'

    card.style.width = '18rem';

    const cardTitle = document.createElement('h5');
    cardTitle.className = 'card-title';
    cardTitle.textContent = title;

    const cardContent = document.createElement('div');
    cardContent.className = 'card-content';

    // Iterate through the content array and create a <p> element for each line
    content.forEach(line => {
        const cardText = document.createElement('p');
        cardText.className = 'card-text';
        cardText.textContent = line;
        cardContent.appendChild(cardText);
    });

    const cardHref = document.createElement('div')


    href.forEach(line => {
        console.log("line: ",line)
        const cardLink = document.createElement('a');
        cardLink.className = 'btn btn-primary m-2';
        cardLink.href = line
        if (line.includes('extend')){
            cardLink.textContent = 'Extend';
        }
        if (line.includes('bookings')) {
            cardLink.textContent = 'Car page'
        }
        if (line.includes('carsearch')) {
            cardLink.textContent = 'Car details'
        }
        if (line.includes('carinsert')) {
            cardLink.textContent = 'Modify your car'
        }
        cardHref.appendChild(cardLink)

    })

    if (image != null){
        const imageElement = document.createElement("image");
        imageElement.src = "data:image/png;base64," + image;
        imageElement.className = "card-img-top"
        imageElement.alt = "car image here"
        card.appendChild(imageElement)
    }

    cardBody.appendChild(cardTitle);
    cardBody.appendChild(cardContent);
    cardBody.appendChild(cardHref);
    card.appendChild(cardBody)

    return card;
}
