/*
let stompClient = null;


// TODO
function wsNotificationConnect() {
    let socket = new SockJS('ws://localhost:8080/stomp-endpoint');
    stompClient = Stomp.over(socket);

    // connect to the stomp endpoint
    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);
        //updateNotificationDisplay();
        stompClient.subscribe('/user/topic/car-notification', function (message) {

            showMessage(JSON.parse(message.body).content);
        });

    });
}

function showMessage(message) {
    console.log(message)
    //$("#messages").append("<tr><td>" + message + "</td></tr>");
}

*/

/*
function updateNotificationDisplay() {
    if (notificationCount === 0) {
        $('#notifications').hide();
    } else {
        $('#notifications').show();
        $('#notifications').text(notificationCount);
    }
}

function resetNotificationCount() {
    notificationCount = 0;
    updateNotificationDisplay();
}*/
