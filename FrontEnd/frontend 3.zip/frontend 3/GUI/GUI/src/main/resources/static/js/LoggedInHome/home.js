import {getCookie} from '../utils/util.js'
document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const signupLink = document.getElementById('signupLink')
    const loginLink = document.getElementById('loginLink')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')

    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && signupLink && loginLink && usernameDisplay) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        userDropDown.style.display = 'block'
        signupLink.style.display = 'none'
        loginLink.style.display = 'none'
    }

});

function performGetRequest() {


    // Replace these URLs with the ones you want to use
    var getUrl = "http://localhost:8081/chat?sender="+sessionStorage.getItem("username");

    // Get cookie
    var token = getCookie("jwtToken");

    var xhr = new XMLHttpRequest();

    xhr.open("GET", getUrl, true);

    xhr.setRequestHeader('Authorization', "Bearer " + token)

    xhr.onload = function () {
        if (xhr.status === 200) {
            // Redirect to the success page
            console.log("SUCCESS");
        } else {
            console.log("FAILED");
        }
    };

    xhr.send();
}


// TODO getting all loggedIn user information to display on the page