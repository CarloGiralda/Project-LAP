function addMoreRows() {
    var rowsAdded = sessionStorage.getItem("NumberOfObjectsPerList");

    for(var x= 0; x < rowsAdded; x++) {
        var newRow = document.getElementById("table").insertRow();

        var newCell = newRow.insertCell();
        // Get only from the cars list (first list), number of object equal to x,
        // and then select the field
        var br = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: brand")
        newCell.innerHTML="<tr><td>" + br + "</td></tr>";

        newCell = newRow.insertCell();
        var mod = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: model")
        newCell.innerHTML="<tr><td>" + mod + "</td></tr>";

        newCell = newRow.insertCell();
        var engine = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: engine")
        newCell.innerHTML="<tr><td>" + engine + "</td></tr>";

        newCell = newRow.insertCell();
        var transmission = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: transmission")
        newCell.innerHTML="<tr><td>" + transmission + "</td></tr>";
    }
}