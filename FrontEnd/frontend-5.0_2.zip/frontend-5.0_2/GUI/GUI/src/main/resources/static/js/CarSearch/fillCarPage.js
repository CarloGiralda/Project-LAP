function fillPage() {
    // take the id of the car from the url
    var url = window.location.href;
    var path = url.split('/');
    var id = path[path.length - 1];

    var token = getCookie("jwtToken");
    var getUrl = "http://localhost:8080/carsearch/getCarById/" + id;

    var username = sessionStorage.getItem("username");
    var receiver;

    fetch(getUrl, {
        method: 'GET',
        headers: {
            'Authorization': "Bearer " + token
        },
    }).then(function(response) {
        return response.json();
    }).then(function(body) {
        // set the name of the car
        var brandmodel = document.getElementById("brandmodel");
        brandmodel.innerHTML = body["car"]["brand"] + " model " + body["car"]["model"];
        // set the description of the car
        var desc = document.getElementById("desc");
        desc.innerHTML = String("NOTHING FOR NOW");
        // set the dates for renting the car
        var td = document.getElementById("td");
        var fd = document.getElementById("fd");
        td.innerHTML += body["offer"]["toDate"];
        fd.innerHTML += body["offer"]["fromDate"];
        // set the rent price of the car
        var price = document.getElementById("price");
        price.innerHTML += body["offer"]["pricePerDay"];
        // set the evaluation of the car
        var mean = computeStars();
        var stars = document.getElementById("stars");
        stars.innerHTML = mean;
        // set the number of reviews
        var revs = document.getElementById("reviews");
        revs.innerHTML = sessionStorage.getItem("NumberOfReviews");
        // set all other details
        var year = document.getElementById("year");
        var pl = document.getElementById("pl");
        var fuel = document.getElementById("fuel");
        var pass = document.getElementById("pass");
        var size = document.getElementById("size");
        var cdn = document.getElementById("cdn");
        var pos = document.getElementById("pos");
        var trans = document.getElementById("trans");
        var engine = document.getElementById("engine");
        var av = document.getElementById("available");
        var dis = document.getElementById("dis");
        var assis = document.getElementById("assis");
        var ac = document.getElementById("ac");
        var sas = document.getElementById("sas");
        var ns = document.getElementById("ns");
        var pa = document.getElementById("pa");
        var bt = document.getElementById("bt");
        var usb = document.getElementById("usb");
        var cd = document.getElementById("cd");
        var radio = document.getElementById("radio");
        var cc = document.getElementById("cc");
        var pc = document.getElementById("pc");
        var sa = document.getElementById("sa");
        year.innerHTML += body["car"]["year"];
        pl.innerHTML += body["car"]["pollutionLevel"];
        fuel.innerHTML += body["car"]["fuel"];
        pass.innerHTML += body["car"]["passengers"];
        size.innerHTML += body["car"]["size"];
        cdn.innerHTML += body["car"]["carDoorNumber"];
        pos.innerHTML += body["car"]["position"];
        trans.innerHTML += body["car"]["transmission"];
        engine.innerHTML += body["car"]["engine"];
        if (body["offer"]["available"] === true) {
            av.innerHTML = "Available";
        } else {
            av.innerHTML = "Not Available";
        }
        if (body["utilities"]["display"] === true) {
            dis.innerHTML = "Display";
        }
        assis.innerHTML = body["utilities"]["assistant"];
        if (body["utilities"]["airConditioning"] === true) {
            ac.innerHTML = "Air Conditioning";
        }
        if (body["utilities"]["startAndStop"] === true) {
            sas.innerHTML = "Start And Stop";
        }
        if (body["utilities"]["navigationSystem"] === true) {
            ns.innerHTML = "Navigation System";
        }
        if (body["utilities"]["parkingAssistant"] === true) {
            pa.innerHTML = "Parking Assistant";
        }
        if (body["utilities"]["bluetooth"] === true) {
            bt.innerHTML = "Bluetooth";
        }
        if (body["utilities"]["usbPorts"] === true) {
            usb.innerHTML = "USB Ports";
        }
        if (body["utilities"]["cdPlayer"] === true) {
            cd.innerHTML = "CD Player";
        }
        if (body["utilities"]["radioAMFM"] === true) {
            radio.innerHTML = "RadioAMFM";
        }
        if (body["utilities"]["cruiseControl"] === true) {
            cc.innerHTML = "Cruise Control";
        }
        if (body["utilities"]["parkingCamera"] === true) {
            pc.innerHTML = "Parking Camera";
        }
        if (body["utilities"]["surroundAudio"] === true) {
            sa.innerHTML = "Surround Audio";
        }

        receiver = body["offer"]["renterUsername"];
    })

    /*
    var x = findNumberOfCarInSessionStorage(id);
    if (x === -1) {
        throw new DOMException();
    }
    */

    var rent = document.getElementById("rent")
    var chat = document.getElementById("chat")
    rent.addEventListener('click', function changePage(event) {
            window.location.href = "http://localhost:8081/book/" + id;
    })
    chat.addEventListener('click', function changePage(event) {
        window.location.href = "http://localhost:8081/chat/m?sender=" + username + "&receiver=" + receiver;
    })
}

function computeStars() {
    var nor = sessionStorage.getItem("NumberOfReviews");
    var sum = 0;
    for (let i = 0; i < nor; i++) {
        sum += sessionStorage.getItem(i + " / stars");
    }
    return sum / nor;
}
/*
function findNumberOfCarInSessionStorage(id) {
    for (var x = 0; x < sessionStorage.getItem("NumberOfLists"); x++) {
        var cid = sessionStorage.getItem("List: " + x + " / Type: car / Field: cid");
        if (parseInt(cid) === parseInt(id)) {
            return x;
        }
    }
    return -1;
}
*/