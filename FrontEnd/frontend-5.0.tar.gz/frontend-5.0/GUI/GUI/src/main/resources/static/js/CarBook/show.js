document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')

    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && usernameDisplay) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        userDropDown.style.display = 'block'
    }

});


document.getElementById("username").value = sessionStorage.getItem("username");//TODO


document.getElementById('myForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Here you can add logic for form submission and checking if something went wrong
        const response= submitFormInSequence();


});


    async function submitFormInSequence() {
          const username = document.getElementById('username').value;
          const flag = document.getElementById('flag').value;
          const filter = document.getElementById('filter').value;


          const successUrl="http://localhost:8081/bookings";

       // Create a new XMLHttpRequest object
       var xhr = new XMLHttpRequest();
       var token = getCookie("jwtToken");

       // Specify the request type (GET or POST), URL, and whether it should be asynchronous
       xhr.open("POST", "http://localhost:8080/reservation/listBookings", true);

       // Set the request header to indicate that we are sending JSON
       xhr.setRequestHeader("Content-Type", "application/json");
       xhr.setRequestHeader('Authorization', 'Bearer ' + token)
       // Define the JSON data to be sent
       const jsonData = {
         cid: filter,
         madeDate: filter,
         from: filter,
         to: filter,
         fromH: filter,
         toH: filter,
         username: username,
         flag: flag,
         desc: filter
         // Add more key-value pairs as needed
       };console.log(jsonData);

       // Convert the JSON data to a string
       const jsonDataString = JSON.stringify(jsonData);
       console.log(jsonDataString);

       // Set up a callback function to handle the response
       xhr.onreadystatechange = function () {
         // Check if the request is complete (readyState 4) and if the status is OK (status 200)
         if (xhr.readyState === 4 && xhr.status === 200) {
           // Parse the response JSON
           const body=xhr.responseText;

           console.log(body);

           var jsonData2 = JSON.parse(body);
           sessionStorage.setItem("NumberOfElements", jsonData2.length);
           console.log(jsonData2.length);
           for (var i = 0; i < jsonData2.length; i++) {
               sessionStorage.setItem("Number: " + i + " / Field: Offer Id", jsonData2[i].bid);
               sessionStorage.setItem("Number: " + i + " / Field: Car Id", jsonData2[i].cid);
               sessionStorage.setItem("Number: " + i + " / Field: Made Date", jsonData2[i].madeDate);
               sessionStorage.setItem("Number: " + i + " / Field: Username", jsonData2[i].username);
               sessionStorage.setItem("Number: " + i + " / Field: From Date", jsonData2[i].from);
               sessionStorage.setItem("Number: " + i + " / Field: To Date", jsonData2[i].to);
               sessionStorage.setItem("Number: " + i + " / Field: From Time", jsonData2[i].from_H);
               sessionStorage.setItem("Number: " + i + " / Field: To Time", jsonData2[i].to_H);
               sessionStorage.setItem("Number: " + i + " / Field: Description", jsonData2[i].desc);
           }

          window.location=successUrl;
         }
       };

       // Send the JSON data as the request payload
       xhr.send(jsonDataString);

    }


