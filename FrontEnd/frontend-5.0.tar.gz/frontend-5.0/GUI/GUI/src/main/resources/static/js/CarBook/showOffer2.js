document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')

    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && usernameDisplay) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        userDropDown.style.display = 'block'
    }

});

 var token = getCookie("jwtToken");

document.getElementById('myForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Here you can add logic for form submission and checking if something went wrong
        const response= fetchAndAddElement();


});
    async function fetchAndAddElement() {
       const cid = document.getElementById('cid').value;


       const successUrl="http://localhost:8081/start";
       const successUrl2="http://localhost:8081/book";

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Specify the request type (GET or POST), URL, and whether it should be asynchronous
    xhr.open("GET", "http://localhost:8080/reservation/showOfferCar?cid="+cid, true);

    xhr.setRequestHeader('Authorization', 'Bearer ' + token)

    // Set up a callback function to handle the response
    xhr.onreadystatechange = function () {
      // Check if the request is complete (readyState 4) and if the status is OK (status 200)
      if (xhr.readyState === 4 && xhr.status === 200) {
        // Parse the response JSON

        if(xhr.responseText=="available"){

            const existingContent = document.getElementById('existingContent');
            const row = document.createElement("tr");
                    row.innerHTML = `
                        <td>"Car is available"</td>
                    `;
                     existingContent.appendChild(row);
            setTimeout(function() {
                                           window.location.href = successUrl2; // Change this to the desired page
                                       }, 3000);
        }else{
        const response=xhr.responseText;
        const existingContent = document.getElementById('existingContent');
        const row = document.createElement("tr");
                row.innerHTML = `
                    <td>"Car not available; it will be available on this date:"+"${response}"</td>
                `;
        existingContent.appendChild(row);


        setTimeout(function() {
                       window.location.href = successUrl; // Change this to the desired page
                   }, 5000);

      }
      }
    };

    // Send the JSON data as the request payload
    xhr.send();

    }