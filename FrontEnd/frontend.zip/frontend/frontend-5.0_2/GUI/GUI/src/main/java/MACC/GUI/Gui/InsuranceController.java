package MACC.GUI.Gui;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
    public class InsuranceController {
    @RequestMapping(path = "/insurance")
    public String insurance(){
        return "templates/Insurance/insuranceForm";
    }
}
