document.addEventListener("DOMContentLoaded", function () {
    const isAuthenticated = document.cookie.includes('jwtToken')
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const usernameDisplay = document.getElementById('usernameDisplay')

    if (isAuthenticated) {
        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")
    }
});