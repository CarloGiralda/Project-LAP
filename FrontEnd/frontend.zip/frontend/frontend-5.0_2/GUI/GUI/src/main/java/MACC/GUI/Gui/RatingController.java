package MACC.GUI.Gui;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RatingController {
    @RequestMapping(path = "/rating/{id}")
    public String getUserRatingForm(@PathVariable String id) { return "templates/UserRating/userRatingForm"; }

    @RequestMapping(path = "/carrating/{id}")
    public String getCarRatingForm(@PathVariable String id) { return "templates/CarRating/carRatingForm"; }

}
