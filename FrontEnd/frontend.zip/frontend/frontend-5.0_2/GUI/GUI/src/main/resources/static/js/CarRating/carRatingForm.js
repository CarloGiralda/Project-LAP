function submitForm() {
    // take the car id from the url (it is inserted by the car-search service)
    var url = window.location.href;
    var path = url.split( '/');
    var car_id = path[path.length - 1];
    
    // Replace these URLs with the ones you want to use
    var postUrl = "http://localhost:8080/carrating/" + car_id;
    var successUrl = "http://localhost:8081/success";
    var problemUrl = "http://localhost:8081/failed";

    // Get form data
    var ev = sessionStorage.getItem("rating").replace(/"/gi, '');
    var token = getCookie("jwtToken");
    var date = document.getElementById("date").value;
    var desc = document.getElementById("desc").value;

    const params={
        stars: ev,
        date: date,
        description: desc,
        made_by: token,
        rating_on: car_id
    };

    var xhr = new XMLHttpRequest();

    xhr.open("POST", postUrl, true);

    xhr.setRequestHeader('Content-type', 'application/json')
    xhr.setRequestHeader('Authorization', "Bearer " + token)

    xhr.onload = function () {
        if (xhr.status === 200) {
            // Redirect to the success page
            window.location.href = successUrl;
        } else {
            window.location.href = problemUrl;
        }
    };

    xhr.send(JSON.stringify(params));
}