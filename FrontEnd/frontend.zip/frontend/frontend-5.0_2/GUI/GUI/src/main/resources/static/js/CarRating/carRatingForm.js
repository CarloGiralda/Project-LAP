
document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const signupLink = document.getElementById('signupLink')
    const loginLink = document.getElementById('loginLink')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')
    const chatLink = document.getElementById('chatLink')
    const insert = document.getElementById('carInsertion')
    const bell = document.getElementById('bellLink')
    const act = document.getElementById('activities')
    const welcome = document.getElementById('welcome')

    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && sessionStorage.getItem("username")) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        chatLink.style.display = 'block'
        insert.style.display = 'block'
        userDropDown.style.display = 'block'
        bell.style.display = 'block'
        act.style.display = 'block'
        welcome.style.display = 'none'
        signupLink.style.display = 'none'
        loginLink.style.display = 'none'



    } else {

        chatLink.style.display = 'none'
        insert.style.display = 'none'
        userDropDown.style.display = 'none'
        bell.style.display = 'none'
        act.style.display = 'none'
        welcome.style.display = 'block'
        signupLink.style.display = 'block'
        loginLink.style.display = 'block'
    }

});

function submitForm() {
    // take the car id from the url (it is inserted by the car-search service)
    var url = window.location.href;
    var path = url.split( '/');
    var car_id = path[path.length - 1];
    
    // Replace these URLs with the ones you want to use
    var postUrl = "http://localhost:8080/carrating/" + car_id;
    var successUrl = "http://localhost:8081/success";
    var problemUrl = "http://localhost:8081/failed";

    // Get form data
    var ev = sessionStorage.getItem("rating").replace(/"/gi, '');
    var token = getCookie("jwtToken");
    var date = document.getElementById("date").value;
    var desc = document.getElementById("desc").value;

    const params={
        stars: ev,
        date: date,
        description: desc,
        made_by: token,
        rating_on: car_id
    };

    var xhr = new XMLHttpRequest();

    xhr.open("POST", postUrl, true);

    xhr.setRequestHeader('Content-type', 'application/json')
    xhr.setRequestHeader('Authorization', "Bearer " + token)

    xhr.onload = function () {
        if (xhr.status === 200) {
            // Redirect to the success page
            window.location.href = successUrl;
        } else {
            window.location.href = problemUrl;
        }
    };

    xhr.send(JSON.stringify(params));
}