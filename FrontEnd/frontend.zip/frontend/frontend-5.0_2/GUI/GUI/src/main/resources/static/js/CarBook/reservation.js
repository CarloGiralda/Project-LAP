const userDropDown = document.getElementById('userDropDown')
const reservationForm = document.getElementById('reservationForm')
let errorMessage = document.querySelector(".alert-danger");
document.addEventListener("DOMContentLoaded", function () {

// Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const overlay = document.getElementById('overlay');
    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && sessionStorage.getItem("username")) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        userDropDown.style.display = 'block'

        const path = window.location.href.split( '/' );


        console.log("setting username")
        document.getElementById( "username" ).value = sessionStorage.getItem( "username" );
        document.getElementById( "cid" ).value = path[path.length - 1];

        // On load set car price TODO test
        document.getElementById("price").value = getPrice(document.getElementById("cid").value)



    } else {
        console.log("here")
        window.location.href = "http://localhost:8081/login"
    }

    function showOverlay() {
        overlay.classList.remove('d-none');
    }

    reservationForm.addEventListener( 'submit', (event) => {

        event.preventDefault(); // Prevent the default form submission
        console.log( "starting reservation..." )
        // show overlay on button click
        showOverlay()

        // Get form field values
        const username = document.getElementById( "username" ).value;
        const carCode = document.getElementById( "cid" ).value;
        const fromDate = document.getElementById( "fromDate" ).value;
        const toDate = document.getElementById( "toDate" ).value;
        const fromTime = document.getElementById( "fromH" ).value;
        const toTime = document.getElementById( "toH" ).value;
        const description = document.getElementById('descriptionInput').value;

        // Prepare form data
        const formData = new FormData();
        formData.append('username', username);
        formData.append('cid', carCode);
        formData.append('fromDate', fromDate);
        formData.append('toDate', toDate);
        formData.append('fromH', fromTime);
        formData.append('toH', toTime);
        formData.append('description', description);


        submitFormInSequence( formData ).then( r => {})
    });


});

function showErrorMessage(message) {
    errorMessage.style.display = "block";
    errorMessage.textContent = message;
}

async function submitFormInSequence (data) {

    const token = getCookie( "jwtToken" );
    const reservationUrl = "http://localhost:8080/reservation/book"

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Specify the request type (GET or POST), URL, and whether it should be asynchronous
    xhr.open( "POST", reservationUrl, true );

    // Set the request header and authentication header
    xhr.setRequestHeader( "Content-Type", "application/json" );
    xhr.setRequestHeader( 'Authorization', 'Bearer ' + token )
    console.log("authorization header:" + "Bearer " + token)

    const today = new Date();

    // format date
    const yyyy = today.getFullYear();
    let mm = today.getMonth() + 1; // Months start at 0!
    let dd = today.getDate();

    if (dd < 10) dd = '0' + dd;
    if (mm < 10) mm = '0' + mm;

    const formattedToday = dd + '-' + mm + '-' + yyyy;

    // Define the JSON data to be sent
    const jsonData = {
        cid: data.get('cid'),
        madeDate: formattedToday,
        fromDay: data.get('fromDate'),
        toDay: data.get('toDate'),
        fromHour: data.get('fromH'),
        toHour: data.get('toH'),
        username: data.get('username'),
        flag: formattedToday,
        description: data.get('description')
        // Add more key-value pairs as needed
    };
    console.log(jsonData);


    // Convert the JSON data to a string
    const jsonDataString = JSON.stringify( jsonData );
    console.log( jsonDataString );

    console.log("sending authorization header with token " + token)
    // Set up a callback function to handle the response
    xhr.onreadystatechange = async function () {

        // if car has been inserted correctly then starts creating PayPal payment
        if (xhr.readyState === 4 && xhr.status === 201) {
            console.log( "creating payment" )
            createPayment(document.getElementById("price").value)
        } else {
            showErrorMessage("Retry later, an error has occurred")
        }
    };
    // Send the JSON data as the request payload
    xhr.send(jsonDataString);

}



// TODO test
async function getPrice(carId){

    const searchUrl = "http://localhost:8080/carsearch/getPriceById/" + carId;
    console.log("here");


    return await fetch(searchUrl, {
        method: 'GET',

    }).then(function (response) {

         return response.json()
    })
        .then(data => {
        console.log(data);
            console.log("price for car: ", data.body)
            return data;
        })



}

// Create payment
function createPayment(price) {

    // Example usage
    const signature = document.getElementById("PrivateKey").value;
    const publicKey = document.getElementById( "PublicKey" ).value;
    const b_publicKey = document.getElementById( "BPublicKey" ).value;

    console.log("CHECKPOINT "+signature+""+publicKey+""+b_publicKey)

    // Concatenate sender, receiver, and payment
    const messageToSign = publicKey + b_publicKey + price;

    // Add the signature to the data object
    //const signature = signMessage(privateKey, messageToSign);

    const data = {
        sender: publicKey,
        receiver: b_publicKey,
        price: price,
        signature: signature
    };


    console.log(data);

    const token = getCookie("jwtToken");

    // extract the username from the jwt token
    fetch("http://localhost:8080/blockchain/addTransaction", {
        method: 'POST',
        headers: {
            'Content-Type': "application/json",
            'Authorization': "Bearer " + token
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())



}



