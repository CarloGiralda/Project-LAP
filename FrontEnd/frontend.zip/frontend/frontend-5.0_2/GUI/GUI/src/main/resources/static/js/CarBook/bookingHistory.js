document.addEventListener("DOMContentLoaded", function () {

    const isAuthenticated = document.cookie.includes('jwtToken')

    if (isAuthenticated) {
        const token = getCookie( "jwtToken" );
        const bookingUrl = "http://localhost:8080/reservation/listBookingsHistory"

        fetch( bookingUrl, {
            method: 'GET',
            headers: {
                'Authorization': "Bearer " + token
            },
        } ).then( response  => {
            if (response.status === 404) { // not found code
                const notFound = document.getElementById("notFound")
                notFound.style.display = "block"
                console.log("no reservation history")
            }
            if(response.status === 503) { // not available
                const notFound = document.getElementById("notFound")
                notFound.value = "service not available, retry later"
                console.log("service not available, retry later")
            }
            if (response.ok){
                return response.json();
            }

        })
            .then( response => {
                showHistory(response);
            })
    }


});



// create function to show card
/*function showHistory(bookings) {
    document.getElementById("card").innerText = "";

    for (let i = 0; i < bookings.length; i++) {
        document.getElementById("card").innerHTML += `
            <div class="col-md-4 mt-3">
                <div class="card p-3 ps-5 pe-5">
                    <h4 class="text-capitalize text-center mt-2">Booking id: ${bookings[i].bid}</h4>
                    <p class="mt-2">Car id: ${bookings[i].cid}</p>
                    <button type="button" class="btn btn-primary mt-2" onclick="fillExtendForm()" data-bs-toggle="modal" data-bs-target="#extendModal">Extend rent</button>
                </div>
            </div>
        `;
    }
}

function fillExtendForm(booking) {
    // Access the properties of the booking object and fill the modal with the data
    document.getElementById("bookingIdField").value = booking.bid;
    document.getElementById("carIdField").value = booking.cid;
    // Add other fields as needed
}*/

// Assume you have a container with the id "card" for the buttons
document.getElementById("card").addEventListener("click", function(event) {
    if (event.target && event.target.tagName === "BUTTON") {
        // If a button is clicked, extract the index and booking information from the button's data attributes
        const index = event.target.getAttribute("data-index");
        const bookingInfo = event.target.getAttribute("data-booking");

        // Call the fillExtendForm function with the extracted parameters
        fillExtendForm(index, bookingInfo);
    }
});

function showHistory(bookings) {
    document.getElementById("card").innerText = "";

    for (let i = 0; i < bookings.length; i++) {
        document.getElementById("card").innerHTML += `
            <div class="col-md-4 mt-3">
                <div class="card p-3 ps-5 pe-5">
                    <h4 class="text-capitalize text-center mt-2">Booking id: ${bookings[i].bid}</h4>
                    <p class="mt-2">Car id: ${bookings[i].cid}</p>
                    <button type="button" class="btn btn-primary mt-2" data-index="${i}" data-booking="${JSON.stringify(bookings[i]).replace(/"/g, '&quot;')}" data-bs-toggle="modal" data-bs-target="#extendModal">Extend rent</button>
                </div>
            </div>
        `;
    }
}

function fillExtendForm(index, booking) {
    // Parse the JSON string into an object
    booking = JSON.parse(booking);

    // Access the properties of the booking object and fill the modal with the data
    document.getElementById("user").value = sessionStorage.getItem("username");
    document.getElementById("cid").value = booking.cid;

    // Additional information about the click
    console.log("Clicked booking index:", index);
    // Add other fields as needed
}

