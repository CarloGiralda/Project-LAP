async function convertIntoname(zoneCoordinates) {

}