function generateCarList() {
    var getUrl = "http://localhost:8080/carinsert/listcars?user=" + sessionStorage.getItem("username");
    var token = getCookie("jwtToken");

    console.log("sending list car request")
    fetch(getUrl, {
        method: 'GET',
        headers: {
            'Authorization': "Bearer " + token
        }
    })
        .then(function(response) {
            return response.json();
        })
        .then(function(body) {
            // TODO
            //var carList = document.getElementById('carList');
            var carList = document.getElementById('cardInsertedCarList');

            var tab = document.createElement("table");
            for(var x= 0; x < body.length; x++) {

                var btn = document.createElement("button");
                btn.setAttribute("id",body[x]["car"]["cid"]);
                btn.setAttribute("class","btn btn-danger btn-block");
                const table = document.createElement("table");
                const tbody = document.createElement("tbody");
                const row_one = document.createElement("tr");
                const row_two = document.createElement("tr");
                const t = document.createTextNode(String(body[x]["car"]["brand"]) + " model " + String(body[x]["car"]["model"]));
                row_one.appendChild(t);
                const price = document.createTextNode("$" + String(body[x]["offer"]["pricePerHour"]));
                row_two.appendChild(price);
                tbody.appendChild(row_one);
                tbody.appendChild(row_two);
                table.appendChild(tbody);
                btn.appendChild(table);
                // in order to pass the param 'x' (number of the list from which we pick the correct car), the param is saved into a custom field customField of the button
                // it is accessed inside the function through the 'event' param (standard param for functions inside addEventListener)
                btn.customField = body[x]["car"]["cid"];
                btn.addEventListener('click', function changePage(event) {
                    window.location.href = "http://localhost:8081/carinsert/modify/" + event.currentTarget.customField;
                }, false);
                const row = document.createElement("tr");
                row.appendChild(btn);
                tab.appendChild(row);
            }
            carList.appendChild(tab);
            carList.style.marginLeft = '20px';
            carList.style.marginRight = '20px';
        });
}