document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')

    // TODO if insurance is already stored query it with it's title


    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && usernameDisplay) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        userDropDown.style.display = 'block'
    }

});


function submitForm() {
    // Replace these URLs with the ones you want to use
    const postUrl = "http://localhost:8080/email/upload-file";
    /*var successUrl = "http://localhost:8081/pages/?type=Upload/uploadSuccess";
    var problemUrl = "http://localhost:8081/pages/?type=Problem/problem";
    */
    // Get form data
    //let formData = new FormData(document.getElementById("myForm"));
    const fileInput = document.getElementById("file")
    let formData = new FormData();
    formData.append("file",fileInput.files[0])
    //let formData = document.getElementById( "file" ).value;


    console.log(formData)
    // Create a new XMLHttpRequest object
    let xhr = new XMLHttpRequest();

    const token = getCookie( "jwtToken" );

    // Set up the request
    xhr.open("POST", postUrl, true);
    xhr.setRequestHeader('Authorization', "Bearer " + token)

    // Define what happens on successful data submission
    xhr.onload = function () {
        if (xhr.status === 200) {
            showSuccessMessage()
            console.log("correctly uploaded")
            // Redirect to the success page
            //window.location.href = successUrl;
        }else{
            showErrorMessage()
            console.log("error")
            //window.location.href= problemUrl;
        }
    };

    // Send the form data
    xhr.send(formData);
}

function showSuccessMessage() {
    let successMessage = document.querySelector(".alert-info");
    let errorMessage = document.querySelector(".alert-danger");
    //hideOverlay(); // Hide the overlay when the registration is successful
    successMessage.style.display = "block";
    errorMessage.style.display = "none";
}

function showErrorMessage(message) {
    let successMessage = document.querySelector(".alert-info");
    let errorMessage = document.querySelector(".alert-danger");
    //hideOverlay(); // Hide the overlay when an error occurs
    successMessage.style.display = "none";
    errorMessage.style.display = "block";
    errorMessage.textContent = message;
}