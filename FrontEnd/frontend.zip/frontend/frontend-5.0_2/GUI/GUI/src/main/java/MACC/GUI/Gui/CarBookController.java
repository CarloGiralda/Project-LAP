package MACC.GUI.Gui;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CarBookController {


    @RequestMapping(path = "/book/{id}")
    public String reservation(@PathVariable String id){
        return "templates/CarBook/reservationForm";
    }
    @RequestMapping(path = "/extend")
    public String extendReservation(){
        return "templates/CarBook/extend";
    }

    @RequestMapping(path = "/bookingHistory")
    public String bookingHistory(){
        return "templates/CarBook/bookingHistory";
    }



}
