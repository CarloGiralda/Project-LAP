package MACC.GUI.Gui;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GuiController {
    @RequestMapping(path="/api/email")
    public String getConfirmationPage(){
        return "templates/Email/confirmationEmail";
    }
    @RequestMapping(path="/api/userSettings")
    public String getUserSettingsPage(){
        return "templates/UserSettings/userSettings";
    }
    @RequestMapping(path="/pages")
    public String getSuccessPage(@Param("type") String type){
        return "templates/"+ type;
    }
    @RequestMapping(path="/api/recovery")
    public String getRecoveryPage() { return "templates/UserSettings/recovery"; }
    @RequestMapping(path="/searchbar")
    public String getOfferForm() { return "templates/CarSearch/form"; }
    @RequestMapping(path="/listcars")
    public String getOfferForm2() { return "templates/CarSearch/cars"; }
    @RequestMapping(path="/insertoffer")
    public String getOfferForm3() { return "templates/CarInsertion/offerForm"; }
    @RequestMapping(path="/insertcar")
    public String getOfferForm4() { return "templates/CarInsertion/carForm"; }
    @RequestMapping(path="/insertutilities")
    public String getOfferForm5() { return "templates/CarInsertion/utilitiesForm"; }
    @RequestMapping(path="/success")
    public String getOfferForm6() { return "templates/CarInsertion/success"; }
    @RequestMapping(path="/failed")
    public String getOfferForm7() { return "templates/CarInsertion/failed"; }

    @RequestMapping(path="/registration")
    public String getRegistrationForm() { return "templates/UserAuthentication/registration"; }

}
