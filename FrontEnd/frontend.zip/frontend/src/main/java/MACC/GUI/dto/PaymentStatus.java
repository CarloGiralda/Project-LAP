package MACC.GUI.dto;

public enum PaymentStatus {
    SUCCESS,
    ERROR
}
