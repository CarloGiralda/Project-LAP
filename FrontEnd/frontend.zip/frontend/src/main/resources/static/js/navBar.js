let notificationWSUrl = 'http://localhost:8080/sockjs?user='

// TODO check how to reuse the WebSocket connection in the whole application to avoid duplicated code
function wsNotificationConnect() {
    const token = getCookie("jwtToken");

    const username = sessionStorage.getItem("username");
    const socket = new SockJS(notificationWSUrl + encodeURIComponent(username));
    const stompClient = Stomp.over(socket);


    // connect to the stomp endpoint
    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);
        //updateNotificationDisplay();
        stompClient.subscribe('/user/topic/car-notification', function (message) {
            let response = JSON.parse(message.body)
            //console.log(response.carId, response.carName)
            showMessage(response);
        });

    });
}

document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const signupLink = document.getElementById('signupLink')
    const loginLink = document.getElementById('loginLink')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')
    const chatLink = document.getElementById('chatLink')
    const insert = document.getElementById('carInsertion')
    const bell = document.getElementById('bellLink')

    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        chatLink.style.display = 'block'
        insert.style.display = 'block'
        userDropDown.style.display = 'block'
        bell.style.display = 'block'
        signupLink.style.display = 'none'
        loginLink.style.display = 'none'

        // you can now start a ws connection for notification
        wsNotificationConnect()

    } else {

        chatLink.style.display = 'none'
        insert.style.display = 'none'
        userDropDown.style.display = 'none'
        bell.style.display = 'none'
        signupLink.style.display = 'block'
        loginLink.style.display = 'block'
    }

});