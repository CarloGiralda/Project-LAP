/*
function addButtons() {
    var rowsAdded = sessionStorage.getItem("NumberOfLists");
    var cont = document.getElementById("list");

    var tab = document.createElement("table");
    for(var x= 0; x < rowsAdded; x++) {

        var btn = document.createElement("button");
        btn.setAttribute("id",sessionStorage.getItem("List: " + x + " / Field: cid"));
        btn.setAttribute("class","btn btn-danger btn-block");
        const table = document.createElement("table");
        const tbody = document.createElement("tbody");
        const row_one = document.createElement("tr");
        const row_two = document.createElement("tr");
        const t = document.createTextNode(String(sessionStorage.getItem("List: " + x + " / Field: brand")) + " model " + String(sessionStorage.getItem("List: " + x + " / Field: model")));
        row_one.appendChild(t);
        const price = document.createTextNode(String("$" + sessionStorage.getItem("List: " + x + " / Field: pricePerHour")));
        row_two.appendChild(price);
        tbody.appendChild(row_one);
        tbody.appendChild(row_two);
        table.appendChild(tbody);
        btn.appendChild(table);
        // in order to pass the param 'x' (number of the list from which we pick the correct car), the param is saved into a custom field customField of the button
        // it is accessed inside the function through the 'event' param (standard param for functions inside addEventListener)
        btn.customField = x;
        btn.addEventListener('click', function changePage(event) {
            var getUrl = "http://localhost:8080/carrating/" + sessionStorage.getItem("List: " + event.currentTarget.customField + " / Field: cid");
            var successUrl = "http://localhost:8081/carsearch/" + sessionStorage.getItem("List: " + event.currentTarget.customField + " / Field: cid");
            var problemUrl = "http://localhost:8081/failed";

            var token = getCookie("jwtToken");

            fetch(getUrl, {
                method: 'GET',
                headers: {
                    'Authorization': "Bearer " + token
                },
            })
                .then(function(response) {
                    return response.json();
                })
                .then(function(body) {
                    for (let x = 0; x < body.length; x++) {
                        sessionStorage.setItem(x + " / stars", body[x]["stars"]);
                        sessionStorage.setItem(x + " / date", body[x]["date"]);
                        sessionStorage.setItem(x + " / description", body[x]["description"]);
                        sessionStorage.setItem(x + " / madeByUser", body[x]["madeByUser"]);
                    }
                    sessionStorage.setItem("NumberOfReviews", body.length);
                })
                .then(function() {
                    window.location.href = successUrl;
                });
        }, false);
        const row = document.createElement("tr");
        row.appendChild(btn);
        tab.appendChild(row);
    }
    cont.appendChild(tab);
    cont.style.marginLeft = '20px';
    cont.style.marginRight = '20px';
}
*/

function addButtons() {
    var rowsAdded = sessionStorage.getItem("NumberOfLists");
    var cont = document.getElementById("list");

    var cardDeck = document.createElement("div");
    cardDeck.className = "card-deck";

    for (var x = 0; x < rowsAdded; x++) {
        var card = document.createElement("div");
        card.className = "card";

        var cardBody = document.createElement("div");
        cardBody.className = "card-body";

        var cardTitle = document.createElement("h5");
        cardTitle.className = "card-title";
        cardTitle.textContent = sessionStorage.getItem("List: " + x + " / Field: brand") + " model " + sessionStorage.getItem("List: " + x + " / Field: model");

        var cardText = document.createElement("p");
        cardText.className = "card-text";
        cardText.textContent = "$" + sessionStorage.getItem("List: " + x + " / Field: pricePerHour");

        cardBody.appendChild(cardTitle);
        cardBody.appendChild(cardText);

        var btn = document.createElement("button");
        btn.setAttribute("id", "btn_" + x);
        btn.setAttribute("class", "btn btn-danger btn-block");
        btn.textContent = "View Details";

        // Set custom data attribute to store the index 'x'
        btn.customField = x;

        btn.addEventListener('click', function changePage(event) {
            var getUrl = "http://localhost:8080/carrating/" + sessionStorage.getItem("List: " + event.currentTarget.customField + " / Field: cid");
            var successUrl = "http://localhost:8081/carsearch/" + sessionStorage.getItem("List: " + event.currentTarget.customField + " / Field: cid");

            var token = getCookie("jwtToken");

            fetch(getUrl, {
                method: 'GET',
                headers: {
                    'Authorization': "Bearer " + token
                },
            })
                .then(function(response) {
                    return response.json();
                })
                .then(function(body) {
                    for (let x = 0; x < body.length; x++) {
                        sessionStorage.setItem(x + " / stars", body[x]["stars"]);
                        sessionStorage.setItem(x + " / date", body[x]["date"]);
                        sessionStorage.setItem(x + " / description", body[x]["description"]);
                        sessionStorage.setItem(x + " / madeByUser", body[x]["madeByUser"]);
                    }
                    sessionStorage.setItem("NumberOfReviews", body.length);
                })
                .then(function() {
                    window.location.href = successUrl;
                });
        }, false);

        card.appendChild(cardBody);
        card.appendChild(btn);
        cardDeck.appendChild(card);
    }

    cont.appendChild(cardDeck);
    cont.style.marginLeft = '20px';
    cont.style.marginRight = '20px';
}
