package MACC.GUI.Gui;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;


@Controller
public class GuiController {
    @RequestMapping(path="/")
    public String getHome(){
        return "templates/index";
    }
    @RequestMapping(path="/api/email")
    public String getConfirmationPage(){
        return "templates/Email/confirmationEmail";
    }
    @RequestMapping(path="/pages")
    public String getSuccessPage(@Param("type") String type){
        return "templates/"+ type;
    }
    @RequestMapping(path="/searchbar")
    public String getOfferForm() { return "templates/CarSearch/form"; }
    @RequestMapping(path="/listcars")
    public String getOfferForm2() { return "templates/CarSearch/cars"; }
    @RequestMapping(path="/insertoffer")
    public String getOfferForm3() { return "templates/CarInsertion/offerForm"; }
    @RequestMapping(path="/insertcar")
    public String getOfferForm4() { return "templates/CarInsertion/carForm"; }
    @RequestMapping(path="/insertutilities")
    public String getOfferForm5() { return "templates/CarInsertion/utilitiesForm"; }
    @RequestMapping(path="/success")
    public String getOfferForm6() { return "templates/CarInsertion/success"; }
    @RequestMapping(path="/failed")
    public String getOfferForm7() { return "templates/CarInsertion/failed"; }
    @RequestMapping(path="/userSettings")
    public String getUserSettingsPage(){
        return "templates/UserSettings/userSettings";
    }
    @RequestMapping(path="/registration")
    public String getRegistrationForm() { return "templates/UserAuthentication/registration"; }
    @RequestMapping(path="/login")
    public String getLoginForm() { return "templates/UserAuthentication/login"; }
    @RequestMapping(path="/recovery")
    public String getRecoveryPage() { return "templates/UserSettings/recovery"; }
    @RequestMapping(path = "/chat", method = RequestMethod.GET)
    public String initChatsPage(Model model, @RequestParam String sender, @RequestHeader("Authorization") String loggedInUser)  {//TODO js to call here with cookie
        model.addAttribute("sender", sender);
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI("http://localhost:8080/chat?sender=" + sender))
                    .GET().header("Authorization",loggedInUser)
                    .build();
            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println(response.body());
            ObjectMapper mapper = new ObjectMapper();
            System.out.println(mapper.readValue(response.body(), new TypeReference<List<Object>>() {
            }));
            model.addAttribute("chats", mapper.readValue(response.body(), new TypeReference<List<Object>>(){}));
        }catch (Exception e){
            return "500 SERVER INTERNAL ERROR";
        }
        return "templates/Chat/formPage";}
    @RequestMapping(path = "/chat/m", method = RequestMethod.GET)
    public String messages(Model model,@RequestParam String sender,@RequestParam String receiver) {
        model.addAttribute("sender", sender);
        model.addAttribute("receiver", receiver);
        return "templates/Chat/chatIndex";}
    @RequestMapping(path = "/start")
    public String start(){
        return "templates/CarBook/start.html";
    }
    @RequestMapping(path = "/book")
    public String reservation(){
        return "templates/CarBook/reservationForm.html";
    }
    @RequestMapping(path = "/extend")
    public String extendReservation(){
        return "templates/CarBook/extend.html";
    }
    @RequestMapping(path = "/show")
    public String show(){
        return "templates/CarBook/show.html";
    }
    @RequestMapping(path = "/showOffer")
    public String showOffer(){
        return "templates/CarBook/showOffer2.html";
    }
    @RequestMapping(path = "/modifyOffer")
    public String modifyOffer(){
        return "templates/CarBook/showOffer.html";
    }
    @RequestMapping(path = "/bookings")
    public String bookings(){
        return "templates/CarBook/bookings.html";
    }

}
