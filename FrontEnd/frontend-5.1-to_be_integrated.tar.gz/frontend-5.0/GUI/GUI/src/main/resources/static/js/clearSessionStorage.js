function clearSessionStorage() {
    const temp = sessionStorage.getItem("username");
    sessionStorage.clear();
    sessionStorage.setItem("username", temp);
}