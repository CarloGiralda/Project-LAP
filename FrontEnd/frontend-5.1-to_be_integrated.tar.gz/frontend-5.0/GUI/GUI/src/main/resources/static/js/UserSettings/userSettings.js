document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')

    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && usernameDisplay) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        userDropDown.style.display = 'block'
    }

});


function submitForm() {
    // Replace these URLs with the ones you want to use
    var postUrl = "http://localhost:8081/api/userSettings/modify";
    var successUrl = "http://localhost:8081/pages/?type=UserSettings/userSettingsSuccess";
    var problemUrl = "http://localhost:8081/pages/?type=Problem/problem";

    // Get form data
    var e = document.getElementById("email").value;
    var fs = document.getElementById("firstName").value;
    var ls = document.getElementById("lastName").value;
    var r = document.getElementById("residence").value;
    var c = document.getElementById("contact").value;
    var p = document.getElementById("password").value;

    const params = {
        email: e,
        firstName: fs,
        lastName: ls,
        residence: r,
        password: p,
        contact: c
    };

    console.log(params)

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Set up the request
    xhr.open("POST", postUrl, true);


    xhr.setRequestHeader('Content-type', 'application/json')

    // Define what happens on successful data submission
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Redirect to the success page
            window.location.href = successUrl;
        } else {
            window.location.href = problemUrl;
        }
    };

    // Send the form data
    xhr.send(JSON.stringify(params)); // Make sure to stringify

}