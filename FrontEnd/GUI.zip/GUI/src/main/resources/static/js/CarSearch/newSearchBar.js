document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('search-button').addEventListener("click", async () => {
        var token = getCookie("jwtToken");
        // Replace these URLs with the ones you want to use
        var postUrl = "http://localhost:8080/carsearch/searchbar";
        var successUrl = "http://localhost:8081/listcars";

        // Get form data
        // checkboxes (false value means that the value was not selected, so turn it to null)
        var dis = document.getElementById("display").checked;
        if (dis === false) {
            dis = null;
        }
        var andr = document.getElementById("android").checked;
        if (andr === false) {
            andr = null;
        }
        var app = document.getElementById("apple").checked;
        if (app === false) {
            app = null;
        }
        var ac = document.getElementById("airconditioning").checked;
        if (ac === false) {
            ac = null;
        }
        var sas = document.getElementById("startandstop").checked;
        if (sas === false) {
            sas = null;
        }
        var ns = document.getElementById("navigationsystem").checked;
        if (ns === false) {
            ns = null;
        }
        var pa = document.getElementById("parkingassistant").checked;
        if (pa === false) {
            pa = null;
        }
        var bt = document.getElementById("bluetooth").checked;
        if (bt === false) {
            bt = null;
        }
        var usb = document.getElementById("usb").checked;
        if (usb === false) {
            usb = null;
        }
        var cd = document.getElementById("cd").checked;
        if (cd === false) {
            cd = null;
        }
        var radio = document.getElementById("radio").checked;
        if (radio === false) {
            radio = null;
        }
        var cc = document.getElementById("cruisecontrol").checked;
        if (cc === false) {
            cc = null;
        }
        var pc = document.getElementById("parkingcamera").checked;
        if (pc === false) {
            pc = null;
        }
        var sa = document.getElementById("surroundaudio").checked;
        if (sa === false) {
            sa = null;
        }
        var avail = document.getElementById("available").checked;
        if (avail === false) {
            avail = null;
        }
        // multi-option (if the empty value is selected, it means that it was not selected at all, so set it to null)
        var pl = document.getElementById("pollutionlevel").value;
        if (pl === "empty") {
            pl = null;
        }
        var fuel = document.getElementById("fuel").value;
        if (fuel === "empty") {
            fuel = null;
        }
        var trans = document.getElementById("transmission").value;
        if (trans === "empty") {
            trans = null;
        }
        var eng = document.getElementById("engine").value;
        if (eng === "empty") {
            eng = null;
        }
        var clas = document.getElementById("classification").value;
        if (clas === "empty") {
            clas = null;
        }
        // set the brand and the model to the search value (the split is done by the microservice)
        var brand = document.getElementById('search-input').value;
        var mod = document.getElementById('search-input').value;
        // set to null if they are empty strings (it means that their value was not set)
        var year = document.getElementById("year").value;
        if (year === '') {
            year = null;
        }
        var pass = document.getElementById("passengers").value;
        if (pass === '') {
            pass = null;
        }
        var cdn = document.getElementById("cardoornumber").value;
        if (cdn === '') {
            cdn = null;
        }
        var pph = document.getElementById("priceperhour").value;
        if (pph === '') {
            pph = null;
        }

        // conversion from date to epoch
        var fromdate = document.getElementById("fromdate").value;
        var fd = new Date(fromdate);
        fd = fd.getTime();

        // conversion from date to epoch
        var todate = document.getElementById("todate").value;
        var td = new Date(todate);
        td = td.getTime();

        // zone section
        var zone;
        if (document.getElementById("zone").value === '') {
            zone = null;
        } else {
            zone = document.getElementById("zone").value;

            // convert name into coordinates
            var getUrl = "http://localhost:8080/area/searchLocation?query=" + zone;

            await fetch(getUrl, {
                method: 'GET',
                headers: {
                    'Authorization': "Bearer " + token
                },
            })
                .then(function (response) {
                    return response.json();
                })
                .then(function (body) {
                    zone = String(body["lat"]) + "/" + String(body["lon"]);
                });
        }

        const params = {
            car: {
                year: year,
                pollutionLevel: pl,
                fuel: fuel,
                brand: brand,
                passengers: pass,
                classification: clas,
                carDoorNumber: cdn,
                transmission: trans,
                engine: eng,
                model: mod
            },
            offer: {
                available: avail,
                fromDate: fd,
                toDate: td,
                pricePerHour: pph,
                zoneLocation: zone
            },
            utilities: {
                display: dis,
                android: andr,
                apple: app,
                airConditioning: ac,
                startAndStop: sas,
                navigationSystem: ns,
                parkingAssistant: pa,
                bluetooth: bt,
                usbPorts: usb,
                cdPlayer: cd,
                radioAMFM: radio,
                cruiseControl: cc,
                parkingCamera: pc,
                surroundAudio: sa
            }
        };

        fetch(postUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(params)
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (body) {
                clearButtons()
                addButtons(body)
            })
    });
})

function addButtons(body) {
    var rowsAdded = body.length;
    var cont = document.getElementById("list");

    var cardDeck = document.createElement("div");
    cardDeck.className = "card-deck";

    for (var x = 0; x < rowsAdded; x++) {
        var card = document.createElement("div");
        card.className = "card";

        var cardBody = document.createElement("div");
        cardBody.className = "card-body";

        var cardTitle = document.createElement("h5");
        cardTitle.className = "card-title";
        cardTitle.textContent = body[x]["brand"] + " model " + body[x]["model"];

        var cardText = document.createElement("p");
        cardText.className = "card-text";
        cardText.textContent = "$" + body[x]["pricePerHour"];

        cardBody.appendChild(cardTitle);
        cardBody.appendChild(cardText);

        var btn = document.createElement("button");
        btn.setAttribute("id", "btn_" + x);
        btn.setAttribute("class", "btn btn-danger btn-block");
        btn.textContent = "View Details";

        // Set custom data attribute to store the index 'x'
        btn.customField = body[x]["cid"];

        btn.addEventListener('click', function changePage(event) {
            window.location.href = "http://localhost:8081/carsearch/" + event.currentTarget.customField;
        }, false);

        card.appendChild(cardBody);
        card.appendChild(btn);
        cardDeck.appendChild(card);
    }

    cont.appendChild(cardDeck);
    cont.style.marginLeft = '20px';
    cont.style.marginRight = '20px';
}

function clearButtons() {
    var cont = document.getElementById("list");
    cont.innerHTML = "";
}