document.addEventListener('DOMContentLoaded', () => {
    // Replace these URLs with the ones you want to use
    var postUrl = "http://localhost:8080/carsearch/search";
    var successUrl = "http://localhost:8081/listcars";

    document.getElementById('search-button').addEventListener("click", () => {
        const searchInput = document.getElementById('search-input').value;
        fetch(postUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: searchInput
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (body) {
                // delete session storage after saving the username, so that it can be inserted into it again
                const temp = sessionStorage.getItem("username");
                sessionStorage.clear();
                sessionStorage.setItem("username", temp);
                sessionStorage.setItem("NumberOfLists", body.length);
                for (let x = 0; x < body.length; x++) {
                    for (let y in body[x]) {
                        sessionStorage.setItem("List: " + x + " / Field: " + y, body[x][y]);
                    }
                }
            })
            .then(function () {
                window.location.href = successUrl;
            })
            // catch the 404 status code, that means that no car matches the parameters
            .catch(function (err) {
                const temp = sessionStorage.getItem("username");
                sessionStorage.clear();
                sessionStorage.setItem("username", temp);
                window.location.href = successUrl;
            });
    });
})
