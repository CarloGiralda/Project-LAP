package MACC.GUI.Gui;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GuiController {
    @RequestMapping(path="/api/email")
    public String getConfirmationPage(){
        return "templates/Email/confirmationEmail.html";
    }
    @RequestMapping(path="api/userSettings")
    public String getUserSettingsPage(){
        return "templates/UserSettings/userSettings.html";
    }
    @RequestMapping(path="/pages")
    public String getSuccessPage(@Param("type") String type){
        return "templates/"+ type +".html";
    }
    @RequestMapping(path="api/recovery")
    public String getRecoveryPage(){
        return "templates/UserSettings/recovery.html";}
}
