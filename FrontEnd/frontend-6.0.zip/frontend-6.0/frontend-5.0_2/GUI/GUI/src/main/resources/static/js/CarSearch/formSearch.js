function submitForm() {
    // Replace these URLs with the ones you want to use
    var postUrl = "http://localhost:8080/carsearch/searchbar";
    var successUrl = "http://localhost:8081/listcars";
    var problemUrl = "http://localhost:8081/failed";

    // Get form data
    var dis = document.getElementById("display").checked;
    var assis = document.getElementById("assistant").value;
    var ac = document.getElementById("airconditioning").checked;
    var sas = document.getElementById("startandstop").checked;
    var ns = document.getElementById("navigationsystem").checked;
    var pa = document.getElementById("parkingassistant").checked;
    var bt = document.getElementById("bluetooth").checked;
    var usb = document.getElementById("usb").checked;
    var cd = document.getElementById("cd").checked;
    var radio = document.getElementById("radio").checked;
    var cc = document.getElementById("cruisecontrol").checked;
    var pc = document.getElementById("parkingcamera").checked;
    var sa = document.getElementById("surroundaudio").checked;
    var year = document.getElementById("year").value;
    var pl = document.getElementById("pollutionlevel").value;
    var fuel = document.getElementById("fuel").value;
    var brand;
    if (document.getElementById("brand").value === '') {
        brand = null;
    } else {
        brand = document.getElementById("brand").value;
    }
    var pass;
    if (document.getElementById("passengers").value === '') {
        pass = null;
    } else {
        pass = document.getElementById("passengers").value;
    }
    var clas = document.getElementById("classification").value;
    var cdn;
    if (document.getElementById("cardoornumber").value === '') {
        cdn = null;
    } else {
        cdn = document.getElementById("cardoornumber").value;
    }
    var trans = document.getElementById("transmission").value;
    var eng = document.getElementById("engine").value;
    var mod;
    if (document.getElementById("model").value === '') {
        mod = null;
    } else {
        mod = document.getElementById("model").value;
    }
    var avail = document.getElementById("available").checked;

    // conversion from date to epoch
    var fromdate = document.getElementById("fromdate").value;
    var fd = new Date(fromdate);
    fd = fd.getTime();

    // conversion from date to epoch
    var todate = document.getElementById("todate").value;
    var td = new Date(todate);
    td = td.getTime();

    var pph;
    if (document.getElementById("priceperhour").value === '') {
        pph = null;
    } else {
        pph = document.getElementById("priceperhour").value;
    }
    var zone;
    if (document.getElementById("zone").value === '') {
        zone = null;
    } else {
        zone = document.getElementById("zone").value;
    }

    const params={
        car: {
            year: year,
            pollutionLevel: pl,
            fuel: fuel,
            brand: brand,
            passengers: pass,
            classification: clas,
            carDoorNumber: cdn,
            transmission: trans,
            engine: eng,
            model: mod
        },
        offer: {
            available: avail,
            fromDate: fd,
            toDate: td,
            pricePerHour: pph,
            zoneLocation: zone
        },
        utilities: {
            display: dis,
            assistant: assis,
            airConditioning: ac,
            startAndStop: sas,
            navigationSystem: ns,
            parkingAssistant: pa,
            bluetooth: bt,
            USBPorts: usb,
            CDPlayer: cd,
            radioAMFM: radio,
            cruiseControl: cc,
            parkingCamera: pc,
            surroundAudio: sa
        }
    };

    fetch(postUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
    })
        .then(function(response) {
            return response.json();
        })
        .then(function(body) {
            // delete session storage after saving the username, so that it can be inserted into it again
            const temp = sessionStorage.getItem("username");
            sessionStorage.clear();
            sessionStorage.setItem("username", temp);
            sessionStorage.setItem("NumberOfLists", body.length);
            for (let x = 0; x < body.length; x++) {
                for (let y in body[x]) {
                    sessionStorage.setItem("List: " + x + " / Field: " + y, body[x][y]);
                }
            }
        })
        .then(function() {
            window.location.href = successUrl;
        })
        // catch the 404 status code, that means that no car matches the parameters
        .catch(function(err) {
            const temp = sessionStorage.getItem("username");
            sessionStorage.clear();
            sessionStorage.setItem("username", temp);
            window.location.href = successUrl;
        });
}