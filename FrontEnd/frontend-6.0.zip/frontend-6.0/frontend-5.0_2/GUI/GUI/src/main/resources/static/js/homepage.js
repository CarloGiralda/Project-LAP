let notificationWSUrl = 'http://localhost:8080/sockjs?user='
let notificationCount = 0

const notificationDropDown = document.getElementById('NotificationList')
const notificationBell = document.getElementById('notificationBell')
const bellLink = document.getElementById("bellLink")

// Reset notification count when user click on it
bellLink.addEventListener("click", function () {

    if (notificationCount > 0) {
        notificationCount = 0
        notificationBell.textContent = ""
        const noNotificationItem = document.getElementById('0')

        if (noNotificationItem){
            notificationDropDown.removeChild(noNotificationItem)
        }

    }
    const liElements = notificationDropDown.getElementsByTagName('li').length
    if(liElements === 0){

        addLiItem("No notification","NO_NOTIFICATION")
    }
})


document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const signupLink = document.getElementById('signupLink')
    const loginLink = document.getElementById('loginLink')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')
    const chatLink = document.getElementById('chatLink')
    const insert = document.getElementById('carInsertion')
    const bell = document.getElementById('bellLink')
    const act = document.getElementById('activities')
    const welcome = document.getElementById('welcome')

    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && sessionStorage.getItem("username")) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        chatLink.style.display = 'block'
        insert.style.display = 'block'
        userDropDown.style.display = 'block'
        bell.style.display = 'block'
        act.style.display = 'block'
        welcome.style.display = 'none'
        signupLink.style.display = 'none'
        loginLink.style.display = 'none'

        const token = getCookie("jwtToken");
        Promise.all([
            getSubscribedCars(token),
            getReservations(token),
            new Promise(resolve => wsNotificationConnect(resolve)) // Assuming wsNotificationConnect accepts a callback to signal completion
        ]).then(() => {
            console.log("All asynchronous functions executed successfully.");
        }).catch(error => {
            console.error("Error in one of the asynchronous functions:", error);
        });

    
    } else {

        chatLink.style.display = 'none'
        insert.style.display = 'none'
        userDropDown.style.display = 'none'
        bell.style.display = 'none'
        act.style.display = 'none'
        welcome.style.display = 'block'
        signupLink.style.display = 'block'
        loginLink.style.display = 'block'
    }

});

function wsNotificationConnect() {
    const token = getCookie("jwtToken");

    const username = sessionStorage.getItem("username");
    const socket = new SockJS(notificationWSUrl + encodeURIComponent(username));
    const stompClient = Stomp.over(socket);


    // connect to the stomp endpoint
    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);
        //updateNotificationDisplay();
        stompClient.subscribe('/user/topic/car-notification', function (message) {
            let response = JSON.parse(message.body)
            //console.log(response.carId, response.carName)
            showMessage(response);
        });

    });
}

function showMessage(message) {

    if (notificationDropDown && notificationBell) {

        notificationCount += 1
        notificationBell.textContent = notificationCount

        addLiItem(message.carName + " now available", message.carUrl)

    }

}

function addLiItem(content, link, type){

    const newLi = document.createElement('li');
    const newLink = document.createElement('a');

    if (type === 'NO_NOTIFICATION') {
        // first item is the only one with the id so that you can remove it
        newLi.id = '0'
    }

    newLink.className = 'dropdown-item bold-text'
    newLink.href = link

    const textElem = document.createElement('b')
    textElem.innerText = content

    newLink.appendChild(textElem)
    newLi.appendChild(newLink)
    notificationDropDown.appendChild(newLi)

}

const CarPreviewDTO = {
    brand: '',
    model: '',
    engine: '',
    year: ''
};

const BookingPreviewDTO = {
    bid: '',
    cid: '',
    fromDay: '',
    toDay: '',
    madeDate: ''
}

function getReservations(token){
    const bookingUrl = "http://localhost:8080/reservation/listBookingsPreview"
    const cardContainer = document.getElementById('cardReservationsList');

    fetch(bookingUrl, {
        method: 'GET',
        headers: {
            'Authorization': "Bearer " + token
        },
    })
        .then(response => {
            if (response.status === 404) { // not found code
                let card = createNoElement("You have no reservation")
                cardContainer.appendChild(card)
                console.log("no reservations")
                //throw new Error("no reservation");
            }
            if(response.status === 503) { // not available
                let card = createNoElement("service not available retry later")
                cardContainer.appendChild(card)
                console.log("service not available, retry later")
            }
            if (response.ok){
                return response.json();
            }

        })
        .then(response => {
            // for each of these car we have to perform a request to get car preview
            console.log("response:",response)

            for (let i = 0; i < response.length; i++) {

                const bookingPreview = Object.create(BookingPreviewDTO)
                BookingPreviewDTO.bid = response[i].bid
                BookingPreviewDTO.cid = response[i].cid
                BookingPreviewDTO.fromDay = response[i].fromDay
                BookingPreviewDTO.toDay = response[i].toDay
                BookingPreviewDTO.madeDate = response[i].madeDate

                const card = createCard(
                    'Booking code: ' + BookingPreviewDTO.bid.toString(),
                    [
                        'Car id: ' + BookingPreviewDTO.cid.toString(),
                        'Pick-up date: ' + BookingPreviewDTO.fromDay,
                        'Drop-off date: ' + BookingPreviewDTO.toDay,
                        'Made date: ' + BookingPreviewDTO.madeDate
                    ],
                    ['http://localhost:8081/bookings','http://localhost:8081/extend']
                );
                cardContainer.appendChild(card);

            }
        })
        .catch(error => console.log(error));

}

function getSubscribedCars(token) {
    const carBookUrl = "http://localhost:8080/subscription/getCarsForUser/" + sessionStorage.getItem("username")
    const carSearchUrl = "http://localhost:8080/carsearch/getCarPreviewById/"
    const cardContainer = document.getElementById('cardSubscriptionList');

    fetch(carBookUrl, {
        method: 'GET',
        headers: {
            'Authorization': "Bearer " + token
        },
    })
        .then(response => {
            if (response.status === 404) { // not found
                let card = createNoElement("You are not subscribed for a car")
                cardContainer.appendChild(card)
                console.log("no subscribed car")
            }
            if(response.status === 503) { // not available
                let card = createNoElement("service not available retry later")
                cardContainer.appendChild(card)
                console.log("service not available, retry later")
            }
            if (response.ok){
                return response.json()
            }
        })
        .then(response => {
            // for each of these car we have to perform a request to get car preview
            console.log(response)

            for (let i = 0; i < response.length; i++) {
                console.log("carId:",i + 1)
                // perform request
                let carId = i + 1
                fetch( carSearchUrl + carId, {
                    method: 'GET'
                }).then(  response => response.json())
                    .then(response => {
                        const carPreview = Object.create(CarPreviewDTO)
                        carPreview.brand = response.brand
                        carPreview.model = response.model
                        carPreview.engine = response.engine
                        carPreview.year = response.year
                        console.log(carPreview.brand,carPreview.model,carPreview.engine)

                        const card = createCard(
                            carPreview.brand + ' ' + carPreview.model,
                            ['Engine: ' + carPreview.engine, 'Year: ' + carPreview.year],
                                ['http://localhost:8081/carsearch/' + carId]
                        );
                        cardContainer.appendChild(card);

                        // TODO get the data and create new cards with this data
                    }).catch(error => console.log(error));
            }
        })
        .catch(error => console.log(error));
}


function createNoElement(content){
    const card = document.createElement('div');
    card.className = 'card card-body m-2';

    const element = document.createElement('div')
    const hElement = document.createElement('h5')
    hElement.textContent = content

    element.appendChild(hElement)
    card.appendChild(element)

    return card
}

function createCard(title, content, href) {
    const card = document.createElement('div');
    card.className = 'card card-body m-2';

    card.style.width = '50px';

    const cardTitle = document.createElement('h5');
    cardTitle.className = 'card-title';
    cardTitle.textContent = title;

    const cardContent = document.createElement('div');
    cardContent.className = 'card-content';



    // Iterate through the content array and create a <p> element for each line
    content.forEach(line => {
        const cardText = document.createElement('p');
        cardText.className = 'card-text';
        cardText.textContent = line;
        cardContent.appendChild(cardText);
    });

    const cardHref = document.createElement('div')


    href.forEach(line => {
        console.log("line: ",line)
        const cardLink = document.createElement('a');
        cardLink.className = 'btn btn-primary m-2';
        cardLink.href = line
        if (line.includes('extend')){
            cardLink.textContent = 'Extend';
        }
        if (line.includes('bookings')) {
            cardLink.textContent = 'Bookings'
        }
        if (line.includes('carsearch')) {
            cardLink.textContent = 'Car details'
        }
        cardHref.appendChild(cardLink)

    })

    /*const cardLink = document.createElement('a');
    cardLink.href = href;
    cardLink.className = 'btn btn-primary';
    cardLink.textContent = 'Car details';
*/
    card.appendChild(cardTitle);
    card.appendChild(cardContent);
    card.appendChild(cardHref);

    return card;
}

