let registrationEndpoint = "http://localhost:8080/auth/register"
let registrationForm = document.getElementById("registrationForm");
console.log("Element:", registrationForm);

registrationForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const formData = new FormData(registrationForm);
    const data = Object.fromEntries(formData);
    console.log(data)

    let testEndPoint = "https://reqres.in/api/users";

    fetch(registrationEndpoint,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    }).then(res => res.json())
        .then(data => console.log(data))
        .catch(error => console.log(error))

});