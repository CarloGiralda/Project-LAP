function submitForm() {
    // take the renter name from the url (it is inserted by the car-book service when you click on one
    var url = window.location.href;
    var path = url.split( '/');
    var renter_id = path[path.length - 1];
    
    // Replace these URLs with the ones you want to use
    var postUrl = "http://localhost:8080/rating/" + renter_id;
    var successUrl = "http://localhost:8081/success";
    var problemUrl = "http://localhost:8081/failed";

    // Get form data
    var ev = sessionStorage.getItem("rating").replace(/"/gi, '');
    console.log(ev)
    var token = getCookie("jwtToken");
    var date = document.getElementById("date").value;
    var desc = document.getElementById("desc").value;

    const params={
        stars: ev,
        date: date,
        description: desc,
        made_by: token,
        rating_on: renter_id
    };

    console.log(params)

    var xhr = new XMLHttpRequest();

    xhr.open("POST", postUrl, true);

    xhr.setRequestHeader('Content-type', 'application/json')
    xhr.setRequestHeader('Authorization', "Bearer " + token)

    xhr.onload = function () {
        if (xhr.status === 200) {
            // Redirect to the success page
            window.location.href = successUrl;
        } else {
            window.location.href = problemUrl;
        }
    };

    xhr.send(JSON.stringify(params));
}

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}