function submitForm() {
    // Replace these URLs with the ones you want to use
    var postUrl = "http://localhost:8080/carsearch/searchbar";
    var successUrl = "http://localhost:8081/listcars";
    var problemUrl = "http://localhost:8081/failed";

    // Get form data
    var dis = document.getElementById("display").checked;
    var assis = document.getElementById("assistant").value;
    var ac = document.getElementById("airconditioning").checked;
    var sas = document.getElementById("startandstop").checked;
    var ns = document.getElementById("navigationsystem").checked;
    var pa = document.getElementById("parkingassistant").checked;
    var bt = document.getElementById("bluetooth").checked;
    var usb = document.getElementById("usb").checked;
    var cd = document.getElementById("cd").checked;
    var radio = document.getElementById("radio").checked;
    var cc = document.getElementById("cruisecontrol").checked;
    var pc = document.getElementById("parkingcamera").checked;
    var sa = document.getElementById("surroundaudio").checked;
    var year = document.getElementById("year").value;
    var pl = document.getElementById("pollutionlevel").value;
    var fuel = document.getElementById("fuel").value;
    var brand;
    if (document.getElementById("brand").value === '') {
        brand = null;
    } else {
        brand = document.getElementById("brand").value;
    }
    var pass;
    if (document.getElementById("passengers").value === '') {
        pass = null;
    } else {
        pass = document.getElementById("passengers").value;
    }
    var size = document.getElementById("size").value;
    var cdn;
    if (document.getElementById("cardoornumber").value === '') {
        cdn = null;
    } else {
        cdn = document.getElementById("cardoornumber").value;
    }
    var pos;
    if (document.getElementById("position").value === '') {
        pos = null;
    } else {
        pos = document.getElementById("position").value;
    }
    var trans = document.getElementById("transmission").value;
    var eng = document.getElementById("engine").value;
    var mod;
    if (document.getElementById("model").value === '') {
        mod = null;
    } else {
        mod = document.getElementById("model").value;
    }
    var avail = document.getElementById("available").checked;
    var fd = document.getElementById("fromdate").value;
    var td = document.getElementById("todate").value;
    var ppd;
    if (document.getElementById("priceperday").value === '') {
        ppd = null;
    } else {
        ppd = document.getElementById("priceperday").value;
    }

    const params={
        car: {
            year: year,
            pollutionLevel: pl,
            fuel: fuel,
            brand: brand,
            passengers: pass,
            size: size,
            carDoorNumber: cdn,
            position: pos,
            transmission: trans,
            engine: eng,
            model: mod
        },
        offer: {
            available: avail,
            fromDate: fd,
            toDate: td,
            pricePerDay: ppd
        },
        utilities: {
            display: dis,
            assistant: assis,
            airConditioning: ac,
            startAndStop: sas,
            navigationSystem: ns,
            parkingAssistant: pa,
            bluetooth: bt,
            USBPorts: usb,
            CDPlayer: cd,
            radioAMFM: radio,
            cruiseControl: cc,
            parkingCamera: pc,
            surroundAudio: sa
        }
    };

    fetch(postUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
    })
        .then(function(response) {
            return response.json();
        })
        .then(function(body) {
            sessionStorage.setItem("NumberOfLists", body.length)
            for (let x = 0; x < body.length; x++) {
                for (let y in body[x]) {
                    for (let z in body[x][y]) {
                        sessionStorage.setItem("List: " + x + " / Type: " + y + " / Field: " + z, body[x][y][z]);
                    }
                }
            }
        })
        .then(function() {
            window.location.href = successUrl;
        });
}