function submitForm() {
            // Replace these URLs with the ones you want to use
            var postUrl = "http://localhost:9002/carinsert/insertcar";
            var successUrl = "http://localhost:8081/carinsert/insertutilities";
            var problemUrl = "http://localhost:8081/failed";

            // Get form data
            var platenum = document.getElementById("platenum").value;
            var model = document.getElementById("model").value;
            var year = document.getElementById("year").value;
            var pl = document.getElementById("PollutionLevel").value;
            var fuel = document.getElementById("Fuel").value;
            var brand = document.getElementById("Brand").value;
            var pass = document.getElementById("Passenger").value;
            var size = document.getElementById("Size").value;
            var carD = document.getElementById("CarDoors").value;
            var pos = document.getElementById("pos").value;
            var ins = document.getElementById("ins").value;
            var tra = document.getElementById("Transmission").value;
            var engine = document.getElementById("Engine").value;

            const params = {
                plateNum: platenum,
                model: model,
                year: year,
                pollutionLevel: pl,
                fuel: fuel,
                brand: brand,
                passengers: pass,
                size: size,
                carDoorNumber: carD,
                position: pos,
                insurance: ins,
                transmission: tra,
                engine: engine
            };

    var xhr = new XMLHttpRequest();

    xhr.open("POST", postUrl, true);

    xhr.setRequestHeader('Content-type', 'application/json')

    xhr.onload = function () {
        if (xhr.status === 200) {
            // Redirect to the success page
            window.location.href = successUrl;
        } else {
            window.location.href = problemUrl;
        }
    };

    xhr.send(JSON.stringify(params));
}