package MACC.Insurance.controller;

import MACC.Insurance.model.Insurance;
import MACC.Insurance.service.InsuranceService;
import com.google.gson.JsonObject;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Objects;


@Slf4j
@AllArgsConstructor
@RequestMapping(path = "/insurance")
@RestController
public class InsuranceController {

    private final InsuranceService insuranceService;

    @PostMapping(path = "/insertInsurance")
    @ResponseBody
    public ResponseEntity<String> insertInsurance(@RequestParam("username") String username,@RequestPart("file") MultipartFile file) throws IOException{
        try {
            if(Objects.isNull(insuranceService.setInsurance(username,file))) return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Serialization Error");
            else
                return ResponseEntity.status(HttpStatus.OK).body("Request completed");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @GetMapping(path = "/showInsurance")
    @ResponseBody
    public ResponseEntity<String> getInsurance(@RequestParam("id") Long id){
        try {
            Insurance insurance=insuranceService.getInsurance(id);
            if(!Objects.isNull(insurance)) {
                JsonObject json=new JsonObject();
                json.addProperty("id",insurance.getId());
                json.addProperty("username",insurance.getUsername());
                json.addProperty("insuranceFile",Base64.getEncoder().encodeToString(insurance.getInsuranceFile()));
                // decode, convert base64 encoded string back to byte[]
                //byte[] decode = Base64.getDecoder().decode(s);
                return ResponseEntity.status(HttpStatus.OK).body(json.getAsString());
            }else {
                return ResponseEntity.status(HttpStatus.OK).body("There is no booking with the current specifications");
            }
        } catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }


}
