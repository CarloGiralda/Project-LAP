package MACC.Insurance.controller;

import MACC.Insurance.model.Insurance;
import MACC.Insurance.service.InsuranceService;
import com.google.gson.JsonObject;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.awt.*;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Base64;
import java.util.Objects;


@Slf4j
@AllArgsConstructor
@RequestMapping(path = "/insurance")
@RestController
public class InsuranceController {

    private final InsuranceService insuranceService;

    @PostMapping(path = "/insertInsurance")
    @ResponseBody
    public ResponseEntity<String> insertInsurance(@RequestParam("username") String username, @RequestHeader("Logged-In-User") String user,@RequestPart("file") MultipartFile file) throws IOException{
        try {
            Insurance ins=insuranceService.setInsurance(username,file);
            if(Objects.isNull(ins)) return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Serialization Error");
            else {
                return ResponseEntity.status(HttpStatus.OK).body("Request completed");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @GetMapping(path = "/showInsurance")
    @ResponseBody
    public ResponseEntity<String> getInsurance(@RequestParam("id") Long id, @RequestHeader("Logged-In-User") String username, HttpServletResponse response){
        try {
            System.out.println(id);
            Insurance insurance=insuranceService.getInsurance(id);
            if(!Objects.isNull(insurance)) {
                JsonObject json=new JsonObject();
                json.addProperty("id",insurance.getId());
                json.addProperty("username",insurance.getUsername());
                json.addProperty("insuranceFile", Arrays.toString(insurance.getInsuranceFile()));
                response.setHeader("Content-Disposition", "attachment; filename=dummy.pdf");
                return ResponseEntity.status(HttpStatus.OK).body(json.toString());
            }else {
                return ResponseEntity.status(HttpStatus.OK).body("There is no such a insurance");
            }
        } catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.toString());
        }
    }


}
