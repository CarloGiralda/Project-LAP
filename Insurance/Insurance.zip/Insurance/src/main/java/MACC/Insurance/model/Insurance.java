package MACC.Insurance.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;

import java.sql.Blob;


@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "insurances")
public class Insurance {
    @Id
    @SequenceGenerator(name = "insurances_gen", sequenceName = "insurances_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "insurances_gen")
    private Long id;
    private String username;
    private byte[] insuranceFile;
}
