package MACC.Insurance.model;

import org.springframework.data.jpa.repository.JpaRepository;





public interface InsuranceRepository extends JpaRepository<Insurance, Integer> {

    Insurance findById(Long Cid);



}