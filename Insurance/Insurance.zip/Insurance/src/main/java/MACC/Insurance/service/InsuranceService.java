package MACC.Insurance.service;

import MACC.Insurance.model.Insurance;
import MACC.Insurance.model.InsuranceRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.hibernate.SessionFactory;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import java.io.*;
import java.nio.charset.Charset;
import java.sql.Blob;
import java.sql.Clob;

@Service
@Slf4j
@AllArgsConstructor
public class InsuranceService {

    private final InsuranceRepository insuranceRepository;





    public Insurance setInsurance(String username, MultipartFile file) throws IOException {
        byte [] byteArr=file.getBytes();
        Insurance insurance=new Insurance();
        insurance.setUsername(username);
        insurance.setInsuranceFile(byteArr);
        return insuranceRepository.saveAndFlush(insurance);
    }

    public Insurance getInsurance(Long id) {
        return insuranceRepository.findById(id);
    }

}

