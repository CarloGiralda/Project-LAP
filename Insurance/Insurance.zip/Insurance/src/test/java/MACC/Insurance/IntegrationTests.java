package MACC.Insurance;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;

import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest(classes = MACC.Insurance.InsuranceApplication.class)
@AutoConfigureMockMvc
class IntegrationTests {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper objectMapper;



    @Test
    public void insertInsurance() throws Exception {
        File file =  new File("/Users/applem2/Downloads/dummy.pdf");
        Path path = Path.of("Downloads");
        String fileName = FilenameUtils.getName(file.getName());
        byte[] bytes = FileUtils.readFileToByteArray((File) file);
        MockMultipartFile mockMultipartFile = new MockMultipartFile("file", "file", MediaType.MULTIPART_FORM_DATA_VALUE, bytes);
        MvcResult result= mvc.perform(multipart("http://localhost:9009/insurance/insertInsurance").file(mockMultipartFile))
                .andExpect(status().isOk())
                .andDo(print()).andReturn();}

    @Test
    void getInsurance() throws Exception {
        String id="1";
        MvcResult result = mvc.perform(get("http://localhost:9009/insurance/showInsurance").queryParam("id",id)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andDo(print()).andReturn();
    }
}






