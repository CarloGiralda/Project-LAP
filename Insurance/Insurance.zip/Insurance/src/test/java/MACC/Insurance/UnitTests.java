package MACC.Insurance;




import MACC.Insurance.controller.InsuranceController;
import MACC.Insurance.model.Insurance;
import MACC.Insurance.service.InsuranceService;
;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.google.gson.JsonObject;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Objects;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(InsuranceController.class)
@ContextConfiguration("/test-context.xml")
class UnitTests {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private  ObjectMapper objectMapper;
    @MockBean
    private InsuranceService insuranceService;



    @BeforeEach
    void setUp(WebApplicationContext wac) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }



    @Test
    public void insertInsurance() throws Exception {
        String username="Gian";
        File file = new File("/Users/applem2/Downloads/LAP/Insurance/dummy.pdf");
        Insurance ins = new Insurance();
        when(insuranceService.setInsurance(anyString(), any(MultipartFile.class))).thenReturn(ins);
        String fileName = FilenameUtils.getName(file.getName());
        byte[] bytes = FileUtils.readFileToByteArray( file);
        MockMultipartFile mockMultipartFile = new MockMultipartFile("file", fileName, MediaType.MULTIPART_FORM_DATA_VALUE, bytes);
        MvcResult result = mockMvc.perform(multipart("http://localhost:9009/insurance/insertInsurance").file(mockMultipartFile).param("username",username))
                .andExpect(status().isOk())
                .andDo(print()).andReturn();
    }

    @Test
    public void getInsurance() throws Exception {
        String id="1";
        Insurance ins=new Insurance();
        when(insuranceService.getInsurance(anyLong())).thenReturn(null);
        MvcResult result = mockMvc.perform(get("http://localhost:9009/insurance/showInsurance").queryParam("id",id)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andDo(print()).andReturn();
    }

}
