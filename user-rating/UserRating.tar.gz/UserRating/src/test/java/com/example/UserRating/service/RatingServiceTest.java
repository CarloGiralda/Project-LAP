package com.example.UserRating.service;

import com.example.UserRating.discoveryclient.DiscoveryClientService;
import com.example.UserRating.model.AppUserDTO;
import com.example.UserRating.model.AppUserRoleDTO;
import com.example.UserRating.model.Rating;
import com.example.UserRating.model.RatingDTO;
import com.example.UserRating.repository.RatingRepo;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class RatingServiceTest {
    @Mock
    RatingRepo ratingRepo;
    @Mock
    DiscoveryClientService discoveryClientService;
    @Mock
    RestTemplate restTemplate;

    @Test
    public void shouldReturnTrueIfRatingIsSaved() {
        RatingService rsi = new RatingServiceImpl(ratingRepo, restTemplate, discoveryClientService);

        // this is the input
        Rating rating = new Rating(5L, LocalDate.of(2020, 10, 10), "Gentile", 1L, 2L);
        // this is the result, and also the expected response
        Rating result = new Rating(5L, LocalDate.of(2020, 10, 10), "Gentile", 1L, 2L);
        result.setUrid(1L);

        when(ratingRepo.save(rating)).thenReturn(result);

        Rating actualResponse = rsi.insertRating(rating);

        Assertions.assertEquals(result.getStars(), actualResponse.getStars());
        Assertions.assertEquals(result.getDate(), actualResponse.getDate());
    }

    @Test
    public void shouldReturnTrueIfConvertionGoesWell() {
        RatingService rsi = new RatingServiceImpl(ratingRepo, restTemplate, discoveryClientService);

        // this is the input to convert
        RatingDTO dto = new RatingDTO(5L, LocalDate.of(2020, 10, 10), "Gentile", "token", 2L);
        // this is the user from which we get the id
        AppUserDTO audto = new AppUserDTO(1L, "Elia", "Bombardelli", "elia@gmail.com", "Math", AppUserRoleDTO.USER);
        // this is the response of the get method
        ResponseEntity<AppUserDTO> re = new ResponseEntity<>(audto, HttpStatus.OK);
        // this is the expected rating
        Rating expectedRating = new Rating(5L, LocalDate.of(2020, 10, 10), "Gentile", 1L, 2L);

        when(discoveryClientService.getServiceUrl("USER-SERVICE")).thenReturn("http://localhost:9000");
        when(restTemplate.getForEntity("http://localhost:9000/auth/getUserFromJwt?jwt=" + dto.getMade_by(), AppUserDTO.class)).thenReturn(re);

        Rating actualRating = rsi.convertDTO(dto);

        Assertions.assertEquals(expectedRating.getStars(), actualRating.getStars());
        Assertions.assertEquals(expectedRating.getDate(), actualRating.getDate());
    }

}
