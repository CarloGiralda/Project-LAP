package com.example.UserRating.controller;

import com.example.UserRating.model.Rating;
import com.example.UserRating.model.RatingDTO;
import com.example.UserRating.service.RatingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;

import static org.mockito.Mockito.when;

@WebMvcTest(controllers = RatingController.class)
public class RatingControllerTest {
    @MockBean
    private RatingService ratingService;
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void shouldReturnTrueIfTheUserRatingIsSaved() throws Exception {
        // this is the input to convert
        RatingDTO dto = new RatingDTO(5L, LocalDate.of(2020, 10, 10), "Gentile", "token", 2L);
        dto.setUrid(1L);
        // this is the input converted, and also the body of the response
        Rating rating = new Rating(5L, LocalDate.of(2020, 10, 10), "Gentile", 1L, 2L);
        rating.setUrid(1L);

        ObjectMapper omdto = new ObjectMapper();
        omdto.findAndRegisterModules();
        String dtoAsString = omdto.writeValueAsString(dto);

        when(ratingService.convertDTO(dto)).thenReturn(rating);

        // create the expected rating
        Rating expectedRating = new Rating(5L, LocalDate.of(2020, 10, 10), "Gentile", 1L, 2L);
        expectedRating.setUrid(1L);
        when(ratingService.insertRating(ArgumentMatchers.any())).thenReturn(expectedRating);

        mockMvc.perform(MockMvcRequestBuilders.post("/rating/{id}", rating.getRating_on())
                        // a custom header must be inserted because of the authentication filter
                        // the username (email) is fake
                        .header("Logged-In-User", "username@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(dtoAsString))
                .andExpect(MockMvcResultMatchers.status().is(200))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Gentile"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.rating_on").value(2L));
    }

    @Test
    public void shouldReturnFalseIfTheUserRatingIsNotSaved() throws Exception {
        // this is the input to convert
        RatingDTO dto = new RatingDTO(5L, LocalDate.of(2020, 10, 10), "Gentile", "token", 2L);
        // this is the input converted, and also the body of the response
        Rating rating = new Rating(5L, LocalDate.of(2020, 10, 10), "Gentile", 1L, 2L);

        ObjectMapper omdto = new ObjectMapper();
        omdto.findAndRegisterModules();
        String dtoAsString = omdto.writeValueAsString(dto);

        when(ratingService.convertDTO(ArgumentMatchers.any())).thenReturn(rating);

        // the result is null
        when(ratingService.insertRating(ArgumentMatchers.any())).thenReturn(null);

        mockMvc.perform(MockMvcRequestBuilders.post("/rating/{id}", rating.getRating_on())
                        // a custom header must be inserted because of the authentication filter
                        // the username (email) is fake
                        .header("Logged-In-User", "username@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(dtoAsString))
                .andExpect(MockMvcResultMatchers.status().is(304));
    }
}
