package com.example.UserRating.model;

public enum AppUserRoleDTO {
    USER,
    ADMIN
}
