package com.example.UserRating.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class RatingDTO {
    private Long stars;
    private LocalDate date;
    private String description;
    // made_by is the jwt token
    private String made_by;
    private Long rating_on;

    public RatingDTO() {
    }

    public RatingDTO(Long stars, LocalDate date, String desc, String made_by, Long rating_on) {
        this.stars = stars;
        this.date = date;
        this.description = desc;
        this.made_by = made_by;
        this.rating_on = rating_on;
    }
}
