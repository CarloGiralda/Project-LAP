package com.example.UserRating.controller;

import com.example.UserRating.model.Rating;
import com.example.UserRating.model.RatingDTO;
import com.example.UserRating.service.RatingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RequestMapping(path = "/rating")
@RestController
public class RatingController {
    private RatingService ratingService;

    public RatingController(RatingService ratingService) {
        super();
        this.ratingService = ratingService;
    }

    @PostMapping(path = "/{id}")
    public ResponseEntity<Rating> saveRating(@PathVariable String id, @RequestBody RatingDTO dto, @RequestHeader("Logged-In-User") String username) {
        Rating rating = ratingService.convertDTO(dto);
        log.info(String.valueOf(rating.getMade_by()));
        return new ResponseEntity<>(ratingService.insertRating(rating), HttpStatus.OK);
    }
}
