package com.example.UserRating.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Setter
@Getter
@Entity
@Table(name = "user_rating")
public class Rating {
    @Id
    @SequenceGenerator(name = "rat_gen", sequenceName = "rat_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rat_gen")
    private Long urid;
    private Long stars;
    private LocalDate date;
    private String description;
    private Long made_by;
    private Long rating_on;

    public Rating() {
    }

    public Rating(Long stars, LocalDate date, String desc, Long made_by, Long rating_on) {
        this.stars = stars;
        this.date = date;
        this.description = desc;
        this.made_by = made_by;
        this.rating_on = rating_on;
    }
}
