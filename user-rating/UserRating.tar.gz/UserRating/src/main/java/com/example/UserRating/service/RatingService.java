package com.example.UserRating.service;

import com.example.UserRating.model.Rating;
import com.example.UserRating.model.RatingDTO;

public interface RatingService {
    public Rating insertRating(Rating rating);
    public Rating convertDTO(RatingDTO dto);
}
