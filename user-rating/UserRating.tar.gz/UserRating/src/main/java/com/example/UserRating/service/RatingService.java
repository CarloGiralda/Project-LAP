package com.example.UserRating.service;

import com.example.UserRating.model.Rating;
import com.example.UserRating.model.RatingDTO;
import org.springframework.stereotype.Service;

public interface RatingService {
    public Rating insertRating(Rating rating);
    public Rating convertDTO(RatingDTO dto);
}
