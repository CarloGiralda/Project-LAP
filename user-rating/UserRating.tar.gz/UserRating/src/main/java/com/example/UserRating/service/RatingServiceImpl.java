package com.example.UserRating.service;

import com.example.UserRating.discoveryclient.DiscoveryClientService;
import com.example.UserRating.model.AppUserDTO;
import com.example.UserRating.model.Rating;
import com.example.UserRating.model.RatingDTO;
import com.example.UserRating.repository.RatingRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Service
public class RatingServiceImpl implements RatingService {
    private final RatingRepo ratingRepo;
    private final DiscoveryClientService discoveryClientService;

    public RatingServiceImpl(RatingRepo ratingRepo, DiscoveryClientService discoveryClientService) {
        this.ratingRepo = ratingRepo;
        this.discoveryClientService = discoveryClientService;
    }

    @Override
    public Rating insertRating(Rating rating) {
        // checks about user id and renter id are performed in the convertDTO function
        // that is called before this function
        return ratingRepo.save(rating);
    }

    @Override
    public Rating convertDTO(RatingDTO dto) {
        String requestForUser = dto.getMade_by();
        String userJwtUrl = discoveryClientService.getServiceUrl("USER-SERVICE") + "/auth/getUserFromJwt?jwt=" + requestForUser;

        // Send the request to the user service
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<AppUserDTO> user = restTemplate.getForEntity(userJwtUrl, AppUserDTO.class);

        return new Rating(dto.getStars(), dto.getDate(), dto.getDescription(), user.getBody().getId(), dto.getRating_on());

        // return new Rating(5L, LocalDate.of(2020, 10, 10), "BELLA", 1L, 1L);
    }
}
