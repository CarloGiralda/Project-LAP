alter table car_rating
   alter column crid set default nextval('carrat_seq');
INSERT INTO car_rating(
	date,  made_by_user, rating_on_car, stars, description)
	VALUES ('2024-02-02',  2, 1, 3, 'nothing special'),
	 ('2024-02-03',  3, 1, 4, 'a good experience'),
	 ('2024-01-06', 1, 2, 5, 'very very good'),
	 ('2024-01-10',  3, 2, 2, 'the car was disgustingly dirty'),
	 ('2024-01-04',  2, 3, 2, 'the renter was too rude'),
	 ('2024-01-03',  1, 3, 5, 'very good car'),
	 ('2024-01-10', 2, 4, 5, 'very good car');
