

import com.example.carbook.CarBookApplication;
import com.example.carbook.model.booking.Booking;
import com.example.carbook.model.booking.BookingPreview;
import com.example.carbook.model.booking.ExtendBookingRequest;
import com.example.carbook.model.booking.Request;
import com.example.carbook.model.carSubscription.CarSubscription;
import com.example.carbook.model.offer.Offer;
import com.example.carbook.service.BookingService;
import com.example.carbook.service.CarSubService;
import com.example.carbook.service.OfferService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;

import java.util.ArrayList;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest(classes = CarBookApplication .class)
@AutoConfigureMockMvc
class ControllerTest2 {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper objectMapper;


    @MockBean
    private BookingService bookingService;
    @MockBean
    private OfferService offerService;



    @Test
    void bookCar() throws Exception {
        Request r=new Request("1","2024-11-01","2024-11-01","2024-11-01","12:00","13:00","test1","test2","");
        RequestBuilder requestBuilder = post("http://localhost:9005/reservation/book").header("Logged-In-User", "username")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(r)).accept(MediaType.TEXT_PLAIN);

        MvcResult result = mvc.perform(requestBuilder).andReturn();
        Assertions.assertEquals("Request completed", result.getResponse().getContentAsString());
    }

    @Test
    void listBookedCar() throws Exception {
       ArrayList<Booking> a=new ArrayList<>();
       Booking b=new Booking();
       a.add(b);
        when(bookingService.getBooking(any(String.class),anyString(),anyString())).thenReturn(a);
        Request r=new Request("1","2024-11-01","2024-11-01","2024-11-01","12:00","13:00","test1","test2","");
        RequestBuilder requestBuilder = post("http://localhost:9005/reservation/listBookings").header("Logged-In-User", "username")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(r)).accept(MediaType.TEXT_PLAIN);

        mvc.perform(requestBuilder).andExpect(status().isOk());
    }


    @Test
    void extendBook() throws Exception {
        ExtendBookingRequest e = new ExtendBookingRequest(1L,1L,"2024-11-01","12:00");
        RequestBuilder requestBuilder = post("http://localhost:9005/reservation/extendBooking").header("Logged-In-User", "username")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(e)).accept(MediaType.TEXT_PLAIN);

        mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    void showOffer() throws Exception {
        Offer o = new Offer();
        when(offerService.getOffer(any(String.class),anyString())).thenReturn(o);
        RequestBuilder requestBuilder = get("http://localhost:9005/reservation/showOffer").header("Logged-In-User", "username").queryParam("cid","1L")
                .accept(MediaType.APPLICATION_JSON);
        mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    void modifyOffer() throws Exception {
        mvc.perform(get("http://localhost:9005/reservation/modifyOffer").header("Logged-In-User", "username").queryParam("cid","1").queryParam("price","10")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
    @Test
    void listBookingsPreview() throws Exception {
        ArrayList<BookingPreview> ret=new ArrayList<>();
        BookingPreview b= new BookingPreview();
        ret.add(b);
        when(bookingService.getBookingPreview(any(String.class))).thenReturn(ret);
        mvc.perform(get("http://localhost:9005/reservation/listBookingsPreview").header("Logged-In-User", "username")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
    @Test
    void listBookingsHistory() throws Exception {
        ArrayList<BookingPreview> ret=new ArrayList<>();
        BookingPreview b= new BookingPreview();
        ret.add(b);
        when(bookingService.getBookingHistory(any(String.class))).thenReturn(ret);
        mvc.perform(get("http://localhost:9005/reservation/listBookingsHistory").header("Logged-In-User", "username")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
    @Test
    void getAvailability() throws Exception {
        when(bookingService.getCarAvailability(any(Long.class))).thenReturn(true);
        mvc.perform(get("http://localhost:9005/reservation/getCarAvailability/{carId}","1").header("Logged-In-User", "username")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
    @Test
    void showOfferCar() throws Exception {
        ArrayList<Booking> a=new ArrayList<>();
        Booking b=new Booking();
        a.add(b);
        when(bookingService.getBooking(any(String.class),anyString(),anyString())).thenReturn(a);
        mvc.perform(get("http://localhost:9005/reservation/showOfferCar").header("Logged-In-User", "username").queryParam("cid","1L")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }






}




