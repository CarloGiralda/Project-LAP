


import MACC.areaservice.AreaServiceApplication;
import MACC.areaservice.model.Area;
import MACC.areaservice.model.Location;
import MACC.areaservice.service.AreaService;
import MACC.areaservice.service.AreaServiceMap;
import MACC.areaservice.service.ContainerService;
import MACC.areaservice.service.SubsService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;

import java.util.ArrayList;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest(classes = AreaServiceApplication .class)
@AutoConfigureMockMvc
class ControllerTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AreaServiceMap geocodingService;
    @MockBean
    private  AreaService areaService;
    @MockBean
    private  SubsService subsService;
    @MockBean
    private ContainerService containerService;



    @Test
    void searchMap() throws Exception {
        String query = "milan";
        String radius = "500";
        ArrayList<Location> ar=new ArrayList<>();
        Location l=new Location();
        l.setCid("10");
        l.setLat("45.4641943");
        l.setLng("9.1896346");
        l.setName("tesla model x");
        JsonObject json=new JsonObject();
        json.addProperty("lat","45.4641943");
        json.addProperty("lon","9.1896346");
        ar.add(l);
        when(geocodingService.search(any(String.class))).thenReturn(json);
        when(containerService.getSession(any(String.class))).thenReturn(ar);
        mvc.perform(get("http://localhost:9008/area/search")
                        .queryParam("query",query).queryParam("radius",radius)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void subscribe() throws Exception {
        String areaCenter = "45.4640943/9.1896346";
        String areaRadius = "50";
        String username="test2";
        Area ret=new Area();
        when(containerService.getSession(any(String.class))).thenReturn(null);
        when(areaService.getArea(any(String.class),anyString())).thenReturn(ret);
        mvc.perform(get("http://localhost:9008/area/subscribe")
                        .queryParam("areaCenter",areaCenter).queryParam("areaRadius",areaRadius).queryParam("username",username)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());


    }



    @Test
    void searchLocation() throws Exception {
        String query = "milan";
        JsonObject json=new JsonObject();
        json.addProperty("lat","45.4641943");
        json.addProperty("lon","9.1896346");
        when(geocodingService.search(any(String.class))).thenReturn(json);
        mvc.perform(get("http://localhost:9008/area/searchLocation")
                        .queryParam("query",query)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void searchName() throws Exception {
        String query = "milan";
        JsonObject json=new JsonObject();
        JsonObject json2=new JsonObject();
        json2.addProperty("city","milan");
        System.out.println(json2);
        json.add("address", json2);
        when(geocodingService.searchName(any(String.class))).thenReturn(json);
        mvc.perform(get("http://localhost:9008/area/searchName")
                        .queryParam("query",query)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }



}




