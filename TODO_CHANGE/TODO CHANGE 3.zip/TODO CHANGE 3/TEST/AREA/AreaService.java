package MACC.areaservice.service;

import MACC.areaservice.model.Area;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@AllArgsConstructor
public class AreaService {

    private final AreaRepository areaRepository;

    public Area getArea(String areaCenter, String areaRadius){
        return areaRepository.findByAreaCenterAndAreaRadius(areaCenter,areaRadius);
    }


    public Area setArea(Area area){
        return areaRepository.save(area);
    }


}
