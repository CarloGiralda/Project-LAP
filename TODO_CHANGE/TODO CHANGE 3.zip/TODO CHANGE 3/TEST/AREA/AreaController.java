package MACC.areaservice.controller;

import MACC.areaservice.model.Area;
import MACC.areaservice.model.CarSubscriptionRequest;
import MACC.areaservice.model.Location;
import MACC.areaservice.request.Subscriptions;
import MACC.areaservice.service.AreaService;
import MACC.areaservice.service.ContainerService;
import MACC.areaservice.service.SubsService;
import com.google.gson.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import MACC.areaservice.service.AreaServiceMap;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;


@RestController
@Slf4j
@AllArgsConstructor
@RequestMapping(path = "/area")
public class AreaController {


    private final AreaServiceMap geocodingService;
    private final AreaService areaService;
    private final SubsService subsService;
    private final ContainerService containerService;

    @RequestMapping(path = "/search",method = RequestMethod.GET,consumes = MediaType.ALL_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<?> searchMap(@RequestParam("query") String query,@RequestParam("radius") String radius){
        JsonObject location;
        try {

            //Request to car search
            location= geocodingService.search(query);
            JsonArray jsonArray=null;
            String center=location.get("lat").getAsString()+"/"+location.get("lon").getAsString();
            // check if search already contained in container
            String[] check=new String[2];
            check[0]=center;
            check[1]=radius;
            System.out.println("SETTING CONTAINER ELEMENT TO key:"+ Arrays.toString(check));
            ArrayList<Location> ls=containerService.getSession(Arrays.toString(check));
            if(Objects.isNull(ls)) {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI("http://localhost:9003/carsearch/getCarsWithinRange?position=" + center + "&range=" + radius))
                        .GET()
                        .build();
                HttpClient client = HttpClient.newHttpClient();
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                System.out.println("RESPONSE FROM CAR SEARCH SERVICE:"+response.body());
                jsonArray=JsonParser.parseString(response.body()).getAsJsonArray();
                System.out.println("RESPONSE FROM CAR SEARCH SERVICE:"+jsonArray);
                location.add("response", jsonArray);
                ArrayList<Location> ll=new ArrayList<>();
                for(int i=0; i< jsonArray.size(); i++) {
                    JsonObject element=jsonArray.get(i).getAsJsonObject();
                    Location l= new Location();
                    l.setId(i);

                    l.setLat(element.get("lat").getAsString());
                    l.setLng(element.get("lon").getAsString());
                    l.setName(element.get("name").getAsString());
                    l.setCid(element.get("cid").getAsString());
                    ll.add(l);
                }
                System.out.println("SETTING CONTAINER ELEMENT TO:"+ Arrays.toString(check));
                containerService.updateSession(Arrays.toString(check),ll);
            }else{
                System.out.println("RESPONSE FROM SERVER:");
                ArrayList<Location> ll = containerService.getSession(Arrays.toString(check));
                JsonArray array = new JsonArray();

                for (int i = 0; i < ll.size(); i++) {
                    JsonObject element = new JsonObject();
                    element.addProperty("lat", ll.get(i).getLat());
                    element.addProperty("lon", ll.get(i).getLng());
                    element.addProperty("name", ll.get(i).getName());
                    element.addProperty("cid", ll.get(i).getCid());
                    array.add(element);
                }
                location.add("response", array.getAsJsonArray());
            }
            return new ResponseEntity<>(location,HttpStatus.OK);
        } catch (JSONException | IOException | JsonSyntaxException | URISyntaxException | InterruptedException e) {
            System.out.println("RESPONSE FROM CAR SEARCH SERVICE: error");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @RequestMapping(path = "/subscribe",method = RequestMethod.GET,consumes = MediaType.ALL_VALUE,
            produces = MediaType.ALL_VALUE)
    @ResponseBody
    public ResponseEntity<?> subscribe(@RequestParam("areaCenter") String areaCenter,@RequestParam("areaRadius") String areaRadius,@RequestParam("username") String username){
        HttpResponse<String> response =null;
        String[] check=new String[2];
        check[0]=areaCenter;
        check[1]=areaRadius;
        ArrayList<Location> l=containerService.getSession(Arrays.toString(check));
        ArrayList<Long> cars=new ArrayList<>();
        if(!Objects.isNull(l)) {
            for (Location loc : l) {
                cars.add(Long.parseLong(loc.getCid()));
            }
            CarSubscriptionRequest r = new CarSubscriptionRequest(username, cars);
            Gson gson = new Gson();
            String json = gson.toJson(r);
            try {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI("http://localhost:9005/subscription/subscribeCarsForUser"))
                        .POST(HttpRequest.BodyPublishers.ofString(json)).header("Content-Type", "application/json")
                        .build();
                HttpClient client = HttpClient.newHttpClient();
                response = client.send(request, HttpResponse.BodyHandlers.ofString());
            } catch (URISyntaxException | InterruptedException | IOException e) {
                System.out.println("RESPONSE FROM SERVER: error " + e.getMessage());
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
            }
            if (!Objects.equals(response.statusCode(),500)){
                //create subs
                Subscriptions subs=new Subscriptions();
                Area ret=areaService.getArea(areaCenter,areaRadius);
                subs.setAreas(ret);
                subs.setUsername(username);
                subsService.setSubs(subs);
            }
            System.out.println("RESPONSE FROM NOTIFICATION SERVICE:" + response);
            return ResponseEntity.status(response.statusCode()).body(response.body());
        }
        // create zone if it is not already present
        Area area=new Area();
        area.setAreaCenter(areaCenter);
        area.setAreaRadius(areaRadius);
        Area ret=areaService.setArea(area);
        //create subs
        Subscriptions subs=new Subscriptions();
        subs.setAreas(ret);
        subs.setUsername(username);
        subsService.setSubs(subs);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(path = "/searchLocation",method = RequestMethod.GET,consumes = MediaType.ALL_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<?> searchLocation(@RequestParam("query") String query){
        JsonObject location;
        JsonObject ret=new JsonObject();
        try {
            //Request to car search
            location= geocodingService.search(query);
            ret.add("lat",location.get("lat"));
            ret.add("lon",location.get("lon"));
            return new ResponseEntity<>(ret,HttpStatus.OK);
        } catch (JSONException | IOException | JsonSyntaxException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @RequestMapping(path = "/searchName",method = RequestMethod.GET,consumes = MediaType.ALL_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<?> searchName(@RequestParam("query") String query){
        JsonObject location;
        JsonObject ret=new JsonObject();
        try {
            //Request to car search
            location= geocodingService.searchName(query);
            System.out.println(location);
            ret.add("city",location.get("address").getAsJsonObject().get("city"));
            return new ResponseEntity<>(ret,HttpStatus.OK);
        } catch (JSONException | IOException | JsonSyntaxException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }
}