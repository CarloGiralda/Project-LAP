package MACC.areaservice.service;

import MACC.areaservice.model.Area;
import MACC.areaservice.request.Subscriptions;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AreaRepository extends JpaRepository<Area, Integer> {
    Area findByAreaCenterAndAreaRadius(String areaCenter,String areaRadius);


}
