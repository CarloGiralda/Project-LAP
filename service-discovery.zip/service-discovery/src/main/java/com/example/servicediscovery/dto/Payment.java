package com.example.servicediscovery.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Payment {

    private String sender;
    private String receiver;
    private String price;

}
