package com.example.servicediscovery.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;

import static java.nio.charset.StandardCharsets.UTF_8;

@Getter
@Setter
@Slf4j
public class Block {
    private String hash;
    private String previousHash;
    private ArrayList<Payment> data;
    private long timeStamp;
    private long nonce;

    public Block(String previousHash) {
        this.data = new ArrayList<>();
        this.previousHash = previousHash;
        this.timeStamp = Instant.now().toEpochMilli();
        Random rand = new Random();
        this.nonce = rand.nextLong();
        this.hash = calculateBlockHash();
    }

    public String calculateBlockHash() {
        String dataToHash = previousHash
                + Long.toString(timeStamp)
                + Long.toString(nonce)
                + data.toString();
        MessageDigest digest = null;
        byte[] bytes = null;
        try {
            digest = MessageDigest.getInstance("SHA-256");
            bytes = digest.digest(dataToHash.getBytes(UTF_8));
        } catch (NoSuchAlgorithmException ex) {
            log.info(ex.getMessage(), Level.SEVERE);
        }
        StringBuffer buffer = new StringBuffer();
        for (byte b : bytes) {
            buffer.append(String.format("%02x", b));
        }
        return buffer.toString();
    }

    public String singleMine() {
        nonce++;
        hash = calculateBlockHash();
        return hash;
    }

    public void addToBlock(Payment trx) throws IOException {
        this.data.add(trx);
    }
}
