package com.example.servicediscovery.model;

import com.example.servicediscovery.dto.Block;
import com.example.servicediscovery.dto.Payment;
import lombok.Getter;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
@Getter
public class Blockchain {
    private ArrayList<Block> blocks;

    public Blockchain() {
        blocks = new ArrayList<>();
        generateGenesis();
    }

    public void generateGenesis() {
        Block genesis = new Block("Genesis Block");
        // DEFAULT COUNTS
        Payment p=new Payment("Genesis Block","-----BEGIN PUBLIC KEY-----MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJIX5lWi3q3Zzb8hFuEVTwm9bfj/f5aAU5N6ynQE7fvpiQzv68zaeOqQ41lVp/bIFTgY+vKvoIZH/X87xt6lwpUCAwEAAQ==-----END PUBLIC KEY-----","1000","");
        ArrayList<Payment> ap=new ArrayList<>();
        ap.add(p);
        genesis.setData(ap);
        blocks.add(genesis);
    }

    public void addBlock(Block block) {
        blocks.add(block);
    }

    public Block getLastBlock() {
        int last = blocks.size() - 1;
        return blocks.get(last);
    }
}
