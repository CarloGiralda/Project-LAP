package com.example.servicediscovery.service;

import com.example.servicediscovery.dto.Block;
import com.example.servicediscovery.dto.Payment;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Arrays;


@Service
public class ConsumerService {
    private BlockchainService blockchainService;

    public void handleMessage(byte[] message) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        int i=0;
        Object object = objectMapper.readValue(message, Object.class);
        while (i==0){
            ;
        }
        // RECEIVE TRANSACTION FROM OTHERS
        if (Arrays.stream(object.getClass().getMethods()).count()==1) {
            Payment payment = objectMapper.readValue(message, Payment.class);
            blockchainService.addTransaction(payment);
        }else{ // RECEIVE SOLVED BLOCK FROM OTHERS TO CHECK
            Block block = objectMapper.readValue(message, Block.class);

            if (block.getHash() == null) {
                blockchainService.addTransaction(block.getData().get(0));
            } else {
                blockchainService.checkBlock(block);
            }
        }
    }
}

