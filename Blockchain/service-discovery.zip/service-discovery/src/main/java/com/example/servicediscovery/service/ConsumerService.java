package com.example.servicediscovery.service;

import com.example.servicediscovery.dto.Payment;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import netscape.javascript.JSObject;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.util.SerializationUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.util.Arrays;
import java.util.Objects;

@Service
public class ConsumerService {



    public void handleMessage(byte[] message) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Payment theResult = objectMapper.readValue(message, Payment.class);
        System.out.println("Message: " +theResult.getPrice());
        //System.out.println("Message: " +theResult);
    }
}
