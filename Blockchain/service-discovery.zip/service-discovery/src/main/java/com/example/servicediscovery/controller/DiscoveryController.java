package com.example.servicediscovery.controller;

import com.example.servicediscovery.dto.Payment;
import com.example.servicediscovery.service.ProducerService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;
@Slf4j
@AllArgsConstructor
@RequestMapping(path = "/discovery")
@RestController
public class DiscoveryController {

    private final ProducerService producerService;
    @PostMapping(path = "/addTransaction")
    @ResponseBody
    public ResponseEntity<String> insertTransaction(@RequestBody Payment payment) {
        try {
            if(Objects.isNull(payment)) return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Serialization Error");
            else {
                System.out.println("Received payment from payment service"+payment);
                //BROADCAST TRANSACTION TO NODES
                producerService.broadcastMessage(payment);
                // VALIDATE TRANSACTION

                return ResponseEntity.status(HttpStatus.OK).body(payment.getPrice());
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }
}
