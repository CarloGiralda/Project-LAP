package com.example.servicediscovery.repository;


import com.example.servicediscovery.model.Credentials;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CredentialsRepo extends JpaRepository<Credentials, String> {
    Credentials findByUsername(String username);
}

