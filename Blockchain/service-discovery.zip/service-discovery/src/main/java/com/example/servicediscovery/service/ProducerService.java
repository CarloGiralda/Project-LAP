package com.example.servicediscovery.service;


import com.example.servicediscovery.dto.Payment;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProducerService {

    @Autowired
    private RabbitTemplate template;

    public void broadcastMessage(Payment message) {
        this.template.convertAndSend("my-exchange2", "", message);  // broadcasts string message to each my-queue-* via my-exchange
    }
}