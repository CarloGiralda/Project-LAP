package com.example.servicediscovery.model;



import lombok.Getter;
import lombok.Setter;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Setter
@Getter
@Entity
@Table(name = "credentials")
public class Credentials {
    @Id
    private String username;
    private String public_key;
    private String private_key;
}
