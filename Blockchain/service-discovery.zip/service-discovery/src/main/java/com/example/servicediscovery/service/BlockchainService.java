package com.example.servicediscovery.service;


import com.example.servicediscovery.dto.Block;
import com.example.servicediscovery.model.Blockchain;
import com.example.servicediscovery.dto.Payment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Objects;


@Service
@Slf4j
public class BlockchainService {
    private boolean found;
    private Block actualBlock;
    private final Blockchain blockchain;
    private final ProducerService producerService;


    public BlockchainService(Blockchain blockchain, ProducerService producerService) {
        this.found = false;
        this.blockchain = blockchain;
        this.producerService = producerService;
    }

    public int addTransaction(Payment payment) {
        try {
            log.error("DISCOVERY_SERVICE RECEIVES PAYMENT FROM THE OTHER NODE: sender: "+payment.getSender()+"price: "+payment.getPrice()+"receiver: "+payment.getReceiver());
            // VALIDATE SIGNATURE
            if (!(payment.validateSignature())) {
                log.error("DISCOVERY_SERVICE SIGNATURE VALIDATION FAILED");
                return 0;
            }
            log.error("DISCOVERY_SERVICE SIGNATURE VALIDATION SUCCESS");
            // BROADCAST TRANSACTION TO NODES
            // ENCAPSULATE TRX INTO A BLOCK
            Block temp=new Block(""); // TODO VERIFY
            ArrayList<Payment> temp2=new ArrayList<>();
            temp2.add(payment);
            temp.setData(temp2);
            producerService.broadcastMessage(temp);
            // VALIDATE TRANSACTION
            if (!(validateTransaction(payment))) {
                log.error("DISCOVERY_SERVICE TRANSACTION VALIDATION FAILED");;
                return 0;
            }
            log.error("DISCOVERY_SERVICE TRANSACTION VALIDATION SUCCESS AND ADDS TRX TO BLOCK");
            // ADD TRANSACTION TO BLOCK
            actualBlock.addToBlock(payment);
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    @Scheduled(fixedRate = 10000)
    public void mineBlock() {
        found = false;
        // TAKE LAST BLOCK OF THE BLOCKCHAIN
        Block last = blockchain.getLastBlock();
        // CREATE NEW BLOCK
        actualBlock = new Block(last.getPreviousHash());
        // PREFIX
        int prefix = 1;
        // START MINING
        String prefixString = new String(new char[prefix]).replace('\0', '0');
        String hash;
        do {
            hash = actualBlock.singleMine();
        } while (!hash.substring(0, prefix).equals(prefixString) && !found);

        if (!found) { // TODO VERIFY
            // NOTIFY THE OTHER NODE ABOUT THE HASH YOU FOUND
            log.error("DISCOVERY_SERVICE NOTIFIES THE OTHER NODE ABOUT THE HASH FOUND");
            producerService.broadcastMessage(actualBlock);
        }
        // IN BOTH CASES, THE BLOCK IS ADDED TO THE BLOCKCHAIN
        blockchain.addBlock(actualBlock);
        log.error("DISCOVERY_SERVICE ADDS BLOCK: "+actualBlock.getHash()+" TO THE BLOCKCHAIN");
        //LOGGING
        logging();
    }

    public void checkBlock(Block block) {
        String hash = block.calculateBlockHash();
        if (hash.equals(block.getHash())) {
            found = true;
        }
    }

    public void logging() {
        log.error("-----DISCOVERY_SERVICE BLOCKCHAIN VIEW START-----");
        ArrayList<String> logs=new ArrayList<>();
        for (Block block : blockchain.getBlocks()) {
            for (Payment payment : block.getData()) {
                logs.add("[BLOCK: "+block.getHash()+" TRX: "+block.getData().get(0).getSender()+block.getData().get(0).getPrice()+block.getData().get(0).getReceiver()+"]-->");
            }
        }
        log.error("-----DISCOVERY_SERVICE BLOCKCHAIN VIEW END-----");
    }

    public boolean validateTransaction(Payment trx) {
        double balance = 0;
        String sender_pk = trx.getSender();
        for (Block block : blockchain.getBlocks()) {
            for (Payment payment : block.getData()) {
                if (payment.getSender().equals(sender_pk)) {
                    balance -= Double.parseDouble(payment.getPrice());
                } else if (payment.getReceiver().equals(sender_pk)) {
                    balance += Double.parseDouble(payment.getPrice());
                }
            }
        }
        return !(balance < Double.parseDouble(trx.getPrice()));
    }
}
