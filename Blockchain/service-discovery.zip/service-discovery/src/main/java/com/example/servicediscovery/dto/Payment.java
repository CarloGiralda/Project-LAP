package com.example.servicediscovery.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.bouncycastle.util.encoders.Base64;

import java.io.IOException;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

@Getter
@Setter
@ToString
public class Payment implements Serializable {

    private String sender;
    private String receiver;
    private String price;
    private String signature;

    public boolean validateSignature() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException, InvalidKeySpecException {
        // TODO MAKE CONSISTENT WITH BLOCKCHAIN SERVICE
        byte[] publicKyeByte = Base64.decode(sender.getBytes());
        java.security.PublicKey publicKey1= KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(publicKyeByte));
        byte[] messageBytes = (sender+receiver+price).getBytes(StandardCharsets.UTF_8);
        Signature sign = Signature.getInstance("SHA256withRSA");
        sign.update(messageBytes);
        sign.initVerify(publicKey1);
        return sign.verify(signature.getBytes());
    }
}
