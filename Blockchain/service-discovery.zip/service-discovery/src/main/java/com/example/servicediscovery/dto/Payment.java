package com.example.servicediscovery.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.bouncycastle.util.encoders.Base64;

import java.io.IOException;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

@Getter
@Setter
public class Payment{

    private String sender;
    private String receiver;
    private String price;
    private String signature;

    public Payment(String sender,String receiver,String price,String signature){
        this.sender=sender;
        this.receiver=receiver;
        this.price=price;
        this.signature=signature;
    }

    public Payment(){

    }


    public boolean validateSignature() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException, InvalidKeySpecException {
        /*
        String sender="-----BEGIN PUBLIC KEY-----\n" +
                "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBALjXSDX42EXQEJBOf6batVGiVMlFawfP\n" +
                "20obS+HZHTzyqZT7lmfRP7cwi+wjDQSmqWFff46YJqY7xR+aOgLFYpcCAwEAAQ==\n" +
                "-----END PUBLIC KEY-----";

        String signature="Pmxdrb4LjENR5zlJqRcjuiQf44Ta9NedqkRWekYVsDloTNuejuJeZ3lZE1QAjzDTRmvVb8hTfBrHzcvkgMeX8g==";
        String msg="12";

         */
        String msg=sender+price;
        System.out.println(msg);
        String publicKeyPEM = sender
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll(System.lineSeparator(), "")
                .replace("-----END PUBLIC KEY-----", "");

        System.out.println(publicKeyPEM);

        byte[] encoded = Base64.decode(publicKeyPEM);


        java.security.PublicKey publicKey1= KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(encoded));
        byte[] messageBytes = msg.getBytes(StandardCharsets.UTF_8);
        Signature sign = Signature.getInstance("SHA256withRSA");
        sign.initVerify(publicKey1);
        sign.update(messageBytes);
        return sign.verify(Base64.decode(signature));
    }
}
