package com.example.servicediscovery.dto;


import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Payment implements Serializable {

    private String sender;
    private String receiver;
    private String price;

}
