package LAP.Blockchain.service;

import LAP.Blockchain.dto.Block;
import LAP.Blockchain.dto.Payment;
import LAP.Blockchain.model.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@PropertySource("classpath:application.properties")
@Service
@Slf4j
public class BlockchainService {
    private boolean found;
    private Block actualBlock;
    private Block nextBlock;
    private final Blockchain blockchain;
    private final ProducerService producerService;
    private boolean start;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private DiscoveryClientService discoveryClientService;
    private boolean criticalSection;

    public BlockchainService(Blockchain blockchain, ProducerService producerService) {
        this.found = false;
        this.blockchain = blockchain;
        this.producerService = producerService;
        this.start = true;
        this.criticalSection = false;
        this.actualBlock = new Block();
    }

    public int addTransaction(Payment payment) {
        try {
            log.error("BLOCKCHAIN_SERVICE RECEIVES PAYMENT FROM THE OTHER NODE: sender: {}price: {}receiver: {}", payment.getSender(), payment.getPrice(), payment.getReceiver());
            // VALIDATE SIGNATURE
            if (!(payment.validateSignature())) {
                log.error("BLOCKCHAIN_SERVICE SIGNATURE VALIDATION FAILED");
                return 0;
            }
            log.error("BLOCKCHAIN_SERVICE SIGNATURE VALIDATION SUCCESS");
            // VALIDATE TRANSACTION
            if (!(validateTransaction(payment))) {
                log.error("BLOCKCHAIN_SERVICE TRANSACTION VALIDATION FAILED");
                return 0;
            }
            log.error("BLOCKCHAIN_SERVICE TRANSACTION VALIDATION SUCCESS");
            // ADD TRANSACTION TO BLOCK TO MINE
            nextBlock.addToBlock(payment);
            // BROADCAST TRANSACTION TO NODES
            if (!payment.isValidated()) {
                // BROADCAST TO ALL THE DUMMY BLOCK TRANSACTION
                Block block = new Block("/");
                ArrayList<Payment> ap = new ArrayList<>();
                payment.setValidated(true);
                ap.add(payment);
                block.setData(ap);
                producerService.broadcastMessage(block);
            }

            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public ArrayList<Block> retrieveBlockchain() throws JsonProcessingException {
        String blockchainUrl = discoveryClientService.getServiceUrl("BLOCKCHAIN-SERVICE");
        String blockchainRetrieveUrl = blockchainUrl + "/blockchain/getBlockchain";

        // REST call to book service to know car availability
        ResponseEntity<ArrayList> blockchainResponseEntity = restTemplate.getForEntity(blockchainRetrieveUrl, ArrayList.class);
        String blockchain = new ObjectMapper().writeValueAsString(blockchainResponseEntity.getBody());
        ArrayList<Block> blocks = new ObjectMapper().readValue(blockchain, new TypeReference<ArrayList<Block>>() {});
        if (blockchainResponseEntity.getStatusCode() != HttpStatus.OK){
            throw new RuntimeException("error, cannot check car validity");
        }

        return blocks;
    }

    private List<ArrayList<Block>> branchesWithMaxLength(List<ArrayList<Block>> branches) {
        ArrayList<ArrayList<Block>> max_branches = new ArrayList<>();
        int max = 0;
        for (ArrayList<Block> branch : branches) {
            if (branch.size() > max) {
                max_branches.clear();
                max = branch.size();
                max_branches.add(branch);
            } else if (branch.size() == max) {
                max_branches.add(branch);
            }
        }
        return max_branches;
    }

    private void branchEvaluation(List<ArrayList<Block>> max_branches) {
        if (max_branches.size() == 1) {
            Collections.reverse(max_branches.get(0));
            actualBlock.setPreviousHash(max_branches.get(0).get(max_branches.get(0).size() - 1).getHash());
            //blockchain.setBlocks(max_branches);
            for (Payment p : actualBlock.getData()) {
                if (!validateTransaction(p)) {
                    actualBlock.getData().remove(p);
                }
            }
        } else {
            boolean isPreviousHashOfActualBlockInOneBlockchain = false;
            if (actualBlock.getPreviousHash() != null) {
                for (ArrayList<Block> branch : max_branches) {
                    Collections.reverse(branch);
                    if (actualBlock.getPreviousHash().equals(branch.get(branch.size() - 1).getHash())) {
                        isPreviousHashOfActualBlockInOneBlockchain = true;
                    }
                }
            }
            if (!isPreviousHashOfActualBlockInOneBlockchain) {
                actualBlock.setPreviousHash(max_branches.get(0).get(max_branches.get(0).size() - 1).getHash());
                for (Payment p : actualBlock.getData()) {
                    if (!validateTransaction(p)) {
                        actualBlock.getData().remove(p);
                    }
                }
            }
        }
    }

    private void setPreviousHashOfLongestBranch() {
        List<ArrayList<Block>> branches = blockchain.findBranches();
        List<ArrayList<Block>> max_branches = branchesWithMaxLength(branches);
        branchEvaluation(max_branches);
    }

    @Scheduled(fixedDelay = 10, initialDelay = 20000)
    public void mineBlock() throws JsonProcessingException {

        if (start) {
            blockchain.setBlocks(retrieveBlockchain());
            start = false;
        }
        found = false;

        // CREATE NEXT BLOCK
        nextBlock = new Block();

        // SET THE PREVIOUS HASH OF THE ACTUAL BLOCK AS THE HASH OF THE LAST BLOCK OF THE LONGEST CHAIN
        setPreviousHashOfLongestBranch();

        // DIFFICULTY
        // PREFIX
        int prefix = 5;
        // START MINING
        String prefixString = new String(new char[prefix]).replace('\0', '0');

        String hash;
        int count = 0;
        do {
            if (count == 50000) {
                count = 0;
                setPreviousHashOfLongestBranch();
            }
            count++;

            hash = actualBlock.singleMine();
        } while (!hash.substring(0, prefix).equals(prefixString) && !found);

        if (!found) {
            // NOTIFY THE OTHER NODE ABOUT THE HASH YOU FOUND
            producerService.broadcastMessage(actualBlock);
            log.error("BLOCKCHAIN_SERVICE NOTIFIES THE OTHER NODE ABOUT THE HASH FOUND");

            // IN BOTH CASES, THE BLOCK IS ADDED TO THE BLOCKCHAIN
            blockchain.addBlock(actualBlock);
            log.error("BLOCKCHAIN_SERVICE ADDS BLOCK: {} TO THE BLOCKCHAIN", actualBlock.getHash());
        }

        actualBlock = nextBlock;
    }

    public void checkBlock(Block block) {
        String hash = block.calculateBlockHash();
        if (hash.equals(block.getHash())) {
            found = true;
            blockchain.addBlock(block);
        }
    }

    @Scheduled(fixedRate = 10000)
    public void logging() {
        ArrayList<String> logs = new ArrayList<>();
        for (Block block : blockchain.getBlocks()) {
            String d=block.getData().isEmpty() ? block.getData().toString() : block.getData().get(0).getPrice();
            logs.add("[BLOCK: " + block.getHash() +" PREVIOUS: "+ block.getPreviousHash() + " DATA: "+ d +  "]-->\n");
        }
        log.error("\n-----BLOCKCHAIN-----\n"+logs);
    }

    public boolean validateTransaction(Payment trx) {
        double balance = 0;
        String sender_pk = trx.getSender();
        for (Block block : blockchain.getBlocks()) {
            for (Payment payment : block.getData()) {
                if (payment.getSender().equals(sender_pk)) {
                    balance -= Double.parseDouble(payment.getPrice());
                }
                if (payment.getReceiver().equals(sender_pk)) {
                    balance += Double.parseDouble(payment.getPrice());
                }
            }
        }
        return !(balance < Double.parseDouble(trx.getPrice()));
    }
}
