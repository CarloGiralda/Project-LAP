package LAP.Blockchain.dto;


import lombok.Getter;
import lombok.Setter;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.DigestInfo;
import org.bouncycastle.operator.DefaultDigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DigestAlgorithmIdentifierFinder;
import org.bouncycastle.util.encoders.Base64;

import javax.crypto.Cipher;
import java.io.IOException;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

@Getter
@Setter
public class Payment implements Serializable {

    private String sender;
    private String receiver;
    private String price;
    private String signature;


    public boolean validateSignature(String pubk) throws NoSuchAlgorithmException, IOException, SignatureException, InvalidKeyException, InvalidKeySpecException {

        byte[] publicKyeByte = Base64.decode(pubk.getBytes());
        java.security.PublicKey publicKey1= KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(publicKyeByte));
        byte[] messageBytes = (sender+receiver+price).getBytes(StandardCharsets.UTF_8);
        Signature sign = Signature.getInstance("SHA256withRSA");
        sign.update(messageBytes);
        sign.initVerify(publicKey1);
        return sign.verify(signature.getBytes());
    }

}
