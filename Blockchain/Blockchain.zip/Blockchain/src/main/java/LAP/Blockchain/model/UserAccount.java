package LAP.Blockchain.model;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.JdbcTypeCode;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Blob;
import java.util.List;
import java.util.logging.Level;

import static java.nio.charset.StandardCharsets.UTF_8;


@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Slf4j
@Table(name = "account")
public class UserAccount {
    @Id
    @SequenceGenerator(name = "account_gen", sequenceName = "account_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "account_gen")
    private Long id;
    private String sender;
    private String amount;



}