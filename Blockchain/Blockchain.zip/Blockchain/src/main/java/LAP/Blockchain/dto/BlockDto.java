package LAP.Blockchain.dto;


import LAP.Blockchain.dto.Payment;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.JdbcTypeCode;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Blob;
import java.util.List;
import java.util.logging.Level;

import static java.nio.charset.StandardCharsets.UTF_8;


@Getter
@Setter
@RequiredArgsConstructor
@Slf4j
public class BlockDto {
    private Long id;
    private String hash;
    private String previousHash;
    private String data;
    private long timeStamp;
    private int nonce;
    private String verifiedHash;

}
