package LAP.Blockchain.service;


import LAP.Blockchain.dto.Payment;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProducerService {

    @Autowired
    private RabbitTemplate template;

    public void broadcastMessage(Payment message) {
        this.template.convertAndSend("my-exchange", "", message);  // broadcasts string message to each my-queue-* via my-exchange
    }
}