package LAP.Blockchain.model;

import LAP.Blockchain.dto.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KeysRepository extends JpaRepository<Keys, Long> {
    Keys findBySender(String sender);
}
