package LAP.Blockchain.service;

import LAP.Blockchain.dto.Payment;
import LAP.Blockchain.model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;

import static java.nio.charset.StandardCharsets.UTF_8;

@Service
@AllArgsConstructor
@Slf4j
public class BlockchainService {

    private final KeysRepository keysRepository;
    private final UserAccountRepository userAccountRepository;
    private final BlockRepository blockRepository;
    private ArrayList<Block> tempBlockchain;

    public boolean validateTransaction(Payment trx) {
        UserAccount userAccount= userAccountRepository.findBySender(trx.getSender());
        return Long.parseLong(userAccount.getAmount())>=Long.parseLong(trx.getPrice());
    }

    public Block addToBlock(Payment trx) throws IOException {
        List<Block> blockchain = blockRepository.findAll();
        String previousHash=blockchain.get(blockchain.size() - 1).getHash();
        String data=trx.getSender()+trx.getReceiver()+trx.getPrice();
        long timestamp=new Date().getTime();
        Block newBlock = new Block();
        newBlock.setHash(calculateBlockHash(previousHash,timestamp,0,data));// TODO
        newBlock.setPreviousHash(previousHash);
        newBlock.setTimeStamp(timestamp);
        newBlock.setData(data);
        tempBlockchain.add(newBlock);
        return newBlock;
    }

    public String getPublic(String sender) throws IOException {
        // GET PUBLIC KEY
        return keysRepository.findBySender(sender).getPublicKey();
    }
    public String calculateBlockHash(String previousHash, long timeStamp, int nonce, String data) {
        String dataToHash = previousHash
                + Long.toString(timeStamp)
                + Integer.toString(nonce)
                + data;
        MessageDigest digest = null;
        byte[] bytes = null;
        try {
            digest = MessageDigest.getInstance("SHA-256");
            bytes = digest.digest(dataToHash.getBytes(UTF_8));
        } catch (NoSuchAlgorithmException ex) {
            log.info(ex.getMessage(), Level.SEVERE);
        }
        StringBuffer buffer = new StringBuffer();
        for (byte b : bytes) {
            buffer.append(String.format("%02x", b));
        }
        return buffer.toString();
    }
    public String mineBlock(int prefix, String hash, int nonce , long timestamp, String data) {
        String prefixString = new String(new char[prefix]).replace('\0', '0');
        while (!hash.substring(0, prefix).equals(prefixString)) {
            nonce++;
            hash = calculateBlockHash(hash,timestamp,nonce,data);
        }
        return hash;
    }

    public void addToBlockchain(Block block) {
        blockRepository.save(block);
    }
}
