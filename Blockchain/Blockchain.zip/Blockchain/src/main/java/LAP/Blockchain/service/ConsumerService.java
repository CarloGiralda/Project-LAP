package LAP.Blockchain.service;

import LAP.Blockchain.dto.Payment;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class ConsumerService {


    public void handleMessage(byte[] message) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Payment theResult = objectMapper.readValue(message, Payment.class);
        System.out.println("Message: " +theResult.getPrice());
    }
}
