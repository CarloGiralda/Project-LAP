package LAP.Blockchain.service;

import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

@Service
public class ConsumerService {

    @Bean
    public MessageListenerAdapter listenerAdapter(ConsumerService consumerService) {
        return new MessageListenerAdapter(consumerService, "handleMessage");
    }

    public void handleMessage(String message) {
        System.out.println("Message: " + message);
    }
}
