package LAP.Blockchain.controller;


import LAP.Blockchain.dto.BlockDto;
import LAP.Blockchain.dto.Payment;
import LAP.Blockchain.model.Block;
import LAP.Blockchain.service.BlockchainService;
import LAP.Blockchain.service.ProducerService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;


@Slf4j
@AllArgsConstructor
@RequestMapping(path = "/blockchain")
@RestController
public class BlockchainController {

    private final ProducerService producerService;
    private final BlockchainService blockchainService;
    private int nodes;

    @PostMapping(path = "/addTransaction") // RECEIVE TRANSACTION FROM HERE
    @ResponseBody
    public ResponseEntity<String> insertTransaction(@RequestBody Payment payment) {
        try {
            if(Objects.isNull(payment)) return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Serialization Error");
            else {
                System.out.println("Received payment from gateway, broadcast to all nodes "+payment);
                // GET PUBLIC KEY FROM DB
                String pubk =blockchainService.getPublic(payment.getSender());
                // VALIDATE SIGNATURE
                if(!(payment.validateSignature(pubk))){
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("TRANSACTION ERROR "+ "SIGNATURE VERIFICATION FAILED");
                }
                // BROADCAST TRANSACTION TO NODES
                producerService.broadcastMessage(payment);
                // VALIDATE TRANSACTION
                if(!(blockchainService.validateTransaction(payment))){
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("TRANSACTION ERROR "+ "SIGNATURE VERIFICATION FAILED");
                }
                // ADD TRANSACTION TO BLOCK
                Block b=blockchainService.addToBlock(payment);
                // START CONSENSUS
                String hash= blockchainService.mineBlock(1, b.getHash(),0,b.getTimeStamp(),b.getData());
                // BROADCAST SOLVED BLOCK TO NODES
                BlockDto blockDto=new BlockDto();
                blockDto.setData(b.getData());
                blockDto.setTimeStamp(b.getTimeStamp());
                blockDto.setHash(b.getHash());
                blockDto.setPreviousHash(b.getPreviousHash());
                blockDto.setVerifiedHash(hash);
                blockDto.setNonce(b.getNonce());
                blockDto.setId(b.getId());
                producerService.broadcastMessage(blockDto);
                // ATTENDS OTHER VALIDATE BLOCK, CONFIRMATION FROM OTHERS
                nodes++;
                while(nodes!=2){ // TODO
                    ;
                }
                // ADD BLOCK TO BLOCKCHAIN
                blockchainService.addToBlockchain(b);
                return ResponseEntity.status(HttpStatus.OK).body("YOUR TRANSACTION HAS BEEN SUCCESSFULLY REGISTERED");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("TRANSACTION ERROR "+ e.getMessage());
        }
    }


}
