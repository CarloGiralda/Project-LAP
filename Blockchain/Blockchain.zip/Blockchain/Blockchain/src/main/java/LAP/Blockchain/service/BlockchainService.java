package LAP.Blockchain.service;

import LAP.Blockchain.dto.Block;
import LAP.Blockchain.dto.Payment;
import LAP.Blockchain.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@PropertySource("classpath:application.properties")
@Service
@Slf4j
public class BlockchainService {
    private boolean found;
    private Block actualBlock;
    private final Blockchain blockchain;
    private final ProducerService producerService;
    @Value("${publickey}")
    private String publickey;
    @Value("${privatekey}")
    private String privatekey;

    public BlockchainService(Blockchain blockchain, ProducerService producerService) {
        this.found = false;
        this.blockchain = blockchain;
        this.producerService = producerService;
    }

    public int addTransaction(Payment payment) {
        try {
            System.out.println("Received payment from gateway, broadcast to all nodes " + payment);
            // VALIDATE SIGNATURE
            if (!(payment.validateSignature())) {
                System.out.println("SIGNATURE VERIFICATION FAILED");
                return 0;
            }
            // BROADCAST TRANSACTION TO NODES
            producerService.broadcastMessage(payment);
            // VALIDATE TRANSACTION
            if (!(validateTransaction(payment))) {
                System.out.println("TRANSACTION VERIFICATION FAILED");
                return 0;
            }
            // ADD TRANSACTION TO BLOCK
            actualBlock.addToBlock(payment);
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    @Scheduled
    public void mineBlock() {
        found = false;
        // TAKE LAST BLOCK OF THE BLOCKCHAIN
        Block last = blockchain.getLastBlock();
        // CREATE NEW BLOCK
        actualBlock = new Block(last.getPreviousHash());
        // PREFIX
        int prefix = 1;
        // START MINING
        String prefixString = new String(new char[prefix]).replace('\0', '0');
        String hash;
        do {
            hash = actualBlock.singleMine();
        } while (!hash.substring(0, prefix).equals(prefixString) && !found);

        if (!found) {
            // NOTIFY THE OTHER NODE ABOUT THE HASH YOU FOUND
            producerService.broadcastMessage(actualBlock);
        }
        // IN BOTH CASES, THE BLOCK IS ADDED TO THE BLOCKCHAIN
        blockchain.addBlock(actualBlock);
    }

    public void checkBlock(Block block) {
        String hash = block.calculateBlockHash();
        if (hash.equals(block.getHash())) {
            found = true;
        }
    }

    public boolean validateTransaction(Payment trx) {
        double balance = 0;
        String sender_pk = trx.getSender();
        for (Block block : blockchain.getBlocks()) {
            for (Payment payment : block.getData()) {
                if (payment.getSender().equals(sender_pk)) {
                    balance -= Double.parseDouble(payment.getPrice());
                } else if (payment.getReceiver().equals(sender_pk)) {
                    balance += Double.parseDouble(payment.getPrice());
                }
            }
        }
        return !(balance < Double.parseDouble(trx.getPrice()));
    }
}
