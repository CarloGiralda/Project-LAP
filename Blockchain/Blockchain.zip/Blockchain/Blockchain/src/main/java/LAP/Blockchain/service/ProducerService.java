package LAP.Blockchain.service;


import LAP.Blockchain.dto.Payment;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.SerializationUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

@Service
public class ProducerService {

    @Autowired
    private RabbitTemplate template;

    public void broadcastMessage(Object message) {

        this.template.convertAndSend("my-exchange", "", message);  // broadcasts string message to each my-queue-* via my-exchange
    }
}