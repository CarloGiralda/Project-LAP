package LAP.Blockchain.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.openssl.PEMException;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.util.encoders.Base64;

import java.io.IOException;
import java.io.Serializable;
import java.io.StringReader;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;

import static org.bouncycastle.asn1.x509.ObjectDigestInfo.publicKey;


@Getter
@Setter
@ToString
public class Payment implements Serializable {

    private String sender;
    private String receiver;
    private String price;
    private String signature;

    public boolean validateSignature() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException, InvalidKeySpecException, IOException {

        /*
        //  TODO IT DOES NOT WORK
        String sender="MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKMyaAkb0TyzsU/4z0qhIRK8zEfOb36d/YVKSFjgTkJBMkDVxnMyracNZ76Z9bnx5f2EeSxvZezgbfzq5YRb0QsCAwEAAQ==";

        String signature="iC/+pqD7wpNY50mdztfAyVsJS1xE2IcIN9n18ZpraKYzxSp8CAYb9LlGNUwo5rAh9v2u+M4R9SNn1X5Ve2HpDg==";
        String msg="MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKMyaAkb0TyzsU/4z0qhIRK8zEfOb36d/YVKSFjgTkJBMkDVxnMyracNZ76Z9bnx5f2EeSxvZezgbfzq5YRb0QsCAwEAAQ==MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKVd+6UWOjpTYNapknAfNGXPecBJbW1oDqvkZgjVgCklF2mggQuL71726dTmW80fzg5PFW94yKO/XFnmAqC21WcCAwEAAQ==12";

        byte[] publicKyeByte = sender.getBytes();

        java.security.PublicKey pubk= KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(publicKyeByte));

        Signature signature2 = Signature.getInstance("SHA256withRSA");

        signature2.initVerify(pubk);
        signature2.update(msg.getBytes());
        return signature2.verify(signature.getBytes());

         */
        // TODO IT DOES NOT WORK
        String sender="-----BEGIN PUBLIC KEY-----MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKMyaAkb0TyzsU/4z0qhIRK8zEfOb36d/YVKSFjgTkJBMkDVxnMyracNZ76Z9bnx5f2EeSxvZezgbfzq5YRb0QsCAwEAAQ==-----END PUBLIC KEY-----";
        String signature="iC/+pqD7wpNY50mdztfAyVsJS1xE2IcIN9n18ZpraKYzxSp8CAYb9LlGNUwo5rAh9v2u+M4R9SNn1X5Ve2HpDg==";
        String msg="MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKMyaAkb0TyzsU/4z0qhIRK8zEfOb36d/YVKSFjgTkJBMkDVxnMyracNZ76Z9bnx5f2EeSxvZezgbfzq5YRb0QsCAwEAAQ==MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKVd+6UWOjpTYNapknAfNGXPecBJbW1oDqvkZgjVgCklF2mggQuL71726dTmW80fzg5PFW94yKO/XFnmAqC21WcCAwEAAQ==12";

        byte[] keyBytes = sender.getBytes(StandardCharsets.UTF_8);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey key = keyFactory.generatePublic(spec);

        Signature signature2 = Signature.getInstance("SHA256withRSA");

        signature2.initVerify(key);
        signature2.update(Base64.decode(msg));
        return signature2.verify(Base64.decode(signature));


        /*

         //   TODO IT WORKS BUT ON LOCAL GENERATED KEYS

        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(512); // Specify the desired key size
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        PrivateKey privateKey = keyPair.getPrivate();
        PublicKey publicKey = keyPair.getPublic();
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashedData = digest.digest(msg.getBytes(StandardCharsets.UTF_8));
        Signature signature1 = Signature.getInstance("SHA256withRSA");
        signature1.initSign(privateKey);
        signature1.update(hashedData);
        byte[] signedHash = signature1.sign();
        Signature signature3 = Signature.getInstance("SHA256withRSA");
        signature3.initVerify(publicKey);
        signature3.update(hashedData);
        boolean isValid = signature3.verify(signedHash);

         */





    }
}
