package LAP.Blockchain.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.openssl.PEMException;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.util.encoders.Base64;

import java.io.IOException;
import java.io.Serializable;
import java.io.StringReader;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Random;

import static org.bouncycastle.asn1.x509.ObjectDigestInfo.publicKey;


@Getter
@Setter
public class Payment {

    private String sender;
    private String receiver;
    private String price;
    private String signature;

    public Payment(String sender,String receiver,String price,String signature){
        this.sender=sender;
        this.receiver=receiver;
        this.price=price;
        this.signature=signature;
    }

    public Payment(){

    }
    public boolean validateSignature() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException, InvalidKeySpecException, IOException {
        /*
        String test="-----BEGIN PUBLIC KEY-----\n" +
                "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKIXLQk/7rE9PwZCUabJLyW1EqYNQu1O\n" +
                "Liw52Rw5bx/oZgs6FavGmNw8eXn+IJi2WWrsuwC1ST+DZd+WEduf9RECAwEAAQ==\n" +
                "-----END PUBLIC KEY-----";

        String signature="GRPMifEnJXxjnMIle2+rwxhEs20XtL3IQmWflIVX/7b4Kry/1GT+RRk0seYFz0nosZyofW0qcyGw+FwWuD/Lmw==";
        String msg="0";

         */
        System.out.println(signature);
        String msg=price;
        System.out.println(msg);
        String publicKeyPEM = sender
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll(System.lineSeparator(), "")
                .replace("-----END PUBLIC KEY-----", "");

        System.out.println(publicKeyPEM);

        byte[] encoded = Base64.decode(publicKeyPEM);


        java.security.PublicKey publicKey1= KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(encoded));
        byte[] messageBytes = msg.getBytes(StandardCharsets.UTF_8);
        Signature sign = Signature.getInstance("SHA256withRSA");
        sign.initVerify(publicKey1);
        sign.update(messageBytes);
        return sign.verify(Base64.decode(signature));

    }
}
