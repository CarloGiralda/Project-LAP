package LAP.Blockchain.model;

import LAP.Blockchain.dto.Block;
import lombok.Getter;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
@Getter
public class Blockchain {
    private ArrayList<Block> blocks;

    public Blockchain() {
        blocks = new ArrayList<>();
        generateGenesis();
    }

    public void generateGenesis() {
        Block genesis = new Block("Genesis Block");
        blocks.add(genesis);
    }

    public void addBlock(Block block) {
        blocks.add(block);
    }

    public Block getLastBlock() {
        int last = blocks.size() - 1;
        return blocks.get(last);
    }
}
