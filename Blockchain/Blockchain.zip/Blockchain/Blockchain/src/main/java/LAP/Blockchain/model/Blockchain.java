package LAP.Blockchain.model;

import LAP.Blockchain.dto.Block;
import LAP.Blockchain.dto.Payment;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.lang.reflect.Array;
import java.util.*;


@Component
@Getter
@Setter
public class Blockchain {
    private ArrayList<Block> blocks;


    public Blockchain() {
        blocks = new ArrayList<>();
        generateGenesis();
    }

    public void generateGenesis() {
        Block genesis = new Block("Genesis Block");
        // DEFAULT COUNTS
        Payment p=new Payment("Genesis Block","-----BEGIN PUBLIC KEY-----MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJIX5lWi3q3Zzb8hFuEVTwm9bfj/f5aAU5N6ynQE7fvpiQzv68zaeOqQ41lVp/bIFTgY+vKvoIZH/X87xt6lwpUCAwEAAQ==-----END PUBLIC KEY-----","1000","");
        ArrayList<Payment> ap=new ArrayList<>();
        ap.add(p);
        genesis.setData(ap);
        blocks.add(genesis);
    }



    public List<ArrayList<Block>> findBranches() {
        List<ArrayList<Block>> branches = new ArrayList<>();
        Set<Long> visited = new HashSet<>();
        for (int i = blocks.size()-1; i >= 0; i--) {
            if (!visited.contains(blocks.get(i).getTimeStamp())) {
                ArrayList<Block> branch = traverseBranch(blocks.get(i), visited);
                branches.add(branch);
            }
        }

        return branches;
    }

    private ArrayList<Block> traverseBranch(Block block,  Set<Long> visited) {
        ArrayList<Block> branch = new ArrayList<>();
        Block currentBlock = block;

        while (currentBlock != null ) {
            branch.add(currentBlock);
            if (!visited.contains(currentBlock.getTimeStamp())) {
                visited.add(currentBlock.getTimeStamp());
            }

            // Find the next block in the branch based on the previous hash
            Block nextBlock = findBlockByHash(currentBlock.getPreviousHash());
            if (nextBlock != null) {
                currentBlock = nextBlock;
            } else {
                currentBlock = null;
            }
        }

        return branch;
    }

    private Block findBlockByHash(String targetHash) {
        for (Block block : blocks) {
            if (block.getHash().equals(targetHash)) {
                return block;
            }
        }
        return null;
    }
    public void addBlock(Block block) {
        blocks.add(block);
    }

    public Block getLastBlock() {
        int last = blocks.size() - 1;
        return blocks.get(last);
    }
}
