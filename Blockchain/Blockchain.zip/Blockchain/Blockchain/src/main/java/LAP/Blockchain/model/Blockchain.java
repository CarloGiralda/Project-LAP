package LAP.Blockchain.model;

import LAP.Blockchain.dto.Block;
import LAP.Blockchain.dto.Payment;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.lang.reflect.Array;
import java.util.*;


@Component
@Getter
@Setter
public class Blockchain {
    private ArrayList<Block> blocks;

    public Blockchain() {
        blocks = new ArrayList<>();
        generateGenesis();
    }

    public void generateGenesis() {
        Payment p = new Payment(0L, "Genesis Block","-----BEGIN PUBLIC KEY-----" +
                "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDpKyJT0pLCI0qz6gpZX6eKWa3L" +
                "jukHTDNfo8uDuhDrKUfanyNeZ4FG9dIVu1B8EOKaSQ4TpmBFMtFZQK4j3Djz66DR" +
                "ULsK64esi/QtSy6c6yHDGwfZcpnPAHc8p770dyCR4EXTcInKOeHgsxMDXX2cmO1D" +
                "5xpgQcrh/cGMtLVtZQIDAQAB" +
                "-----END PUBLIC KEY-----","1000000","");
        Block genesis = new Block("None", p);
        blocks.add(genesis);
    }

    public List<ArrayList<Block>> findBranches() {
        List<ArrayList<Block>> branches = new ArrayList<>();
        Set<Long> visited = new HashSet<>();
        for (int i = blocks.size()-1; i >= 0; i--) {
            if (!visited.contains(blocks.get(i).getTimeStamp())) {
                ArrayList<Block> branch = traverseBranch(blocks.get(i), visited);
                branches.add(branch);
            }
        }

        return branches;
    }

    private ArrayList<Block> traverseBranch(Block block,  Set<Long> visited) {
        ArrayList<Block> branch = new ArrayList<>();
        Block currentBlock = block;

        while (currentBlock != null ) {
            branch.add(currentBlock);
            if (!visited.contains(currentBlock.getTimeStamp())) {
                visited.add(currentBlock.getTimeStamp());
            }

            // Find the next block in the branch based on the previous hash
            Block nextBlock = findBlockByHash(currentBlock.getPreviousHash());
            if (nextBlock != null) {
                currentBlock = nextBlock;
            } else {
                currentBlock = null;
            }
        }

        return branch;
    }

    private Block findBlockByHash(String targetHash) {
        for (Block block : blocks) {
            if (block.getHash().equals(targetHash)) {
                return block;
            }
        }
        return null;
    }
    public void addBlock(Block block) {
        blocks.add(block);
    }

    public Block getLastBlock() {
        int last = blocks.size() - 1;
        return blocks.get(last);
    }
}
