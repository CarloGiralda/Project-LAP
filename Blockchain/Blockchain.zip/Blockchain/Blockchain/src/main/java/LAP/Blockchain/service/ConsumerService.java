package LAP.Blockchain.service;

import LAP.Blockchain.dto.Block;
import LAP.Blockchain.dto.Payment;
import LAP.Blockchain.model.Blockchain;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

@AllArgsConstructor
@Service
public class ConsumerService {
    private final BlockchainService blockchainService;



    public void handleMessage(byte[] message) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Block block = objectMapper.readValue(message, Block.class);
        // RECEIVE TRANSACTION FROM OTHERS
        System.out.println("RECEIVED BLOCK FROM EUREKA" + message);
        if (block.getHash() == null) {
            blockchainService.addTransaction(block.getData().get(0));
        } else {
            blockchainService.checkBlock(block);
        }
        }
    }



