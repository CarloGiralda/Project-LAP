package LAP.Blockchain.service;

import LAP.Blockchain.dto.Block;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class ConsumerService {
    private BlockchainService blockchainService;

    public void handleMessage(byte[] message) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Block block = objectMapper.readValue(message, Block.class);

        if (block.getHash() == null) {
            blockchainService.addTransaction(block.getData().get(0));
        } else {
            blockchainService.checkBlock(block);
        }
    }
}
