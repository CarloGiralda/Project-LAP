package LAP.Blockchain.service;

import LAP.Blockchain.dto.Block;
import LAP.Blockchain.dto.Payment;
import LAP.Blockchain.model.*;
import LAP.Blockchain.repository.CredentialsRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;

@PropertySource("classpath:application.properties")
@Service
@Slf4j
public class BlockchainService {
    private boolean found;
    private Block actualBlock;
    private final Blockchain blockchain;
    private final ProducerService producerService;
    private final CredentialsRepo credentialsRepo;

    public BlockchainService(Blockchain blockchain, ProducerService producerService, CredentialsRepo credentialsRepo) {
        this.credentialsRepo = credentialsRepo;
        this.found = false;
        this.blockchain = blockchain;
        this.producerService = producerService;
    }

    public int addTransaction(Payment payment) {
        try {
            log.error("BLOCKCHAIN_SERVICE RECEIVES PAYMENT FROM THE OTHER NODE: sender: {}price: {}receiver: {}", payment.getSender(), payment.getPrice(), payment.getReceiver());
            // VALIDATE SIGNATURE
            if (!(payment.validateSignature())) {
                log.error("BLOCKCHAIN_SERVICE SIGNATURE VALIDATION FAILED");
                return 0;
            }
            log.error("BLOCKCHAIN_SERVICE SIGNATURE VALIDATION SUCCESS");
            // VALIDATE TRANSACTION
            if (!(validateTransaction(payment))) {
                log.error("BLOCKCHAIN_SERVICE TRANSACTION VALIDATION FAILED");
                return 0;
            }
            log.error("BLOCKCHAIN_SERVICE TRANSACTION VALIDATION SUCCESS");
            // ADD TRANSACTION TO BLOCK
            actualBlock.addToBlock(payment);
            // BROADCAST TRANSACTION TO NODES
            producerService.broadcastMessage(actualBlock);

            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    @Scheduled(fixedRate = 10000)
    public void mineBlock() {

        found = false;
        // TAKE LAST BLOCK OF THE BLOCKCHAIN
        Block last = blockchain.getLastBlock();
        // CREATE NEW BLOCK
        actualBlock = new Block(last.getPreviousHash());
        // PREFIX
        int prefix = 1;
        // START MINING
        String prefixString = new String(new char[prefix]).replace('\0', '0');
        String hash;
        int count=0;
        int v=0;
        ArrayList<Block> temp=new ArrayList<>();
        ArrayList<ArrayList<Block>> temp2=new ArrayList<>();
        HashSet<Integer> hs=new HashSet<>();
        do {
            if(count==100000) {
                count=0;
                List<ArrayList<Block>> branches = blockchain.findBranches();
                HashMap<List<Block>, Integer> l = new HashMap<>();
                for (ArrayList<Block> branch : branches) {
                    if (branch.size()>v) {
                        l.clear();
                        v=branch.size();
                        temp=branch;
                        l.put(branch, v);
                    }else if (branch.size()==v){
                        l.put(branch,v);
                        temp2.add(branch);
                    }
                }
                if (l.size()==1){
                    Collections.reverse(temp);
                    actualBlock.setPreviousHash(temp.get(temp.size()-1).getHash());
                    blockchain.setBlocks(temp);
                    for (Payment p: actualBlock.getData() ){
                        if(!validateTransaction(p)){
                            actualBlock.getData().remove(p);
                        }
                    }
                } else {
                    boolean u=false;
                    for (ArrayList<Block> branch: temp2) {
                        Collections.reverse(branch);
                        if(actualBlock.getPreviousHash().equals(branch.get(branch.size() - 1).getHash())){
                            u=true;
                        }
                    }
                    if (!u){
                        actualBlock.setPreviousHash(temp2.get(0).get(temp2.get(0).size()-1).getHash());
                        for (Payment p: actualBlock.getData()){
                            if(!validateTransaction(p)){
                                actualBlock.getData().remove(p);
                            }
                        }
                    }
                }

            }
            count++;
            hash = actualBlock.singleMine();
        } while (!hash.substring(0, prefix).equals(prefixString) && !found);

        if (!found) {
            // NOTIFY THE OTHER NODE ABOUT THE HASH YOU FOUND
            log.error("BLOCKCHAIN_SERVICE NOTIFIES THE OTHER NODE ABOUT THE HASH FOUND");
            producerService.broadcastMessage(actualBlock);
        }
        // IN BOTH CASES, THE BLOCK IS ADDED TO THE BLOCKCHAIN
        blockchain.addBlock(actualBlock);
        log.error("BLOCKCHAIN_SERVICE ADDS BLOCK: {} TO THE BLOCKCHAIN", actualBlock.getHash());
        //LOGGING
        logging();
    }

    public void checkBlock(Block block) {
        String hash = block.calculateBlockHash();
        if (hash.equals(block.getHash())) {
            found = true;
        }
    }

    public void logging() {
        ArrayList<String> logs = new ArrayList<>();
        for (Block block : blockchain.getBlocks()) {
            for (Payment payment : block.getData()) {
                logs.add("[BLOCK: " + block.getHash() + " TRX: " + block.getData().get(0).getSender() + block.getData().get(0).getPrice() + block.getData().get(0).getReceiver() + "]-->");
            }
        }
    }

    public boolean validateTransaction(Payment trx) {
        double balance = 0;
        String sender_pk = trx.getSender();
        for (Block block : blockchain.getBlocks()) {
            for (Payment payment : block.getData()) {
                if (payment.getSender().equals(sender_pk)) {
                    balance -= Double.parseDouble(payment.getPrice());
                } else if (payment.getReceiver().equals(sender_pk)) {
                    balance += Double.parseDouble(payment.getPrice());
                }
            }
        }
        return !(balance < Double.parseDouble(trx.getPrice()));
    }

    public Credentials retrieveCredentials(String username) {
        return credentialsRepo.findByUsername(username);
    }
}
