package LAP.Blockchain.controller;


import LAP.Blockchain.dto.Payment;
import LAP.Blockchain.dto.PaymentDTO;
import LAP.Blockchain.model.Credentials;
import LAP.Blockchain.service.BlockchainService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.util.encoders.Base64;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Objects;


@Slf4j
@AllArgsConstructor
@RequestMapping(path = "/blockchain")
@RestController
public class BlockchainController {
    private final BlockchainService blockchainService;

    @PostMapping(path = "/addTransaction") // RECEIVE TRANSACTION FROM HERE
    @ResponseBody
    public ResponseEntity<String> insertTransaction(@RequestBody PaymentDTO paymentDTO) {
        try {
            Credentials sender = blockchainService.retrieveCredentials(paymentDTO.getSender_username());
            Credentials receiver = blockchainService.retrieveCredentials(paymentDTO.getReceiver_username());

            String signature = createSignature(sender.getPrivate_key(), sender.getPublic_key() + receiver.getPublic_key() + paymentDTO.getPrice());

            Payment payment = new Payment(sender.getPublic_key(), receiver.getPublic_key(), paymentDTO.getPrice(), signature);
            int res = blockchainService.addTransaction(payment);
            if (res == 1) {
                return ResponseEntity.status(HttpStatus.OK).body("YOUR TRANSACTION HAS BEEN SUCCESSFULLY REGISTERED");
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("YOUR TRANSACTION HAS BEEN REFUSED");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("TRANSACTION ERROR "+ e.getMessage());
        }
    }

    private String createSignature(String privKey, String data) throws NoSuchAlgorithmException, SignatureException, InvalidKeySpecException, InvalidKeyException, UnsupportedEncodingException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashedData = digest.digest(data.getBytes(StandardCharsets.UTF_8));

        String privateKeyPEM = privKey
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replaceAll(System.lineSeparator(), "")
                .replace("-----END PRIVATE KEY-----", "");

        byte[] keyBytes = Base64.decode(privateKeyPEM.getBytes("utf-8"));
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory fact = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = fact.generatePrivate(keySpec);

        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        signature.update(hashedData);
        byte[] signedHash = signature.sign();

        return Base64.toBase64String(signedHash);
    }
}
