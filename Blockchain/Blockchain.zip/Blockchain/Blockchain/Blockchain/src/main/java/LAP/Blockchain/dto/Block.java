package LAP.Blockchain.dto;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;

import static java.nio.charset.StandardCharsets.UTF_8;

@Getter
@Setter
@NoArgsConstructor
@Slf4j
public class Block implements Serializable {
    private String hash;
    private String previousHash;
    private ArrayList<Payment> data;
    private long timeStamp;
    private long nonce;
    public Block(String previousHash) {
        this.data = new ArrayList<>();
        this.previousHash = previousHash;
        this.timeStamp = Instant.now().toEpochMilli();
        Random rand = new Random();
        this.nonce = rand.nextLong();
        this.hash = calculateBlockHash();
    }

    public String calculateBlockHash() {
        String d=data.isEmpty() ? data.toString() : data.get(0).getSender()+data.get(0).getReceiver()+data.get(0).getPrice();
        String t= this.getPreviousHash().equals("Genesis Block") ? "" : Long.toString(timeStamp);
        String n= this.getPreviousHash().equals("Genesis Block") ? "0" : Long.toString(nonce);
        String dataToHash = previousHash
                + t
                + n
                + d;

        MessageDigest digest = null;
        byte[] bytes = null;
        try {
            digest = MessageDigest.getInstance("SHA-256");
            bytes = digest.digest(dataToHash.getBytes(UTF_8));
        } catch (NoSuchAlgorithmException ex) {
            log.info(ex.getMessage(), Level.SEVERE);
        }
        StringBuffer buffer = new StringBuffer();
        for (byte b : bytes) {
            buffer.append(String.format("%02x", b));
        }
        return buffer.toString();
    }

    public String singleMine() {
        nonce++;
        hash = calculateBlockHash();
        return hash;
    }

    public void addToBlock(Payment trx) throws IOException {
        this.data.add(trx);
    }
}
