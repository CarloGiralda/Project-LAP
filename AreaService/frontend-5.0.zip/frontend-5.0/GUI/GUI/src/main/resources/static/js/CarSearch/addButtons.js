function addButtons() {
    var rowsAdded = sessionStorage.getItem("NumberOfLists");
    var cont = document.getElementById("list");

    for(var x= 0; x < rowsAdded; x++) {

        var btn = document.createElement("button");
        btn.setAttribute("id",sessionStorage.getItem("List: " + x + " / Field: cid"));
        btn.setAttribute("class","btn btn-danger btn-block");
        var t = document.createTextNode(String(sessionStorage.getItem("List: " + x + " / Field: brand")) + " model " + String(sessionStorage.getItem("List: " + x + " / Field: model")));
        btn.appendChild(t);
        // in order to pass the param 'x' (number of the list from which we pick the correct car), the param is saved into a custom field customField of the button
        // it is accessed inside the function through the 'event' param (standard param for functions inside addEventListener)
        btn.customField = x;
        btn.addEventListener('click', function changePage(event) {
            var getUrl = "http://localhost:8080/carrating/" + sessionStorage.getItem("List: " + event.currentTarget.customField + " / Field: cid");
            var successUrl = "http://localhost:8081/carsearch/" + sessionStorage.getItem("List: " + event.currentTarget.customField + " / Field: cid");
            var problemUrl = "http://localhost:8081/failed";

            var token = getCookie("jwtToken");

            fetch(getUrl, {
                method: 'GET',
                headers: {
                    'Authorization': "Bearer " + token
                },
            })
                .then(function(response) {
                    return response.json();
                })
                .then(function(body) {
                    for (let x = 0; x < body.length; x++) {
                        sessionStorage.setItem(x + " / stars", body[x]["stars"]);
                        sessionStorage.setItem(x + " / date", body[x]["date"]);
                        sessionStorage.setItem(x + " / description", body[x]["description"]);
                        sessionStorage.setItem(x + " / madeByUser", body[x]["madeByUser"]);
                    }
                    sessionStorage.setItem("NumberOfReviews: ", body.length);
                })
                .then(function() {
                    window.location.href = successUrl;
                });
        }, false);
        cont.appendChild(btn);
    }
}