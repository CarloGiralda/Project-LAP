document.addEventListener("DOMContentLoaded", function () {
    // Check if the user is authenticated based on the presence of the HttpOnly cookie
    const isAuthenticated = document.cookie.includes('jwtToken')
    const usernameDisplay = document.getElementById('usernameDisplay')
    const userDropDown = document.getElementById('userDropDown')

    console.log("user is authenticated:", isAuthenticated)

    if (isAuthenticated && usernameDisplay) {

        // read name from session storage and show to the user
        usernameDisplay.textContent = sessionStorage.getItem("username")

        // show user dropdown
        userDropDown.style.display = 'block'
    }

});
var username= sessionStorage.getItem("username");
var token = getCookie("jwtToken");

function submitForm() {
    // Replace these URLs with the ones you want to use
    var postUrl = "http://localhost:8080/insurance/insertInsurance?username="+username;
    var successUrl = "http://localhost:8081/pages/?type=Upload/uploadSuccess";

    // Get form data
    var formData = new FormData(document.getElementById("myForm"));


    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Set up the request
    xhr.open("POST", postUrl, true);
    xhr.setRequestHeader('Authorization', 'Bearer '+token);


    // Define what happens on successful data submission
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Redirect to the success page
            console.log("success");
        }else{
        console.log("problem");

        }
    };

    // Send the form data
    xhr.send(formData);
}
function submitForm2() {
    // Replace these URLs with the ones you want to use
    var id = document.getElementById("id").value;
    var getUrl = "http://localhost:8080/insurance/showInsurance?id="+id;
    var successUrl = "http://localhost:8081/pages/?type=Upload/uploadSuccess";
    var problemUrl = "http://localhost:8081/pages/?type=Problem/problem";


    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Set up the request
    xhr.open("GET", getUrl, true);
    xhr.responseType = 'blob';
    xhr.setRequestHeader('Authorization', 'Bearer '+token);


    // Define what happens on successful data submission
    xhr.onload = function (e) {
        var blob = e.currentTarget.response;
        var contentDispo = e.currentTarget.getResponseHeader('Content-Disposition');
        // https://stackoverflow.com/a/23054920/
        var fileName = contentDispo.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/)[1];
        var a = document.createElement("a");
            document.body.appendChild(a);
            a.style = "display: none";
            saveBlob(blob, fileName);

    };



    // Send the form data
    xhr.send();
}

function saveBlob(blob, fileName) {
                       var a = document.createElement('a');
                       a.href = window.URL.createObjectURL(blob);
                       a.download = fileName;
                       a.dispatchEvent(new MouseEvent('click'));
                   }