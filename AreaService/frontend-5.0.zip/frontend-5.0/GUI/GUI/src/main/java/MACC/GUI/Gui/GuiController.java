package MACC.GUI.Gui;


import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;

import org.json.JSONException;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

import java.lang.reflect.Type;
import java.net.URI;


import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;


import static org.springframework.web.bind.annotation.RequestMethod.GET;

@Slf4j
@Controller
public class GuiController {
    @RequestMapping(path="/")
    public String getHome(){ return "templates/index"; }

    @RequestMapping(path="/api/email")
    public String getConfirmationPage(){ return "templates/Email/confirmationEmail"; }
    @RequestMapping(path="/pages")
    public String getSuccessPage(@Param("type") String type){ return "templates/"+ type; }

    @RequestMapping(path="/searchbar")
    public String getOfferForm() { return "templates/CarSearch/form"; }
    @RequestMapping(path="/listcars")
    public String getOfferForm2() { return "templates/CarSearch/cars"; }
    @RequestMapping(path = "/carsearch/{id}")
    public String getCarDetails(@PathVariable String id) { return "templates/CarSearch/carRetrieved"; }

    @RequestMapping(path="/carinsert/insertoffer")
    public String getOfferForm3() { return "templates/CarInsertion/offerForm"; }
    @RequestMapping(path="/carinsert/insertcar")
    public String getOfferForm4() { return "templates/CarInsertion/carForm"; }
    @RequestMapping(path="/carinsert/insertutilities")
    public String getOfferForm5() { return "templates/CarInsertion/utilitiesForm"; }

    @RequestMapping(path="/success")
    public String getOfferForm6() { return "templates/CarInsertion/success"; }
    @RequestMapping(path="/failed")
    public String getOfferForm7() { return "templates/CarInsertion/failed"; }

    @RequestMapping(path="/userSettings")
    public String getUserSettingsPage(){ return "templates/UserSettings/userSettings"; }
    @RequestMapping(path="/recovery")
    public String getRecoveryPage() { return "templates/UserSettings/recovery"; }

    @RequestMapping(path="/registration")
    public String getRegistrationForm() { return "templates/UserAuthentication/registration"; }
    @RequestMapping(path="/login")
    public String getLoginForm() { return "templates/UserAuthentication/login"; }

    @RequestMapping(path = "/rating/{id}")
    public String getUserRatingForm(@PathVariable String id) { return "templates/UserRating/userRatingForm"; }

    @RequestMapping(path = "/carrating/{id}")
    public String getCarRatingForm(@PathVariable String id) { return "templates/CarRating/carRatingForm"; }

    @RequestMapping(path = "/chat/page")
    public String getFormPage() { return "templates/Chat/formPage"; }
    @RequestMapping(path = "/chat/m", method = GET)
    public String messages(Model model,@RequestParam String sender,@RequestParam String receiver) {
        model.addAttribute("sender", sender);
        model.addAttribute("receiver", receiver);
        return "templates/Chat/chatIndex";}

    @RequestMapping(path = "/start")
    public String start(){
        return "templates/CarBook/start.html";
    }
    @RequestMapping(path = "/book/{id}")
    public String reservation(@PathVariable Long id){
        return "templates/CarBook/reservationForm.html";
    }
    @RequestMapping(path = "/extend")
    public String extendReservation(){
        return "templates/CarBook/extend.html";
    }
    @RequestMapping(path = "/show")
    public String show(){
        return "templates/CarBook/show.html";
    }
    @RequestMapping(path = "/showOffer")
    public String showOffer(){
        return "templates/CarBook/showOffer2.html";
    }
    @RequestMapping(path = "/bookings")
    public String bookings(){
        return "templates/CarBook/bookings.html";
    }
    @RequestMapping(path = "/map")
    public String map(){
        return "templates/Area/map";
    }

@RequestMapping(value = "/search",method = RequestMethod.GET)
public String search(@RequestParam("query") String query, @RequestParam("radius") String radius,Model model) throws JSONException {
    String location;
    try {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI("http://localhost:9008/area/search?query=" + query+"&radius="+radius))
                .GET()
                .build();
        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("RESPONSE FROM AREA SERVICE:"+response.body());
        location = response.body();
        JsonArray jsonArray ;
        JsonObject jsonObject ;
        Gson gson = new Gson();
        Type listType = new TypeToken<List<?>>() {}.getType();
        jsonObject = JsonParser.parseString(response.body()).getAsJsonObject();
        jsonArray=jsonObject.get("response").getAsJsonArray();
        List<?> ll = gson.fromJson(jsonArray, listType);
        //Location l=new Location(1,"41.9027835","12.4963655","car1");
        //Location l2=new Location(2,"41.9027835","12.4963755","car2");
        //List<Location> ll=new ArrayList<>();
        //ll.add(l);
        //ll.add(l2);
        model.addAttribute("loc", location);
        model.addAttribute("radius", radius);
        model.addAttribute("locations", ll);
        System.out.println(jsonArray);

    } catch (URISyntaxException | InterruptedException | IOException| JsonSyntaxException e) {
        System.out.println(e.getMessage());
        throw new RuntimeException(e);
    }

    return "templates/Area/map.html";
}
    @RequestMapping(path = "/insurance")
    public String insurance(){
        return "templates/Insurance/insuranceForm";
    }
}

