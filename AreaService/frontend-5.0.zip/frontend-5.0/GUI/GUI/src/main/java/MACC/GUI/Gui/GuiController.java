package MACC.GUI.Gui;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.URI;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@Slf4j
@Controller
public class GuiController {
    @RequestMapping(path="/")
    public String getHome(){ return "templates/index"; }

    @RequestMapping(path="/api/email")
    public String getConfirmationPage(){ return "templates/Email/confirmationEmail"; }
    @RequestMapping(path="/pages")
    public String getSuccessPage(@Param("type") String type){ return "templates/"+ type; }

    @RequestMapping(path="/searchbar")
    public String getOfferForm() { return "templates/CarSearch/form"; }
    @RequestMapping(path="/listcars")
    public String getOfferForm2() { return "templates/CarSearch/cars"; }
    @RequestMapping(path = "/carsearch/{id}")
    public String getCarDetails(@PathVariable String id) { return "templates/CarSearch/carRetrieved"; }

    @RequestMapping(path="/carinsert/insertoffer")
    public String getOfferForm3() { return "templates/CarInsertion/offerForm"; }
    @RequestMapping(path="/carinsert/insertcar")
    public String getOfferForm4() { return "templates/CarInsertion/carForm"; }
    @RequestMapping(path="/carinsert/insertutilities")
    public String getOfferForm5() { return "templates/CarInsertion/utilitiesForm"; }

    @RequestMapping(path="/success")
    public String getOfferForm6() { return "templates/CarInsertion/success"; }
    @RequestMapping(path="/failed")
    public String getOfferForm7() { return "templates/CarInsertion/failed"; }

    @RequestMapping(path="/userSettings")
    public String getUserSettingsPage(){ return "templates/UserSettings/userSettings"; }
    @RequestMapping(path="/recovery")
    public String getRecoveryPage() { return "templates/UserSettings/recovery"; }

    @RequestMapping(path="/registration")
    public String getRegistrationForm() { return "templates/UserAuthentication/registration"; }
    @RequestMapping(path="/login")
    public String getLoginForm() { return "templates/UserAuthentication/login"; }

    @RequestMapping(path = "/rating/{id}")
    public String getUserRatingForm(@PathVariable String id) { return "templates/UserRating/userRatingForm"; }

    @RequestMapping(path = "/carrating/{id}")
    public String getCarRatingForm(@PathVariable String id) { return "templates/CarRating/carRatingForm"; }

    @RequestMapping(path = "/chat/page")
    public String getFormPage() { return "templates/Chat/formPage"; }
    @RequestMapping(path = "/chat/m", method = GET)
    public String messages(Model model,@RequestParam String sender,@RequestParam String receiver) {
        model.addAttribute("sender", sender);
        model.addAttribute("receiver", receiver);
        return "templates/Chat/chatIndex";}

    @RequestMapping(path = "/start")
    public String start(){
        return "templates/CarBook/start.html";
    }
    @RequestMapping(path = "/book/{id}")
    public String reservation(@PathVariable Long id){
        return "templates/CarBook/reservationForm.html";
    }
    @RequestMapping(path = "/extend")
    public String extendReservation(){
        return "templates/CarBook/extend.html";
    }
    @RequestMapping(path = "/show")
    public String show(){
        return "templates/CarBook/show.html";
    }
    @RequestMapping(path = "/showOffer")
    public String showOffer(){
        return "templates/CarBook/showOffer2.html";
    }
    @RequestMapping(path = "/bookings")
    public String bookings(){
        return "templates/CarBook/bookings.html";
    }
    @RequestMapping(path = "/map")
    public String map(){
        return "templates/Area/map.html";
    }

@RequestMapping(value = "/search",method = RequestMethod.POST)
public String search(@RequestParam("query") String query, Model model) {
    String location;
    try {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI("http://localhost:9008/area/search?query=" + query))
                .GET()
                .build();
        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        location = response.body();
        System.out.println(location);
        model.addAttribute("loc", location);
    } catch (URISyntaxException | InterruptedException | IOException e) {
        throw new RuntimeException(e);
    }

    return "templates/Area/map.html";
}
}

