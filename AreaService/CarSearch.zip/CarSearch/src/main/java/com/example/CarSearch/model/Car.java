package com.example.CarSearch.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "car")
public class Car {
    public enum Engine {
        Electric,
        Gas,
        Diesel,
        Hybrid
    }

    public enum Size {
        Big,
        Medium,
        Small
    }

    public enum Transmission {
        Manual,
        Automatic
    }

    public enum Fuel {
        Gas,
        Methane,
        Diesel,
        GPL,
        Electric
    }

    public enum PollutionLevel {
        EURO2,
        EURO3,
        EURO4,
        EURO5,
        EURO6,
    }

    @Id
    @SequenceGenerator(name = "car_gen", sequenceName = "car_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "car_gen")
    private Long cid;
    private String plateNum;
    private Long year;
    private PollutionLevel pollutionLevel;
    private Fuel fuel;
    private String brand;
    private Long passengers;
    private String model;
    private String position;
    private String insurance;
    private Size size;
    private Long carDoorNumber;
    private Engine engine;
    private Transmission transmission;
    @OneToOne
    @JoinColumn(name = "offer_oid")
    private Offer offer_oid;
    @OneToOne
    @JoinColumn(name = "utilities_utid")
    private Utilities utilities_utid;

    public Car() {
    }

    public Car(Long cid) {
        this.cid = cid;
    }

    public Car(String plateNum, Long year, PollutionLevel pollutionLevel, Fuel fuel, String brand, Long passengers, String model,
               String position, String insurance, Size size, Long carDoorNumber, Engine engine, Transmission transmission) {
        this.plateNum = plateNum;
        this.year = year;
        this.pollutionLevel = pollutionLevel;
        this.fuel = fuel;
        this.brand = brand;
        this.passengers = passengers;
        this.model = model;
        this.position = position;
        this.insurance = insurance;
        this.size = size;
        this.carDoorNumber = carDoorNumber;
        this.engine = engine;
        this.transmission = transmission;
    }
}
