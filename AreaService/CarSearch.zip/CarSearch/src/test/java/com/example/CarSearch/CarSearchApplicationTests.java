package com.example.CarSearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
