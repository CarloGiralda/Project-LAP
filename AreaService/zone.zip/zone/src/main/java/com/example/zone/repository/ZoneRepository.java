package com.example.zone.repository;

import com.example.zone.model.Zone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ZoneRepository extends JpaRepository<Zone, Long> {
    @Query("SELECT z FROM Zone z WHERE z.center = ?1 and z.radius = ?2")
    List<Zone> findAllByCenterAndRadius(Double center, Double radius);
}
