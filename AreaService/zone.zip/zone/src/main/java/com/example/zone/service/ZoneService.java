package com.example.zone.service;

import com.example.zone.dto.SubscriptionDTO;
import com.example.zone.model.Subscription;
import com.example.zone.model.Zone;
import com.example.zone.repository.SubscriptionRepository;
import com.example.zone.repository.ZoneRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class ZoneService {
    private ZoneRepository zoneRepository;
    private SubscriptionRepository subscriptionRepository;

    public void subscribeUserToZone(SubscriptionDTO subscriptionDTO) {
        List<Zone> result = zoneRepository.findAllByCenterAndRadius(subscriptionDTO.getCenter(), subscriptionDTO.getRadius());
        Zone zone = new Zone(subscriptionDTO.getCenter(), subscriptionDTO.getRadius());
        Subscription subscription;
        if (result.isEmpty()) {
            Zone saved = zoneRepository.save(zone);
            subscription = new Subscription(saved.getId(), subscriptionDTO.getUsername());
        } else {
            subscription = new Subscription(result.get(0).getId(), subscriptionDTO.getUsername());
        }
        if (result.size() > 1) {
            throw new RuntimeException("There is a more than one zone.");
        }
        subscriptionRepository.save(subscription);
    }

    public List<String> getSubscribedUser(){

        // TODO logic to retrieve subscribed user
        return null;
    }

}
