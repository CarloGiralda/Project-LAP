package com.example.zone.controller;

import com.example.zone.dto.SubscriptionDTO;
import com.example.zone.service.ZoneService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@Slf4j
@AllArgsConstructor
@RequestMapping(path = "/area")
public class ZoneController {
    private ZoneService zoneService;

    @GetMapping(path = "/subscribe")
    public ResponseEntity<?> subscribe(@RequestParam("center") String center, @RequestParam("radius") String radius, @RequestHeader("Logged-In-User") String username) {
        try {
            SubscriptionDTO subscriptionDTO = new SubscriptionDTO(username, Double.parseDouble(center), Double.parseDouble(radius));
            zoneService.subscribeUserToZone(subscriptionDTO);
            return ResponseEntity.ok().body("Success");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body("internal server error");
        }

    }

    // TODO
    @GetMapping(path = "/getSubscribedUser/{center}{radius}")
    public ResponseEntity<?> getSubscribedUser(@RequestParam("center") Double zone, @RequestParam("radius") Double radius) {
        try {
            List<String> subUsers = zoneService.getSubscribedUser();
            return ResponseEntity.ok().body(subUsers);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body("internal server error");
        }

    }


}
