package com.example.zone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZoneSubscriptionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
