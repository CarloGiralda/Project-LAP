package MACC.areaservice.service;

import MACC.areaservice.model.Area;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AreaRepository extends JpaRepository<Area, Integer> {

}
