package MACC.areaservice.service;

import MACC.areaservice.model.Area;
import MACC.areaservice.model.Subscriptions;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Slf4j
@Service
@AllArgsConstructor
public class SubsService {

    private final SubsRepository subsRepository;

    public Subscriptions getSubs(String username){
        return subsRepository.findByUsername(username);
    }

    public Subscriptions setSubs(Subscriptions subs){
        return subsRepository.save(subs);
    }
}
