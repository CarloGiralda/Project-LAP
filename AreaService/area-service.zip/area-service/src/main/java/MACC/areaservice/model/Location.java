package MACC.areaservice.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@NoArgsConstructor
@Getter
@Setter
public class Location implements Serializable {
    private Integer id;
    private String lat;
    private String lng;
    private String name;
    private String cid;
}

