package MACC.areaservice.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "subscriptions", uniqueConstraints = @UniqueConstraint(columnNames = {"areaId","username"}))
public class Subscriptions {


    @Id
    @Column(name = "subsId")
    @SequenceGenerator(name = "subscriptions_gen", sequenceName = "subscriptions_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "subscriptions_gen")
    private Long sid;

    @ManyToOne
    @JoinColumn(name = "areaId")
    private Area areas;



    @Column(name = "username")
    private String username;

}

