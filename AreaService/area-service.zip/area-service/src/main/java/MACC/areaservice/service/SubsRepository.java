package MACC.areaservice.service;

import MACC.areaservice.model.Area;
import MACC.areaservice.model.Subscriptions;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubsRepository extends JpaRepository<Subscriptions, Integer> {
    Subscriptions findByUsername(String username);
}
