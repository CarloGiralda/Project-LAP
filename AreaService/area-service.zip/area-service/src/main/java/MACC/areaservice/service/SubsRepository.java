package MACC.areaservice.service;

import MACC.areaservice.request.Subscriptions;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubsRepository extends JpaRepository<Subscriptions, Integer> {
    Subscriptions findByUsername(String username);
}
