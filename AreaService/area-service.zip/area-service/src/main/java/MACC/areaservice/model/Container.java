package MACC.areaservice.model;

import com.google.gson.JsonArray;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashMap;

@Setter
@Getter
@AllArgsConstructor
public class Container {

    private HashMap<String[], ArrayList<Location> > activeSessions;

    public void updateActiveSession(String[] id, ArrayList<Location> subsArray){

        activeSessions.put(id,subsArray);
    }

    public ArrayList<Location>  getActiveSession(String[] id){return activeSessions.get(id);}


}
