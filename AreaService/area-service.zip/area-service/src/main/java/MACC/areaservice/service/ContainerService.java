package MACC.areaservice.service;

import MACC.areaservice.model.Container;
import MACC.areaservice.model.Location;
import com.google.gson.JsonArray;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;


@Service
public class  ContainerService{
    private final Container activeSessions;

    public ContainerService(){
        activeSessions=new Container(new HashMap<>());
    }
    public void updateSession( String id, ArrayList<Location> subsArray){
        // update older sessionID
        activeSessions.updateActiveSession(id,subsArray);}
    public ArrayList<Location> getSession( String username){
        // get current user sessionID
        return activeSessions.getActiveSession(username);
    }
}
