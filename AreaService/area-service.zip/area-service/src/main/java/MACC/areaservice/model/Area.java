package MACC.areaservice.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@RequiredArgsConstructor
@Table(name = "areas", uniqueConstraints = @UniqueConstraint(columnNames = {"areaCenter","areaRadius"}))
@Entity
public class Area {

@Id
@Column(name = "areaId")
@SequenceGenerator(name = "areas_gen", sequenceName = "areas_seq", allocationSize = 1)
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "areas_gen")
private Long aid;

@Column(name = "areaCenter")
private String areaCenter;

@Column(name = "areaRadius")
private String areaRadius;

@OneToMany(mappedBy="areas")
private List<Subscriptions> subscriptions;
}

