package MACC.areaservice.controller;

import MACC.areaservice.model.Area;
import MACC.areaservice.model.Location;
import MACC.areaservice.model.Subscriptions;
import MACC.areaservice.service.AreaService;
import MACC.areaservice.service.ContainerService;
import MACC.areaservice.service.SubsService;
import com.google.gson.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import MACC.areaservice.service.AreaServiceMap;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Arrays;


@RestController
@Slf4j
@AllArgsConstructor
@RequestMapping(path = "/area")
public class AreaController {


    private final AreaServiceMap geocodingService;
    private final AreaService areaService;
    private final SubsService subsService;
    private final ContainerService containerService;

    @RequestMapping(path = "/search",method = RequestMethod.GET,consumes = MediaType.ALL_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<?> searchMap(@RequestParam("query") String query,@RequestParam("radius") String radius){
        JsonObject location;
        try {
            //Request to car search
            location= geocodingService.search(query);
            String center=location.get("lat").getAsString()+"/"+location.get("lon").getAsString();
            // check if search already contained in container
            String[] check=new String[2];
            check[0]=center;
            check[1]=radius;
            Gson gson = new GsonBuilder().create();
            JsonArray jsonArray = gson.toJsonTree(containerService.getSession(check)).getAsJsonArray();
            if(jsonArray.isEmpty()) {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI("carsearchURL/?center=" + center + "&radius=" + radius))
                        .GET()
                        .build();
                HttpClient client = HttpClient.newHttpClient();
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                jsonArray=JsonParser.parseString(response.body()).getAsJsonArray();
                System.out.println("RESPONSE FROM CAR SEARCH SERVICE:"+jsonArray);
                location.add("response", jsonArray.getAsJsonArray());
                ArrayList<Location> ll=new ArrayList<>();
                for(int i=0; i< jsonArray.size(); i++) {
                    JsonObject element=jsonArray.get(i).getAsJsonObject();
                    Location l= new Location();
                    l.setId(i);
                    l.setLat(element.get("lat").getAsString());
                    l.setLng(element.get("lng").getAsString());
                    l.setName(element.get("name").getAsString());
                    l.setCid(element.get("cid").getAsString());
                    ll.add(l);
                }
                System.out.println("SETTING CONTAINER ELEMENT TO:"+ll);
                containerService.updateSession(check,ll);
            }else{
                System.out.println("RESPONSE FROM CAR Container SERVICE:"+jsonArray);
                location.add("response", jsonArray.getAsJsonObject());
            }
            return new ResponseEntity<>(location,HttpStatus.OK);
        } catch (JSONException | URISyntaxException | IOException | JsonSyntaxException |InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @RequestMapping(path = "/subscribe",method = RequestMethod.GET,consumes = MediaType.ALL_VALUE,
            produces = MediaType.ALL_VALUE)
    @ResponseBody
    public ResponseEntity<?> subscribe(@RequestParam("areaCenter") String areaCenter,@RequestParam("areaRadius") String areaRadius,@RequestParam("username") String username, @RequestHeader("Logged-In-User") String user){
        HttpResponse<String> response =null;
        String[] check=new String[2];
        check[0]=areaCenter;
        check[1]=areaRadius;
        Gson gson = new GsonBuilder().create();
        JsonArray body = gson.toJsonTree(containerService.getSession(check)).getAsJsonArray();
        Gson gson2 = new Gson();
        String[] output = gson2.fromJson(body , String[].class);
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI("notificationurl"))
                    .POST(HttpRequest.BodyPublishers.ofString(Arrays.toString(output)))
                    .header("Authorization", username).headers("Content-Type", "application/json")
                    .build();
            HttpClient client = HttpClient.newHttpClient();
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (URISyntaxException | InterruptedException | IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
        System.out.println("RESPONSE FROM NOTIFICATION SERVICE:"+response);
        // create zone if it is not already present
        Area area=new Area();
        area.setAreaCenter(areaCenter);
        area.setAreaRadius(areaRadius);
        Area ret=areaService.setArea(area);
        //create subs
        Subscriptions subs=new Subscriptions();
        subs.setAreas(ret);
        subs.setUsername(username);
        subsService.setSubs(subs);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}