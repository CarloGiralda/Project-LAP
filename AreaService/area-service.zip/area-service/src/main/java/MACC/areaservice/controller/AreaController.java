package MACC.areaservice.controller;


import MACC.areaservice.model.Area;
import MACC.areaservice.model.Subscriptions;
import MACC.areaservice.service.AreaService;
import MACC.areaservice.service.SubsService;
import com.google.gson.JsonObject;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import MACC.areaservice.service.AreaServiceMap;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;

@RestController
@Slf4j
@AllArgsConstructor
@RequestMapping(path = "area")
public class AreaController {


    private final AreaServiceMap geocodingService;
    private final AreaService areaService;
    private final SubsService subsService;

    @RequestMapping(path = "/search",method = RequestMethod.GET,consumes = MediaType.ALL_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<?> searchMap(@RequestParam("query") String query){
        JsonObject location;
        try {
            location= geocodingService.search(query);
            return new ResponseEntity<>(location,HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @RequestMapping(path = "/subscribe",method = RequestMethod.GET,consumes = MediaType.ALL_VALUE,
            produces = MediaType.ALL_VALUE)
    @ResponseBody
    public ResponseEntity<?> subscribe(@RequestParam("areaCenter") String areaCenter,@RequestParam("areaRadius") String areaRadius,@RequestParam("username") String username){
        String body;
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI("carsearchURL"))
                    .GET().header("key1", "value1")
                    .header("key2", "value2")
                    .build();
            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            body=response.body();
        } catch (URISyntaxException | InterruptedException | IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI("notificationurl"))
                    .POST(HttpRequest.BodyPublishers.ofString(body)).header("key1", "value1")
                    .header("key2", "value2").headers("Content-Type", "application/json")
                    .build();
            HttpClient client = HttpClient.newHttpClient();
            client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (URISyntaxException | InterruptedException | IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
        // create zone if it is not already present
        Area area=new Area();
        area.setAreaCenter(areaCenter);
        area.setAreaRadius(areaRadius);
        Area ret=areaService.setArea(area);
        //create subs
        Subscriptions subs=new Subscriptions();
        subs.setAreas(ret);
        subs.setUsername(username);
        subsService.setSubs(subs);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}