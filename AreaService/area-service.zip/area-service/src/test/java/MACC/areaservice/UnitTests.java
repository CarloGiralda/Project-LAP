package MACC.areaservice;




import MACC.areaservice.controller.AreaController;
import MACC.areaservice.service.AreaService;
import MACC.areaservice.service.AreaServiceMap;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.google.gson.JsonObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.ArrayList;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AreaController.class)
@ContextConfiguration("/test-context.xml")
class UnitTests {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private  ObjectMapper objectMapper;
    @MockBean
    private AreaService areaService;
    @MockBean
    private AreaServiceMap geocodingService;


    @BeforeEach
    void setUp(WebApplicationContext wac) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    void subscribe() throws Exception {

        String areaCenter="[12.0/12.0]";
        String areaRadius="500";
        String username="Gian";
        MvcResult result = mockMvc.perform(get("http://localhost:9008/area/subscribe").queryParam("areaCenter",areaCenter).queryParam("areaRadius",areaRadius).queryParam("username",username)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();
    }

    @Test
    void searchMap() throws Exception {
        String query="Rome";
        String radius="500";
        JsonObject json=new JsonObject();
        json.addProperty("lat","12.0");
        json.addProperty("lon","12.0");
        when(geocodingService.search(query)).thenReturn(json);
        MvcResult result = mockMvc.perform(get("http://localhost:9008/area/search").queryParam("query",query).queryParam("radius",radius)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();


    }

    @Test
    void searchLocation() throws Exception {
        String query="Rome";
        JsonObject json=new JsonObject();
        json.addProperty("lat","12.0");
        json.addProperty("lon","12.0");
        when(geocodingService.search(query)).thenReturn(json);
        MvcResult result = mockMvc.perform(get("http://localhost:9008/area/searchLocation").queryParam("query",query)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();
    }





}
