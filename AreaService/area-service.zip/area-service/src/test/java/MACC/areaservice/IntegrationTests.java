package MACC.areaservice;






import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;

import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest(classes = MACC.areaservice.AreaServiceApplication.class)
@AutoConfigureMockMvc
class IntegrationTests {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper objectMapper;



    @Test
    void subscribe() throws Exception {

        String areaCenter="[12.0/12.0]";
        String areaRadius="500";
        String username="Gian";

        // when(offerService.setOffer(any(Offer.class)));
        MvcResult result = mvc.perform(get("http://localhost:9008/area/subscribe").queryParam("areaCenter",areaCenter).queryParam("areaRadius",areaRadius).queryParam("username",username)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();

    }


    @Test
    void searchMap() throws Exception {
        String query="Rome";
        String radius="500";

        MvcResult result = mvc.perform(get("http://localhost:9008/area/search").queryParam("query",query).queryParam("radius",radius)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();

    }

    @Test
    void searchLocation() throws Exception {
        String query="Rome";
        MvcResult result = mvc.perform(get("http://localhost:9008/area/searchLocation").queryParam("query",query)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();
    }

}





