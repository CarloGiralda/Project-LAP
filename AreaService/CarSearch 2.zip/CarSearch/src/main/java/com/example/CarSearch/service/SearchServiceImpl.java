package com.example.CarSearch.service;

import com.example.CarSearch.model.*;
import com.example.CarSearch.repository.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SearchServiceImpl implements SearchService {
    private final SearchRepo searchRepo;
    private final CarRepo carRepo;

    public SearchServiceImpl(SearchRepo searchRepo, CarRepo carRepo) {
        this.searchRepo = searchRepo;
        this.carRepo = carRepo;
    }
    
    @Override
    public List<SearchDTO> getCar(SearchDTO dto) {
        return searchRepo.getCarOfferUtFromSearchDTO(dto);
    }

    @Override
    public List<SearchDTO> getSearchDTOById(Long id) {
        return searchRepo.getCarOfferUtFromId(id);
    }

    @Override
    public String getCarById(Long id) {
        return carRepo.findCarById(id);
    }

    @Override
    public JsonArray getCarsInsideRange(String position, Long range) {
        List<SearchDTO> cars = searchRepo.getCars();
        JsonArray carsInsideRange = new JsonArray();
        String[] lat_lon = position.split("/");
        // latitude is lat_lon[0]
        // longitude is lat_lon[1]
        for (int i = 0; i < cars.size(); i++) {
            String zone = cars.get(i).getOffer().getZoneLocation();
            String[] car_lat_lon = zone.split("/");
            // distance(x,y) = ( (x1-y1)^2 + (x2-y2)^2 )^0.5
            double distance = Math.pow((Math.pow(Double.parseDouble(lat_lon[0]) - Double.parseDouble(car_lat_lon[0]), 2) + Math.pow(Double.parseDouble(lat_lon[1]) - Double.parseDouble(car_lat_lon[1]), 2)), 0.5);
            if (distance < range) {
                JsonObject object=new JsonObject();
                String[] pos=cars.get(i).getOffer().getZoneLocation().split("/");
                object.addProperty("lat",pos[0]);
                object.addProperty("lon",pos[1]);
                object.addProperty("name",cars.get(i).getCar().getBrand()+cars.get(i).getCar().getModel());
                object.addProperty("id",i);
                object.addProperty("cid",cars.get(i).getCar().getCid());
                carsInsideRange.add(object);
            }
        }
        return carsInsideRange;
    }
}
