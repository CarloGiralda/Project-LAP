package MACC_Project.Send_Email_MS;

import MACC_Project.Send_Email_MS.SendConfirmation.Email.SendEmailController;
import MACC_Project.Send_Email_MS.SendConfirmation.Email.SendEmailService;
import MACC_Project.Send_Email_MS.SendConfirmation.FileUpload.UploadService;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.UserRepository;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.io.File;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.SharedHttpSessionConfigurer.sharedHttpSession;
@RunWith(SpringRunner.class)
@WebMvcTest(SendEmailController.class)
@AllArgsConstructor
@ExtendWith(SpringExtension.class)
@SpringBootTest
class SendEmailMsApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;
	@Autowired
	private final SendEmailService emailSender;
	@Autowired
	private final UserService user;
	@Autowired
	private final UploadService upload;
	//TEST
	@Autowired
	private final UserRepository users;
	@Autowired
	private final SendEmailController s;
	//TEST_END);

	//private String token;

	@BeforeEach
	void setUp(WebApplicationContext wac) {
		// 方式1：明确指定需要测试的"Controller"类
		this.mockMvc = MockMvcBuilders.standaloneSetup(new SendEmailController(emailSender,user,upload,users)).build();

		// 方式2：基于Spring容器进行配置，包含了Spring MVC环境和所有"Controller"类。
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();

		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac)
				.defaultRequest(get("/").accept(MediaType.APPLICATION_JSON)) // 默认请求路径
				.apply(sharedHttpSession()) // 配置session
				.alwaysExpect(status().isOk()) // 预期响应状态码
				.alwaysExpect(content().contentType("application/json;charset=UTF-8")) // 预期内容类型
				.build();
	}
	@Test
	void passwordForgotten() throws Exception {

		//SendRequest request=new SendRequest("Gianmarco","Bordin","bordingianmarco@virgilio.it","ciao","*","*","*","*");
		MvcResult result = this.mockMvc.perform(get("/test/simple/get")
						.accept(MediaType.APPLICATION_JSON)) // 接受JSON格式响应消息
				.andReturn(); // 获取返回结果
		Assertions.assertEquals("OK", result.getResponse().getContentAsString());
	}

	@Test
	void confimationTokenService() throws Exception {
		int id = 10;
		// 方式1：在URI模板中指定参数
		//MvcResult result = this.mockMvc.perform(get("/test/param/get?id={id}", id).accept(MediaType.APPLICATION_JSON)).andReturn();

		// 方式2：通过param()方法指定参数
		//MvcResult result = this.mockMvc.perform(get("/test/param/get").param("id", String.valueOf(id)).accept(MediaType.APPLICATION_JSON)).andReturn();

		// 方式3：通过queryParam()方法指定参数
		MvcResult result = this.mockMvc.perform(get("/test/param/get").queryParam("id", String.valueOf(id)).accept(MediaType.APPLICATION_JSON)).andReturn();
		Assertions.assertEquals("OK: " + id, result.getResponse().getContentAsString());
	}
	@Test
	void emailConfirmation() {
	//TODO
	}


	@Test
	void modifyUserSettings() throws Exception {
			MvcResult result = this.mockMvc.perform(MockMvcRequestBuilders
					.post("/employees")
					.content(this.objectMapper.writeValueAsString(this.s))
					.contentType(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_JSON)
					.accept(String.valueOf(status().isCreated()))).andReturn();
			Assertions.assertEquals("{\"id\":10}", result.getResponse().getContentAsString());
			}


	@Test
	void fileUpload() throws Exception {
			File file = new File("C:\\Users\\xxx\\Downloads\\test.jpg");
			String fileName = FilenameUtils.getName(file.getName());
			byte[] bytes = FileUtils.readFileToByteArray(file);
			MockMultipartFile mockMultipartFile = new MockMultipartFile("file", fileName, MediaType.MULTIPART_FORM_DATA_VALUE, bytes);
			this.mockMvc.perform(multipart("/test/upload/single").file(mockMultipartFile))
			.andExpect(status().isOk())
			.andExpect(content().string("OK"))
			.andDo(print());
	}
}
