package MACC_Project.Send_Email_MS;

import MACC_Project.Send_Email_MS.SendConfirmation.Email.SendEmailService;
import MACC_Project.Send_Email_MS.SendConfirmation.Email.SendRequest;
import MACC_Project.Send_Email_MS.SendConfirmation.FileUpload.UploadService;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.User;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.UserRepository;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.UserService;
import MACC_Project.Send_Email_MS.SendConfirmation.SendEmailMsApplication;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;


@RunWith(SpringRunner.class)
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.MOCK,
        classes = SendEmailMsApplication.class)
@AutoConfigureMockMvc
@TestPropertySource(
        locations = "classpath:application-integrationtest.properties")
class IntegrationTests {

    @Autowired
    private MockMvc mvc;
    @Autowired
    private  SendEmailService emailSender;
    @Autowired
    private  UserService user;
    @Autowired
    private  UploadService upload;
    @Autowired
    private  UserRepository users;


    @Test
    public void addOneEmployee() {
            User user=new User();
            assertEquals(1, users.save(user));
    }

    @Test
    void sendRecoveryEmail() throws Exception {
        String email="bordingianmarco@virgilio.it";
        String result="";
        assertEquals("Done, Recovery email has been sent to your registered email address", result);
        String pass=UUID.randomUUID().toString();
        assertEquals(user.updatePass(email, pass),1);
        assertNotEquals(emailSender.send(email, pass, "Recovery"),"Done, Recovery email has been sent to your registered email address");
    }


    @Test
    void modifyUserSettings() throws Exception {
        String result="";
        SendRequest request=new SendRequest("Gianmarco","Bordin","bordingianmarco@virgilio.it","ciao","","","","");
        Integer i = 0;
        List<String> mods = new ArrayList<>();
        mods.add("firstName");
        mods.add("lastName");
        mods.add("residence");
        mods.add("contact");
        mods.add("password");
        for(i=1;i<6;i++) {
            request.mod= mods.get(i - 1);
            switch (request.getMod()) {
                case "firstName":
                    if (user.updateFirstName(request.getEmail(), request.getFirstName()) != 1)
                        result = "500 INTERNAL SERVER ERROR";
                case "lastName":
                    if (user.updateLastName(request.getEmail(), request.getLastName()) != 1)
                        result = "500 INTERNAL SERVER ERROR";
                case "residence":
                    if (user.updateResidence(request.getEmail(), request.getResidence()) != 1)
                        result = "500 INTERNAL SERVER ERROR";
                case "contact":
                    if (user.updateContact(request.getEmail(), request.getContact()) != 1)
                        result = "500 INTERNAL SERVER ERROR";
                case "password":
                    if (user.updatePass(request.getEmail(), request.getPassword()) != 1) {
                        result = "500 INTERNAL SERVER ERROR";
                    }
                if(!Objects.equals(result,"500 INTERNAL SERVER ERROR"))
                    result = "Done, User Settings Modified";
                assertEquals("Done, User Settings Modified", result);
            }
        }
    }


    @Test
    void sendConfirmationEmail() throws Exception {
        SendRequest request=new SendRequest("Gianmarco","Bordin","bordingianmarco@virgilio.it","ciao","","","","");
        String token = UUID.randomUUID().toString();
        emailSender.send(request.getEmail(), request.getFirstName(), token);
        assertEquals("Done", emailSender.send(request.getEmail(), request.getFirstName(), token));
    }


    @Test
    void handleFileUpload() throws Exception {
        Path path = Path.of("Downloads");
        File file =  new File("/Users/applem2/Downloads/Send_Email_MS/dummy.pdf");
        byte[] bytes = FileUtils.readFileToByteArray(file);
        String fileName = FilenameUtils.getName(file.getName());
        MockMultipartFile mockMultipartFile = new MockMultipartFile("file", fileName, MediaType.MULTIPART_FORM_DATA_VALUE, bytes);
        assertEquals("uploadSuccessful", upload.handleFileUpload(mockMultipartFile, path));

    }

}
