package MACC_Project.Send_Email_MS.SendConfirmation.Pass;

import lombok.AllArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;



@Service
@AllArgsConstructor
public class UserService implements UserDetailsService {

    private final static String USER_NOT_FOUND_MSG =
            "user with email %s not found";

    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String email)
            throws UsernameNotFoundException {
        return userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new UsernameNotFoundException(
                                String.format(USER_NOT_FOUND_MSG, email)));
    }


    public User all () {
        return userRepository.show();

    }
    public int updatePass(String email, String  pass) {
        if(userRepository.updatePass(pass, email)>0)
            return 1;
        else
            return 0;
    }

    public int updateFirstName(String email, String  firstName) {
        if(userRepository.updateFirstName(firstName, email)>0)
            return 1;
        else
            return 0;
    }

    public int updateLastName(String email, String  lastName) {
        if(userRepository.updateLastName(lastName, email)>0)
            return 1;
        else
            return 0;
    }

    public int updateResidence(String email, String  residence) {
        if(userRepository.updateResidence(residence, email)>0)
            return 1;
        else
            return 0;
    }

    public int updateContact(String email, String contact) {
        if(userRepository.updateContact(contact, email)>0)
            return 1;
        else
            return 0;
    }
}