package MACC_Project.Send_Email_MS.SendConfirmation.Email;

import MACC_Project.Send_Email_MS.SendConfirmation.FileUpload.UploadService;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.User;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.UserRepository;
import MACC_Project.Send_Email_MS.SendConfirmation.Pass.UserService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.springframework.web.bind.annotation.*;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Path;
import java.util.UUID;

@RestController
@AllArgsConstructor
public class SendEmailController {

    private final SendEmailService emailSender;
    private final UserService user;
    private final UploadService upload;
    //TEST
    private final UserRepository users;
//TEST_END
    final Logger LOGGER = LoggerFactory
            .getLogger(SendEmailController.class);

    //private String token;


    @PostMapping(path = "api/email")
    public String sendConfirmationEmail(@RequestBody SendRequest request) {
        LOGGER.info("Sending Confirmation Email...");
        String token = UUID.randomUUID().toString();
        return emailSender.send(request.getEmail(), request.getFirstName(), token);
    }

    @GetMapping(path = "api/confirmation")
    public String confirmEmailToken(@RequestParam("token") String sentToken)  {
        LOGGER.info("Confirming Token...");
        //  TODO Should render a page that states Mail confirmed
        String token="DUMMY";
        return emailSender.confirmToken(token,sentToken);
    }

    @GetMapping(path = "api/recovery")
    public String sendRecoveryEmail(@RequestParam("email") String email,@RequestParam("name") String firstName) {
        String pass=UUID.randomUUID().toString();
        LOGGER.info("Sending Recovery Email...");
        if(user.updatePass(email, pass)!=1){
            LOGGER.error("Recovery Procedure Failed due to internal error");
            return "500 INTERNAL SERVER ERROR";
        }
        emailSender.send(email, firstName, "Recovery");
        return "Done, Recovery email has been sent to your registered email address";
    }
//TEST TODO CHANGE TO RET COLLECTION OF USERS
    @GetMapping(path = "api/userSettings")
    public String userSettings() {
        LOGGER.info("Showing all names of registered users...");
        User us= user.all();
        return "Done all users are: "+us.getFirstName();
    }

    @PostMapping("api/userSettings")
    public User addOneEmployee(@RequestBody User user) {
        return users.save(user);
    }

//TEST_END
    @PostMapping(path = "api/userSettings/modify")
    public String modifyUserSettings(@RequestBody SendRequest request) {
        LOGGER.info("Sending Confirmation Email...");
        switch (request.getMod()) {
            case "firstName":
                if(user.updateFirstName(request.getEmail(), request.getFirstName())!=1)
                    return "500 INTERNAL SERVER ERROR";
            case "lastName":
                if(user.updateLastName(request.getEmail(), request.getLastName())!=1)
                    return "500 INTERNAL SERVER ERROR";
            case "residence":
                if(user.updateResidence(request.getEmail(), request.getResidence())!=1)
                    return "500 INTERNAL SERVER ERROR";
            case "contact":
                if(user.updateContact(request.getEmail(), request.getContact())!=1)
                    return "500 INTERNAL SERVER ERROR";
            default:
                if(user.updatePass(request.getEmail(), request.getPassword())!=1) {
                    return "500 INTERNAL SERVER ERROR";
                }
        }
        return "Done, User Settings Modified";
    }

    @PostMapping("api/upload")
    public String handleFileUpload(@RequestParam MultipartFile file) throws IOException {
        Path path = Path.of("Downloads");
        if(!"uploadSuccessful".equals(upload.handleFileUpload(file, path))) return "500 INTERNAL SERVER ERROR";
        else
            return "Done, File Uploaded!";
    }
}

