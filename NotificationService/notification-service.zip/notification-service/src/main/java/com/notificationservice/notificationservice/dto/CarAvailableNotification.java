package com.notificationservice.notificationservice.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CarAvailableNotification {

    private String carId;
    private String carName;
}
