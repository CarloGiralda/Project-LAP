package com.notificationservice.notificationservice.Controller;

import com.notificationservice.notificationservice.dto.CarAvailableNotification;
import com.notificationservice.notificationservice.dto.CarMessage;
import com.notificationservice.notificationservice.service.WebSocketService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
// Check if needed
@RestController
@RequestMapping(path = "/notification")
public class CarAvailableNotificationController {

    private WebSocketService webSocketService;

    @PostMapping("/send-car-notification")
    public void sendCarNotification(@RequestBody CarMessage carMessage){

        // TODO car message is retrieved from message queue of car service
        // TODO list of user subscribed to the car is taken from car service
        List<String> userIds = List.of("1","2");

        webSocketService.notifySubscribedUser(userIds,carMessage);
    }


}
