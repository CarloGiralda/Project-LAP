INSERT INTO chats(
	id, receiver, sender)
	VALUES (1, 'bordin.2081387@studenti.uniroma1.it', 'giralda.1903088@studenti.uniroma1.it'),
           (2, 'gabriele.lerani2000@gmail.com', 'bordin.2081387@studenti.uniroma1.it'),
           (3, 'giralda.1903088@studenti.uniroma1.it', 'gabriele.lerani2000@gmail.com');
INSERT INTO messages(
	type, id, content, receiver, sender, session_id)
	VALUES (0, 1, 'where do we meet?', 'bordin.2081387@studenti.uniroma1.it', 'giralda._@studenti.uniroma1.it', ''),
           (0, 2, 'at my house', 'giralda.1903088@studenti.uniroma1.it',  'bordin.2081387@studenti.uniroma1.it', ''),
           (0, 3, 'be punctual!', 'gabriele.lerani2000@gmail.com',  'bordin.2081387@studenti.uniroma1.it', ''),
           (0, 4, 'yes sir!', 'bordin.2081387@studenti.uniroma1.it', 'gabriele.lerani2000@gmail.com', ''),
           (0, 5, 'I cannot find the place we talked about', 'giralda.1903088@studenti.uniroma1.it', 'gabriele.lerani2000@gmail.com', ''),
           (0, 6, 'send me your cellphone number, I wil call you', 'gabriele.lerani2000@gmail.com',  'giralda.1903088@studenti.uniroma1.it', '');