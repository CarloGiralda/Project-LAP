INSERT INTO offer(
	available, from_date, oid, to_date, price_per_hour, renter_username, zone_location)
	VALUES (true, '', 1, '', '15', 'bordin.2081387@studenti.uniroma1.it', ''),
	VALUES (true, '', 2, '', '20', 'gabriele.lerani2000@gmail.com', ''),
	VALUES (true, '', 3, '', '30', 'giralda.1903088@studenti.uniroma1.it', ''),
	VALUES (true, '', 4, '', '15', 'bordin.2081387@studenti.uniroma1.it', ''),
    VALUES (true, '', 5, '', '13', 'gabriele.lerani2000@gmail.com', ''),
    VALUES (true, '', 6, '', '12', 'giralda.1903088@studenti.uniroma1.it', '');
INSERT INTO utilities(
	air_conditioning, assistant, bluetooth, cd_player, cruise_control, display, navigation_system, parking_assistant, parking_camera, radioamfm, start_and_stop, surround_audio, usb_ports, utid, description)
	VALUES (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'a good car to drive'),
	VALUES (1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 'good to drive in the countryside'),
	VALUES (1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, '4x4'),
	VALUES (1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 'beautiful small car'),
	VALUES (0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 'good for transport'),
	VALUES (0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 'good for families');
INSERT INTO car(
	classification, engine, fuel, pollution_level, transmission, car_door_number, cid, offer_oid, passengers, utilities_utid, year, brand, model, plate_num, image)
	VALUES (0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 'renault', 'clio', 'AAAAAA', ''),
	VALUES (0,  0, 0, 0, 0, 0, 2, 2, 0, 2, 0, 'bmw', 'x3', 'BBBBBB', ''),
	VALUES (0,  0, 0, 0, 0, 0, 3, 3, 0, 3, 0, 'fiat', 'jeep', 'CCCCCC', ''),
	VALUES (0,  0, 0, 0, 0, 0, 4, 4, 0, 4, 0, 'smart', 'fortwo', 'DDDDDD', ''),
	VALUES (0,  0, 0, 0, 0, 0, 5, 5, 0, 5, 0, 'fiat', 'multipla', 'EEEEEE', ''),
	VALUES (0, 0, 0, 0, 0, 0, 6, 6, 0, 6, 0, 'toyota', 'yaris', 'FFFFFF', '');
