INSERT INTO offer(
	available, from_date, oid, to_date, price_per_hour, renter_username, zone_location)
	VALUES (true, '1706745600000', 1, '1709251140000', '15', 'bordin.2081387@studenti.uniroma1.it', '41.898380/12.481499'),
	 (true, '1707091200000', 2, '1707091200000', '20', 'gabriele.lerani2000@gmail.com', '41.842691/12.585193'),
	 (false, '1704067200000', 3, '1706659200000', '30', 'giralda.1903088@studenti.uniroma1.it', '45.464158/9.191775'),
	 (false, '1704412800000', 4, '1705363140000', '15', 'bordin.2081387@studenti.uniroma1.it', '45.061912/7.678392'),
    	 (true, '1704240000000', 5, '1709510340000', '13', 'gabriele.lerani2000@gmail.com', '39/9'),
    	 (false, '1709251200000', 6, '1711065540000', '12', 'giralda.1903088@studenti.uniroma1.it', '40.001764/15.993605');
INSERT INTO utilities(
	air_conditioning, assistant, bluetooth, cd_player, cruise_control, display, navigation_system, parking_assistant, parking_camera, radioamfm, start_and_stop, surround_audio, usb_ports, utid, description)
	VALUES (true, 0, true, false, true, true, true, true, true, true, true, true, true, 1, 'a good car to drive'),
	 (true, 0, true, false, true, true, true, true, true, true, true, true, true, 2, 'good to drive in the countryside'),
	 (false, 0, true, false, true, true, true, true, true, true, true, true, true, 3, '4x4'),
	 (true, 0, true, false, true, true, true, true, true, true, true, true, true, 4, 'beautiful small car'),
	(false, 0, true, false, true, false, true, false, true, false, true, false, true, 5, 'good for transport'),
	(true, 0, true, false, true, true, true, true, true, true, true, true, true, 6, 'good for families');
INSERT INTO car(
	classification, engine, fuel, pollution_level, transmission, car_door_number, cid, offer_oid, passengers, utilities_utid, year, brand, model, plate_num, image)
	VALUES (0, 0, 0, 4, 1, 5, 1, 1, 5, 1, 2021, 'renault', 'clio', 'AAAAAA', ''),
	(4, 2, 2, 3, 0, 4, 2, 2, 5, 2, 2020, 'bmw', 'x3', 'BBBBBB', ''),
	 (4, 2, 2, 3, 1, 5, 3, 3, 7, 3, 2018, 'jeep', 'renegade', 'CCCCCC', ''),
	 (0, 0, 0, 4, 1, 2, 4, 4, 2, 4, 2019, 'smart', 'fortwo', 'DDDDDD', ''),
	 (3, 1, 3, 0, 0, 5, 5, 5, 7, 5, 2012, 'fiat', 'multipla', 'EEEEEE', ''),
	 (0, 3, 0, 2, 0, 3, 6, 6, 4, 6, 2020, 'toyota', 'yaris', 'FFFFFF', '');
