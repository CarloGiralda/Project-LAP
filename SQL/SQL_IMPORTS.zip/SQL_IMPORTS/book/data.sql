INSERT INTO bookings(
	bid, cid, description, from_day, from_hour, made_date, to_day, to_hour, username)
	VALUES (1, 1, '', '', '', '', '', '', 'giralda.1903088@studenti.uniroma1.it'),
	VALUES (2, 2, '', '', '', '', '', '', 'bordin.2081387@studenti.uniroma1.it'),
	VALUES (3, 3, '', '', '', '', '', '', 'gabriele.lerani2000@gmail.com'),
	VALUES (4, 4, '', '', '', '', '', '', 'giralda.1903088@studenti.uniroma1.it'),
	VALUES (5, 5, '', '', '', '', '', '', 'bordin.2081387@studenti.uniroma1.it'),
	VALUES (6, 6, '','', '', '', '', '', 'gabriele.lerani2000@gmail.com');
INSERT INTO carsubscription(
	car_id, id, user_id)
	VALUES (1, 1, 'giralda.1903088@studenti.uniroma1.it'),
	VALUES (2, 2, 'bordin.2081387@studenti.uniroma1.it'),
	VALUES (3, 3, 'gabriele.lerani2000@gmail.com');