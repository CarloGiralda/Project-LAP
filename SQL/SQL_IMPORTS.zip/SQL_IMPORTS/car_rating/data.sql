INSERT INTO car_rating(
	date, crid, made_by_user, rating_on_car, stars, description)
	VALUES ('', 'bordin.2081387@studenti.uniroma1.it', 'gabriele.lerani2000@gmail.com', 1, 3, 'nothing special'),
	VALUES ('', 'bordin.2081387@studenti.uniroma1.it', 'giralda.1903088@studenti.uniroma1.it', 1, 4, 'a good experience'),
	VALUES ('', 'gabriele.lerani2000@gmail.com',  'bordin.2081387@studenti.uniroma1.it', 2, 5, 'very very good'),
	VALUES ('', 'gabriele.lerani2000@gmail.com', 'giralda.1903088@studenti.uniroma1.it', 2, 2, 'the car was disgustingly dirty'),
	VALUES ('', 'giralda.1903088@studenti.uniroma1.it', 'gabriele.lerani2000@gmail.com', 3, 2, 'the renter was too rude'),
	VALUES ('', 'giralda.1903088@studenti.uniroma1.it', 'bordin.2081387@studenti.uniroma1.it', 3, 5, 'very good car');