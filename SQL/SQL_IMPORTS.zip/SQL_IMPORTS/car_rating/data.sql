INSERT INTO car_rating(
	date, crid, made_by_user, rating_on_car, stars, description)
	VALUES ('2024-02-02', 1, 2, 1, 3, 'nothing special'),
	 ('2024-02-03', 2, 3, 1, 4, 'a good experience'),
	 ('2024-01-06', 3, 1, 2, 5, 'very very good'),
	 ('2024-01-10', 4, 3, 2, 2, 'the car was disgustingly dirty'),
	 ('2024-01-04', 5, 2, 3, 2, 'the renter was too rude'),
	 ('2024-01-03', 6, 1, 3, 5, 'very good car'),
	 ('2024-01-10', 7, 2, 4, 5, 'very good car');
