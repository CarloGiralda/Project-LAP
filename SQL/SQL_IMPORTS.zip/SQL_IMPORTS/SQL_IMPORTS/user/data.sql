INSERT INTO users(
	enabled, locked, id, app_user_role, contact, email, first_name, last_name, password, residence)
	VALUES (true, false, 1, 'USER', '321321321', 'bordin.2081387@studenti.uniroma1.it', 'Gianmarco', 'Bordin', 'password', 'roma');
INSERT INTO users(
    	enabled, locked, id, app_user_role, contact, email, first_name, last_name, password, residence)
    	VALUES (true, false, 2, 'USER', '321321323', 'gabriele.lerani2000@gmail.com', 'Gabriele', 'Lerani', 'password', 'firenze');
INSERT INTO users(
        	enabled, locked, id, app_user_role, contact, email, first_name, last_name, password, residence)
        	VALUES (true, false, 3, 'USER', '321321329', 'giralda.1903088@studenti.uniroma1.it', 'Carlo', 'Giralda', 'password', 'milano');