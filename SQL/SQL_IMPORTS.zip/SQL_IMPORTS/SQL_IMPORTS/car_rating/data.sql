INSERT INTO car_rating(
	date, crid, made_by_user, rating_on_car, stars, description)
	VALUES ('2024-02-02', 1, 'gabriele.lerani2000@gmail.com', 1, 3, 'nothing special'),
	VALUES ('2024-02-03', 2, 'giralda.1903088@studenti.uniroma1.it', 1, 4, 'a good experience'),
	VALUES ('2024-01-06', 3, 'bordin.2081387@studenti.uniroma1.it', 2, 5, 'very very good'),
	VALUES ('2024-01-10', 4, 'giralda.1903088@studenti.uniroma1.it', 2, 2, 'the car was disgustingly dirty'),
	VALUES ('2024-01-04', 5, 'gabriele.lerani2000@gmail.com', 3, 2, 'the renter was too rude'),
	VALUES ('2024-01-03', 6, 'bordin.2081387@studenti.uniroma1.it', 3, 5, 'very good car');
	VALUES ('2024-01-10', 7, 'gabriele.lerani2000@gmail.com', 4, 5, 'very good car');
