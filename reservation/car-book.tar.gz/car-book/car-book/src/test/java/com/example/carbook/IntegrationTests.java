package com.example.carbook;




import com.example.carbook.model.booking.Booking;
import com.example.carbook.model.booking.Request;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;

import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest(classes = com.example.carbook.CarBookApplication.class)
@AutoConfigureMockMvc
class IntegrationTests {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper objectMapper;



    @Test
    public void listBookedCar() throws Exception {
        Request request=new Request("1","12/12/2023","12/12/2023","12/12/2023","12-00","12-00","user","","");
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:9005/reservation/listBookings")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)).accept(MediaType.APPLICATION_JSON);
       mvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();}

    @Test
    void modifyOffer() throws Exception {

        String cid="1";
        String price="30";
        // when(offerService.setOffer(any(Offer.class)));
        MvcResult result = mvc.perform(get("http://localhost:9005/reservation/modifyOffer").queryParam("cid",cid).queryParam("price",price)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();
    }

    @Test
    void showOffer() throws Exception {
        String cid="1";
        MvcResult result = mvc.perform(get("http://localhost:9005/reservation/showOffer").queryParam("cid",cid)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();
    }



    @Test
    void extendBook() throws Exception {
        String cid="1";
        String to="30/12/2023";
        String user="user";
        MvcResult result = mvc.perform(get("http://localhost:9005/reservation/extendBooking").queryParam("user",user).queryParam("cid",cid).queryParam("to",to)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();
    }

    @Test
    void bookCar() throws Exception {
        Request request=new Request("1","12/12/2023","12/12/2023","12/12/2023","12-00","12-00","user","","");
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:9005/reservation/book")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)).accept(MediaType.APPLICATION_JSON);
        mvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
    }

    @Test
    void showOfferCar() throws Exception {
        String cid="1";
        String to="30/12/2023";
        String user="user";
        Booking b=new Booking();
        ArrayList<Booking> a=new ArrayList<>();
        a.add(b);
        MvcResult result = mvc.perform(get("http://localhost:9005/reservation/showOfferCar").queryParam("cid",cid)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();
    }
}





