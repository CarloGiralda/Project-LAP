package com.example.carbook.model.offer;


import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "offers")
public class Offer {
    @Id
    @SequenceGenerator(name = "offers_gen", sequenceName = "offers_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "offers_gen")
    private Long oid;
    private Long cid;
    private String pricePerHour;
}
