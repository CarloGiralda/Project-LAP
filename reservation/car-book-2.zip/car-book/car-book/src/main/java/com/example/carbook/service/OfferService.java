package com.example.carbook.service;


import com.example.carbook.model.offer.Offer;
import com.example.carbook.model.offer.OfferRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Objects;


@Service
@AllArgsConstructor
public class OfferService {

    private final OfferRepository offerRepository;
    public void setOffer(Offer offer){
        offerRepository.save(offer);}
    public Offer getOffer(String flag, String param){
        if(Objects.equals(flag,"cid")){
            return offerRepository.findByCid(Long.parseLong(param));}
        else{
            return offerRepository.findByOid(Long.parseLong(param));
        }
    }


}
