package com.example.carbook;

import com.example.carbook.model.booking.*;
import com.example.carbook.service.BookingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;

import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.*;


import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest(classes = com.example.carbook.CarBookApplication.class)
@AutoConfigureMockMvc
class RestControllerTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private BookingService bookingService;


    @Test
    public void listBookedCar() throws Exception {

        BookingPreview bookingPreview = new BookingPreview();
        bookingPreview.setBid(1L);
        bookingPreview.setCid(1L);
        bookingPreview.setFromDay("10-02-2023");
        bookingPreview.setToDay("12-02-2023");
        bookingPreview.setToHour("10:00");
        bookingPreview.setMadeDate("09-02-2023");

        ArrayList<BookingPreview> bookingPreviews = new ArrayList<>();

        bookingPreviews.add(bookingPreview);

        String username = "test";

        // MOCK test returns booking list
        when(bookingService.getBookingPreview(username)).thenReturn(bookingPreviews);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("http://localhost:9005/reservation/listBookingsPreview")
                .header("Logged-In-User",username);

        mvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();


    }


    @Test
    public void testExtendBooking() throws Exception {
        // Mocked data
        ExtendBookingRequest request = new ExtendBookingRequest(1L,1L,"12-12-2023","10:20");
        String username = "testuser";

        Map<String,Object> body = new HashMap<>();
        body.put("bid",1L);
        body.put("cid",1L);
        body.put("toDay","12-12-2023");
        body.put("toHour","10:20");

        // Mocking service method behavior
        doNothing().when(bookingService).extendBooking(request);

        // Perform the MockMvc request
        mvc.perform(MockMvcRequestBuilders.post("/reservation/extendBooking")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body))
                        .accept(MediaType.APPLICATION_JSON)
                        .header("Logged-In-User", username))
                .andExpect(status().isOk()).andReturn();


    }

    @Test
    void bookCar() throws Exception {


        Request request = new Request(
                "1",
                "12-12-2023",
                "12-13-2023",
                "10-12-2023",
                "10:00",
                "10:00",
                "user",
                "",
                "");


        Booking booking = new Booking(
                1L,
                "12-12-2023",
                "12-13-2023",
                "10-12-2023",
                "10:00",
                "10:00",
                "user",
                ""
        );

        doNothing().when(bookingService).setBooking(booking);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:9005/reservation/book")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
                .accept(MediaType.APPLICATION_JSON)
                .header("Logged-In-User", "user");
        mvc.perform(requestBuilder).andExpect(status().isCreated()).andReturn();
    }


}





