package com.example.carbook;



import com.example.carbook.controller.BookController;
import com.example.carbook.model.booking.Booking;
import com.example.carbook.model.booking.Request;
import com.example.carbook.service.BookingService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.ArrayList;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(BookController.class)
@ContextConfiguration("/test-context.xml")
class UnitTests {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private  ObjectMapper objectMapper;
    @MockBean
    private  BookingService bookingService;


    @BeforeEach
    void setUp(WebApplicationContext wac) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    void modifyOffer() throws Exception {
        String cid="1";
        String price="30";
        MvcResult result = mockMvc.perform(get("http://localhost:9005/reservation/modifyOffer").queryParam("cid",cid).queryParam("price",price)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();}



    @Test
    void extendBook() throws Exception {
        String cid="1";
        String to="30/12/2023";
        String user="user";
        Booking b=new Booking();
        ArrayList<Booking> a=new ArrayList<>();
        a.add(b);
        when(bookingService.getBooking(anyString(),anyString(),anyString())).thenReturn(a);
        MvcResult result = mockMvc.perform(get("http://localhost:9005/reservation/extendBooking").queryParam("user",user).queryParam("cid",cid).queryParam("to",to)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();
    }

    @Test
    void showOfferCar() throws Exception {
        String cid="1";
        Booking b=new Booking();
        ArrayList<Booking> a=new ArrayList<>();
        a.add(b);
        when(bookingService.getBooking(anyString(),anyString(),anyString())).thenReturn(a);
        MvcResult result = mockMvc.perform(get("http://localhost:9005/reservation/showOfferCar").queryParam("cid",cid)
                        .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andReturn();
    }


    @Test
    void listBookedCar() throws Exception {
        Request request=new Request("1","12/12/2023","12/12/2023","12/12/2023","12-00","12-00","user","","");
        ArrayList<Booking> a=new ArrayList<>();
        when(bookingService.getBooking(anyString(),anyString(),anyString())).thenReturn(a);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:9005/reservation/listBookings")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)).accept(MediaType.APPLICATION_JSON);
        mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();

    }


    @Test
    void bookCar() throws Exception {
        Request request=new Request("1","12/12/2023","12/12/2023","12/12/2023","12-00","12-00","user","","");
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:9005/reservation/book")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)).accept(MediaType.APPLICATION_JSON);
        mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();

    }

}
