package com.example.carbook.service;

import com.example.carbook.model.carSubscription.CarSubRepository;
import com.example.carbook.model.carSubscription.CarSubscription;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Slf4j
@AllArgsConstructor
@Service
public class CarSubService {

    private CarSubRepository carSubRepository;

    public void subscribeUser(CarSubscription carSubscription) throws Exception {
        try {
            carSubRepository.save(carSubscription);
        } catch (DataIntegrityViolationException e){
            log.info("constraints exception");
            throw new Exception("user already subscribed");
        }

    }

    public ArrayList<String> getSubscribedUser(String carId){
        Long id = Long.parseLong(carId);
        return carSubRepository.findUserIdByCarId(id);

    }

}
