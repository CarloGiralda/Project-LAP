package com.example.carbook.model.carSubscription;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.ArrayList;

public interface CarSubRepository extends JpaRepository<CarSubscription, Integer> {


    @Query("SELECT c.userId from CarSubscription c WHERE c.carId = ?1")
    ArrayList<String> findUserIdByCarId(Long carId);
}
