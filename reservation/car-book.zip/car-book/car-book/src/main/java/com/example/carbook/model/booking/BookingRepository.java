package com.example.carbook.model.booking;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.ArrayList;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Integer> {


    ArrayList<Booking>findByUsername(String username);
    ArrayList<Booking>findByCid(Long cid);
    ArrayList<Booking>findByUsernameAndCid(String username, Long Cid);
    ArrayList<Booking>findByUsernameAndMadeDate(String username, String madeDate);
    ArrayList<Booking>findByUsernameAndFromDay(String username, String from);
    ArrayList<Booking>findByUsernameAndToDay(String username, String to);


}