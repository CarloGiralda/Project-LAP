package com.example.carbook.service;


import com.example.carbook.config.MQConfig;
import com.example.carbook.model.booking.Booking;
import com.example.carbook.model.booking.BookingPreview;
import com.example.carbook.model.booking.BookingRepository;
import com.example.carbook.model.booking.SimplifiedBooking;
import com.example.carbook.model.carSubscription.CarSubscription;
import com.example.carbook.model.carSubscription.CarSubscriptionMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


@Service
@Slf4j
public class BookingService {

    private final BookingRepository bookingRepository;

    private final HashMap<Long, SimplifiedBooking> bookingMap;

    @Autowired
    private RabbitTemplate template;

    @Autowired
    private Queue queue;

    private final RestTemplate restTemplate;

    @Value("${app.subscription-service-url}")
    private String subscriptionServiceUrl;

    public BookingService(BookingRepository bookingRepository, RestTemplate restTemplate) {
        this.bookingRepository = bookingRepository;
        this.restTemplate = restTemplate;
        this.bookingMap = new HashMap<>();
    }


    /**
     * Store booking in DB and HashMap and check whether some of the stored bookings
     * is expired, if yes it notify the notification service to notify all subscribed user
     * the car is now available**/
    public void setBooking(Booking booking) throws Exception {

        try {
            // Store booking on DB
            Booking savedBooking = bookingRepository.save(booking);

            // Store only necessary field
            SimplifiedBooking simplifiedBooking = new SimplifiedBooking(savedBooking.getCid(), savedBooking.getToDay(), savedBooking.getToHour());

            // Store the booking in the hashmap
            bookingMap.put(savedBooking.getBid(),simplifiedBooking);
        } catch (DataIntegrityViolationException e){
            log.info("constraints exception");
            throw new Exception("booking already exists");

        }


    }

    public ArrayList<Booking> getBooking(String username, String flag, String param){
        System.out.println(flag+param+username);
        return switch (flag) {
            case "username" -> bookingRepository.findByUsername(username);
            case "username&from" -> bookingRepository.findByUsernameAndFromDay(username, param);
            case "username&madeDate" -> bookingRepository.findByUsernameAndToDay(username, param);
            case "username&to" -> bookingRepository.findByUsernameAndMadeDate(username, param);
            case "cid" -> bookingRepository.findByCid(Long.parseLong(param));
            default -> bookingRepository.findByUsernameAndCid(username, Long.parseLong(param));
        };
    }

    public void modifyBooking(Booking booking){
        bookingRepository.save(booking);
    }

    @Scheduled(fixedDelay = 10000)
    public void checkSubscribedUser(){

        if (!bookingMap.isEmpty()){
            for(Map.Entry<Long, SimplifiedBooking> set: bookingMap.entrySet()){

                if (expired(set.getValue().getToDay(),set.getValue().getToHour())){
                    log.info("reservation with id {} has expired", set.getKey());

                    // remove from hashmap the booking because now is expired
                    bookingMap.remove(set.getKey());

                    // 1) get the ids of the subscribed user for a car
                    String subscriptionUrl = subscriptionServiceUrl + "/subscription/getSubscribedUser/{carId}";
                    ResponseEntity<String[]> response = restTemplate.getForEntity(subscriptionUrl, String[].class, set.getValue().getCid());
                    if (response.getStatusCode().is2xxSuccessful()) {
                        String[] subscriptions = response.getBody();

                        assert subscriptions != null;

                        for(String user: subscriptions){
                            log.info("user {} subscribed to car {}" ,user, set.getValue().getCid());
                        }

                        // 2) send this message to the queue
                        CarSubscriptionMessage carSubscriptionMessage = new CarSubscriptionMessage(set.getValue().getCid(),subscriptions);
                        template.convertAndSend(queue.getName(), carSubscriptionMessage);
                    }



                }

            }
        }
        else {
            log.info("no booking is stored");
        }

    }



    private static boolean expired(String day, String hour){
        // Parse date and time strings
        LocalDate toDate = LocalDate.parse(day, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        LocalTime toTimeOfDay = LocalTime.parse(hour, DateTimeFormatter.ofPattern("HH:mm"));

        // Create LocalDateTime by combining date and time
        LocalDateTime toDateTime = LocalDateTime.of(toDate, toTimeOfDay);

        // Get current date and time
        LocalDateTime currentDateTime = LocalDateTime.now();

        log.info("comparing {} with {}", toDateTime, currentDateTime);
        int dateComparison = currentDateTime.toLocalDate().compareTo(toDateTime.toLocalDate());
        return dateComparison > 0;
    }

    public ArrayList<BookingPreview> getBookingPreview(String username) {
        ArrayList<Booking> bookings = bookingRepository.findByUsername(username);
        ArrayList<BookingPreview> bookingPreviews = new ArrayList<>();
        for (Booking booking: bookings) {
            bookingPreviews.add(new BookingPreview(
                    booking.getBid(),
                    booking.getCid(),
                    booking.getFromDay(),
                    booking.getToDay(),
                    booking.getMadeDate())
            );
        }

        return bookingPreviews;
    }


}

