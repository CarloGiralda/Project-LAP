package com.example.carbook.exception;

public class CarSubscriptionException extends RuntimeException {

    public CarSubscriptionException(String message) {
        super(message);
    }
}
