package com.example.carbook.controller;


import com.example.carbook.model.carSubscription.CarSubscription;
import com.example.carbook.service.CarSubService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@Slf4j
@AllArgsConstructor
@RequestMapping(path = "/subscription")
@RestController
public class CarSubController {

    private CarSubService carSubService;

    @PostMapping(path = "/car/{carId}")
    @ResponseBody
    public ResponseEntity<?> subscribeUser(@RequestHeader("Logged-In-User") String username, @PathVariable String carId) throws Exception {
        // TODO verify integrity constraints with other microservices
        try {
            CarSubscription carSubscription = new CarSubscription(username, Long.parseLong(carId));

            carSubService.subscribeUser(carSubscription);
            return new ResponseEntity<>("user subscribed",HttpStatus.OK);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }



    }

    @GetMapping(path = "getSubscribedUser/{carId}")
    public ResponseEntity<?> getSubscribedUser(@PathVariable String carId) {
        // TODO handle some exception
        try {
            ArrayList<String> subscriptions = carSubService.getSubscribedUser(carId);
            // TODO returns only the list of subscribed users
            if(!subscriptions.isEmpty()) {
                return new ResponseEntity<>(subscriptions, HttpStatus.OK);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("cannot find user subscribed for car " + carId);
            }

        } catch (Exception e){
            log.info(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("internal error");
        }
    }
}
