document.getElementById('reservationForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Here you can add logic for form submission and checking if something went wrong
        submitFormInSequence();

});



    function showSuccessMessage() {
        document.getElementById('reservationForm').style.display = 'none';
        const successMessage = document.getElementById('successMessage');
        successMessage.textContent = "Reservation completed";
        successMessage.style.color = 'green';
    }

    function showErrorMessage() {
        const successMessage = document.getElementById('errorMessage');
        successMessage.textContent = "Reservation not completed";
        successMessage.style.color = 'red';
    }
async function submitFormInSequence() {
       const cid = document.getElementById('cid').value;
       const username = document.getElementById('username').value;
       const fromDate = document.getElementById('fromDate').value;
       const toDate = document.getElementById('toDate').value;
       const fromH = document.getElementById('fromH').value;
       const toH = document.getElementById('toH').value;
       const desc = document.getElementById('description').value;
       const today = new Date();
       const yyyy = today.getFullYear();
       let mm = today.getMonth() + 1; // Months start at 0!
       let dd = today.getDate();

       if (dd < 10) dd = '0' + dd;
       if (mm < 10) mm = '0' + mm;

       const formattedToday = dd + '-' + mm + '-' + yyyy;


       const madeDate = formattedToday;

       const successUrl="start.html";

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Specify the request type (GET or POST), URL, and whether it should be asynchronous
    xhr.open("POST", "http://localhost:9005/reservation/book", true);

    // Set the request header to indicate that we are sending JSON
    xhr.setRequestHeader("Content-Type", "application/json");

    // Define the JSON data to be sent
    const jsonData = {
      cid: cid,
      madeDate: madeDate,
      from: fromDate,
      to: toDate,
      fromH: fromH,
      toH: toH,
      username: username,
      flag: madeDate,
      desc: desc
      // Add more key-value pairs as needed
    };console.log(jsonData);

    // Convert the JSON data to a string
    const jsonDataString = JSON.stringify(jsonData);
    console.log(jsonDataString);

    // Set up a callback function to handle the response
    xhr.onreadystatechange = function () {
      // Check if the request is complete (readyState 4) and if the status is OK (status 200)
      if (xhr.readyState === 4 && xhr.status === 200) {
        // Parse the response JSON
                setTimeout(function() {
                               window.location.href = "start.html"; // Change this to the desired page
                           }, 3000);
                           window.location.href = successUrl;

        // Verify the result or do something with the response
        console.log("Response:", response);
      }else{
      showErrorMessage();
      }
    };

    // Send the JSON data as the request payload
    xhr.send(jsonDataString);

}