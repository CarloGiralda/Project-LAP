document.getElementById('myForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Here you can add logic for form submission and checking if something went wrong
        const response= submitFormInSequence();


});


    async function submitFormInSequence() {
          const username = document.getElementById('username').value;
          const flag = document.getElementById('flag').value;
          const filter = document.getElementById('filter').value;


          const successUrl="bookings.html";

       // Create a new XMLHttpRequest object
       var xhr = new XMLHttpRequest();

       // Specify the request type (GET or POST), URL, and whether it should be asynchronous
       xhr.open("POST", "http://localhost:9005/reservation/listBookings", true);

       // Set the request header to indicate that we are sending JSON
       xhr.setRequestHeader("Content-Type", "application/json");

       // Define the JSON data to be sent
       const jsonData = {
         cid: filter,
         madeDate: filter,
         from: filter,
         to: filter,
         fromH: filter,
         toH: filter,
         username: filter,
         flag: flag,
         desc: filter
         // Add more key-value pairs as needed
       };console.log(jsonData);

       // Convert the JSON data to a string
       const jsonDataString = JSON.stringify(jsonData);
       console.log(jsonDataString);

       // Set up a callback function to handle the response
       xhr.onreadystatechange = function () {
         // Check if the request is complete (readyState 4) and if the status is OK (status 200)
         if (xhr.readyState === 4 && xhr.status === 200) {
           // Parse the response JSON
           const body=xhr.responseText;
           //TODO json parse
           for (let x = 0; x < body.length; x++) {
                  console.log(body[x].length);
                  sessionStorage.setItem("NumberOfObjectsPerList", body[x].length)
                  for (let y = 0; y < body[x].length; y++) {
                      console.log(body[x][y]);
                      sessionStorage.setItem("Number: " + x + " / Field: " + y, body[x][y]);

                  }
                              }
          // window.location=successUrl;
         }
       };

       // Send the JSON data as the request payload
       xhr.send(jsonDataString);

    }


