function addMoreRows() {
    var rowsAdded = sessionStorage.getItem("NumberOfObjectsPerList");//TODO json parse

    for(var x= 0; x < rowsAdded; x++) {
        var newRow = document.getElementById("table").insertRow();

        var newCell = newRow.insertCell();
        // Get only from the cars list (first list), number of object equal to x,
        // and then select the field
        var br = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: Offer Id")
        newCell.innerHTML="<tr><td>" + br + "</td></tr>";

        newCell = newRow.insertCell();
        var mod = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: Car Id")
        newCell.innerHTML="<tr><td>" + mod + "</td></tr>";

        newCell = newRow.insertCell();
        var engine = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: Made Date")
        newCell.innerHTML="<tr><td>" + engine + "</td></tr>";

        newCell = newRow.insertCell();
        var transmission = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: From Date")
        newCell.innerHTML="<tr><td>" + transmission + "</td></tr>";

        newCell = newRow.insertCell();
        var transmission = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: To Date")
        newCell.innerHTML="<tr><td>" + transmission + "</td></tr>";

        newCell = newRow.insertCell();
        var transmission = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: From Time")
        newCell.innerHTML="<tr><td>" + transmission + "</td></tr>";

        newCell = newRow.insertCell();
        var transmission = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: To Time")
        newCell.innerHTML="<tr><td>" + transmission + "</td></tr>";

        newCell = newRow.insertCell();
        var transmission = sessionStorage.getItem("List: " + 0 + " / Number: " + x + " / Field: Description")
        newCell.innerHTML="<tr><td>" + transmission + "</td></tr>";

        newCell = newRow.insertCell();
        newCell.innerHTML= "<a href=\"http://localhost:9005/extend\"><button>Extend Reservation period</button></a>";
    }



}
window.onload=addMoreRows();