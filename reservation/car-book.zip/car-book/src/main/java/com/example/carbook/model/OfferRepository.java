package com.example.carbook.model;


import org.springframework.data.jpa.repository.JpaRepository;

import java.util.ArrayList;
import java.util.Optional;

public interface OfferRepository extends JpaRepository<Offer, Integer> {
    Offer findByOid(Long oid);
    Offer findByCid(Long cid);
}
