package com.example.carbook.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Request {
    private String cid;
    private String madeDate;
    private String from;
    private String to;
    private String fromH;
    private String toH;
    private String username;
    private String flag;
    private String desc;

}
