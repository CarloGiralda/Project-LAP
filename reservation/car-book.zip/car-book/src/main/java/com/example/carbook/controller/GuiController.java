package com.example.carbook.controller;


import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;



@AllArgsConstructor
@Controller
public class GuiController {
    @RequestMapping(path = "/")
    public String start(){
            return "start.html";
    }
    @RequestMapping(path = "/book")
    public String reservation(){
        return "reservationForm.html";
    }
    @RequestMapping(path = "/extend")
    public String extendReservation(){
        return "extend.html";
    }
}
