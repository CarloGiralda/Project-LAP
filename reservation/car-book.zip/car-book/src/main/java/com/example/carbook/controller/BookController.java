package com.example.carbook.controller;

import com.example.carbook.model.Booking;
import com.example.carbook.model.Offer;
import com.example.carbook.model.Request;
import com.example.carbook.service.BookingService;
import com.example.carbook.service.OfferService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@AllArgsConstructor
@RequestMapping(path = "/reservation")
@RestController
public class BookController {

    private final BookingService bookingService;
    private final OfferService offerService;
    @PostMapping(path = "/book")
    @ResponseBody
    public ResponseEntity<String> bookCar(@RequestBody Request request, @RequestHeader("Logged-In-User") String username){
        try {
            Long cid=Long.parseLong(request.getCid());
            Booking booking =new Booking();
            booking.setCid(cid);
            booking.setFrom(request.getFrom());
            booking.setTo(request.getTo());
            booking.setFrom_H(request.getFromH());
            System.out.println(request.getToH());
            booking.setTo_H(request.getToH());
            booking.setMadeDate(request.getMadeDate());
            booking.setUsername(request.getUsername());
            booking.setDesc(request.getDesc());
            bookingService.setBooking(booking);
            return ResponseEntity.status(HttpStatus.OK).body("Request completed");
        } catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }
    }

    @PostMapping(path = "/listBookings")
    @ResponseBody
    public ResponseEntity<?> listBookedCar(@RequestBody Request request, @RequestHeader("Logged-In-User") String username) {
        try {
            String param;
            switch (request.getFlag()){
                case "username" -> param= "";
                case "username&from" -> param= request.getFrom();
                case "username&madeDate" -> param= request.getMadeDate();
                case "username&to" -> param= request.getTo();
                default -> param= request.getCid();
            }
            ArrayList<Booking> ret= bookingService.getBooking(request.getUsername(),request.getFlag(),param);
            if(!ret.isEmpty()) {
                return new ResponseEntity<>(ret, HttpStatus.OK);
            }else{
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
            }
        } catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }
    }

    @GetMapping(path = "/extendBooking")
    @ResponseBody
    public ResponseEntity<String> extendBook(@RequestParam("user") String username,@RequestParam("cid") String cid,@RequestParam("to") String to, @RequestHeader("Logged-In-User") String user){
        try {
            ArrayList<Booking> b=bookingService.getBooking(username,"username&cid",cid);
            Booking b1 ;
            if(!b.isEmpty()) {
                b1 = b.get(0);
                b1.setTo(to);
                bookingService.setBooking(b1);
                return ResponseEntity.status(HttpStatus.OK).body("Request completed");
            }else {
                return ResponseEntity.status(HttpStatus.OK).body("There is no booking with the current specifications");
            }
        } catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @GetMapping(path = "/showOffer")
    @ResponseBody
    public ResponseEntity<?> showOffer(@RequestParam("cid") String cid, @RequestHeader("Logged-In-User") String username){
        try {
            return new ResponseEntity<>(offerService.getOffer("cid",cid),HttpStatus.OK);
        } catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }
    }

    @GetMapping(path = "/showOfferCar")
    @ResponseBody
    public ResponseEntity<?> showOfferCar(@RequestParam("cid") String cid, @RequestHeader("Logged-In-User") String username){
        try {
            ArrayList<Booking> ret=bookingService.getBooking("%%","cid",cid);

            if(ret.isEmpty()){
                return new ResponseEntity<>("available",HttpStatus.OK);
            }
            return new ResponseEntity<>(ret.get(0).getTo(),HttpStatus.OK);
        } catch (Exception e){
            System.out.println(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }
    }


    @GetMapping(path = "/modifyOffer")
    @ResponseBody
    public ResponseEntity<String> modifyOffer(@RequestParam("cid") String cid,@RequestParam("price") String price, @RequestHeader("Logged-In-User") String username){
        try {

            Offer offer=new Offer();
            offer.setCid(Long.parseLong(cid));
            offer.setPricePerHour(price);
            offerService.setOffer(offer);
            return ResponseEntity.status(HttpStatus.OK).body("Request completed");
        } catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }
    }

}
