package com.example.carbook.model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "bookings")
public class Booking {
    @Id
    @SequenceGenerator(name = "bookings_gen", sequenceName = "bookings_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bookings_gen")
    private Long bid;
    private Long cid;
    private String madeDate;
    private String username;
    private String from;
    private String to;
    private String from_H;
    private String to_H;
    private String desc;
}
