package com.example.carbook.service;


import com.example.carbook.model.Booking;
import com.example.carbook.model.BookingRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.ArrayList;


@Service
@AllArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    public void setBooking(Booking booking){
        bookingRepository.save(booking);}
    public ArrayList<Booking> getBooking(String username, String flag, String param){
        return switch (flag) {
            case "username" -> bookingRepository.findByUsername(username);
            case "username&from" -> bookingRepository.findByUsernameAndFrom(username, param);
            case "username&madeDate" -> bookingRepository.findByUsernameAndTo(username, param);
            case "username&to" -> bookingRepository.findByUsernameAndMadeDate(username, param);
            case "cid" -> bookingRepository.findByCid(Long.parseLong(param));
            default -> bookingRepository.findByUsernameAndCid(username, Long.parseLong(param));
        };
    }

    public void modifyBooking(Booking booking){
        bookingRepository.save(booking);
    }
}

