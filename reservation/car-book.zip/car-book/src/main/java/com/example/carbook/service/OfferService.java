package com.example.carbook.service;


import com.example.carbook.model.Booking;
import com.example.carbook.model.BookingRepository;
import com.example.carbook.model.Offer;
import com.example.carbook.model.OfferRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Optional;


@Service
@AllArgsConstructor
public class OfferService {

    private final OfferRepository offerRepository;
    public void setOffer(Offer offer){
        offerRepository.save(offer);}
    public Offer getOffer(String flag, String param){
        if(Objects.equals(flag,"cid")){
            return offerRepository.findByCid(Long.parseLong(param));}
        else{
            return offerRepository.findByOid(Long.parseLong(param));
        }
    }


}
