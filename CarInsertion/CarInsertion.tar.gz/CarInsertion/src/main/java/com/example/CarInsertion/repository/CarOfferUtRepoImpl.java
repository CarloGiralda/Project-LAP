package com.example.CarInsertion.repository;

import com.example.CarInsertion.model.Car;
import com.example.CarInsertion.model.InsertionDTO;
import com.example.CarInsertion.model.Offer;
import com.example.CarInsertion.model.Utilities;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.criteria.*;

import java.util.List;

public class CarOfferUtRepoImpl implements CarOfferUtRepo {
    @PersistenceContext
    EntityManager em;

    @Override
    public List<InsertionDTO> getCarOfferUtFromUsername(String username) {
        CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<InsertionDTO> criteriaQuery = criteriaBuilder.createQuery(InsertionDTO.class);
        Root<Offer> offerRoot = criteriaQuery.from(Offer.class);
        Join<Offer, Car> offerOfCar = offerRoot.join("car_cid");
        Join<Offer, Utilities> utOfCar = offerRoot.join("utilities_utid");

        Predicate predicateForEquality = criteriaBuilder.equal(offerRoot.get("renterUsername"), username);

        criteriaQuery.multiselect(offerRoot, offerOfCar, utOfCar).where(predicateForEquality);
        Query query = em.createQuery(criteriaQuery);

        return query.getResultList();
    }
}
