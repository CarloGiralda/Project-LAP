package com.example.CarInsertion.service;

import com.example.CarInsertion.model.InsertionDTO;

public interface InsertionService {
    public InsertionDTO insert(InsertionDTO dto);
}
