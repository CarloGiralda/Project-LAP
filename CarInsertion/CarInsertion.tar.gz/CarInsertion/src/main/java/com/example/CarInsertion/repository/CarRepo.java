package com.example.CarInsertion.repository;

import com.example.CarInsertion.model.Car;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CarRepo extends JpaRepository<Car,Long> {
    @Modifying
    @Query("UPDATE Car c SET c.plateNum = :plateNum, c.year = :year, c.pollutionLevel = :pl, c.fuel = :fuel," +
            "c.brand = :brand, c.passengers = :pass, c.model = :model, c.insurance = :ins," +
            "c.classification = :classification, c.carDoorNumber = :cdn, c.engine = :engine, c.transmission = :trans WHERE c.cid = :cid")
    int updateCarBy(@Param(value = "cid") Long cid, @Param(value = "plateNum") String plateNum,
                    @Param(value = "year") Long year, @Param(value = "pl") Car.PollutionLevel pl,
                    @Param(value = "fuel") Car.Fuel fuel, @Param(value = "brand") String brand,
                    @Param(value = "pass") Long pass, @Param(value = "model") String model,
                    @Param(value = "ins") String ins, @Param(value = "classification") Car.Classification classification,
                    @Param(value = "cdn") Long cdn, @Param(value = "engine") Car.Engine engine, @Param(value = "trans") Car.Transmission trans);
}
