package com.example.CarInsertion.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "utilities")
public class Utilities {
    public enum Assistant {
        Android,
        Apple
    }

    @Id
    @SequenceGenerator(name = "ut_gen", sequenceName = "ut_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ut_gen")
    private Long utid;
    private Boolean display;
    private Assistant assistant;
    private Boolean airConditioning;
    private Boolean startAndStop;
    private Boolean navigationSystem;
    private Boolean parkingAssistant;
    private Boolean bluetooth;
    private Boolean usbPorts;
    private Boolean cdPlayer;
    private Boolean radioAMFM;
    private Boolean cruiseControl;
    private Boolean parkingCamera;
    private Boolean surroundAudio;
    private String description;

    public Utilities() {
    }

    public Utilities(Assistant assistant, Boolean airConditioning, Boolean startAndStop, Boolean display, Boolean navigationSystem,
                     Boolean parkingAssistant, Boolean bluetooth, Boolean USBPorts, Boolean CDPlayer, Boolean radioAMFM, Boolean cruiseControl,
                     Boolean parkingCamera, Boolean surroundAudio, String description) {
        this.assistant = assistant;
        this.airConditioning = airConditioning;
        this.startAndStop = startAndStop;
        this.display = display;
        this.navigationSystem = navigationSystem;
        this.parkingAssistant = parkingAssistant;
        this.bluetooth = bluetooth;
        this.usbPorts = USBPorts;
        this.cdPlayer = CDPlayer;
        this.radioAMFM = radioAMFM;
        this.cruiseControl = cruiseControl;
        this.parkingCamera = parkingCamera;
        this.surroundAudio = surroundAudio;
        this.description = description;
    }

    public boolean hasEmptyFields() {
        return getAssistant() == null || getAirConditioning() == null || getStartAndStop() == null || getDisplay() == null ||
                getNavigationSystem() == null || getParkingAssistant() == null || getBluetooth() == null || getUsbPorts() == null ||
                getCdPlayer() == null || getRadioAMFM() == null || getCruiseControl() == null || getParkingCamera() == null ||
                getSurroundAudio() == null;
    }
}
