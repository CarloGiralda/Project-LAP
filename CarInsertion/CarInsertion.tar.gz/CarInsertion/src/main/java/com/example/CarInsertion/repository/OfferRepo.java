package com.example.CarInsertion.repository;

import com.example.CarInsertion.model.Car;
import com.example.CarInsertion.model.Offer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface OfferRepo extends JpaRepository<Offer,Long> {
    @Modifying
    @Query("UPDATE Offer o SET o.available = :av, o.fromDate = :from, o.toDate = :to, o.pricePerHour = :pph, o.renterUsername = :renter, o.zoneLocation = :zone " +
            "WHERE o.oid = :oid")
    int updateOfferBy(@Param(value = "oid") Long oid, @Param(value = "av") Boolean av,
                      @Param(value = "from") Long from, @Param(value = "to") Long to,
                      @Param(value = "pph") String pph, @Param(value = "renter") String renter, @Param(value = "zone") String zone);
}
