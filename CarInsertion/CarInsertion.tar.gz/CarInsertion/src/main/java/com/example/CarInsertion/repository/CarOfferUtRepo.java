package com.example.CarInsertion.repository;

import com.example.CarInsertion.model.InsertionDTO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CarOfferUtRepo {
    List<InsertionDTO> getCarOfferUtFromUsername(String username);
}
