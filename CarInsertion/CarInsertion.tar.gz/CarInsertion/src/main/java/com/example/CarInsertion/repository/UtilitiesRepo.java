package com.example.CarInsertion.repository;

import com.example.CarInsertion.model.Utilities;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface UtilitiesRepo extends JpaRepository<Utilities,Long> {
    @Modifying
    @Query("UPDATE Utilities ut SET ut.airConditioning = :ac, ut.assistant = :ass, ut.bluetooth = :bt," +
            "ut.cdPlayer = :cd, ut.cruiseControl = :cc, ut.display = :dis, ut.navigationSystem = :nav," +
            "ut.parkingAssistant = :pa, ut.parkingCamera = :pc, ut.radioAMFM = :radio, ut.startAndStop = :sas," +
            "ut.surroundAudio = :sa, ut.usbPorts = :usb, ut.description = :desc WHERE ut.utid = :utid")
    int updateUtilitiesBy(@Param(value = "utid") Long utid, @Param(value = "ac") Boolean ac,
                          @Param(value = "ass") Utilities.Assistant ass, @Param(value = "bt") Boolean bt,
                          @Param(value = "cd") Boolean cd, @Param(value = "cc") Boolean cc,
                          @Param(value = "dis") Boolean dis, @Param(value = "nav") Boolean nav,
                          @Param(value = "pa") Boolean pa, @Param(value = "pc") Boolean pc,
                          @Param(value = "radio") Boolean radio, @Param(value = "sas") Boolean sas,
                          @Param(value = "sa") Boolean sa, @Param(value = "usb") Boolean usb,
                          @Param(value = "desc") String desc);
}
