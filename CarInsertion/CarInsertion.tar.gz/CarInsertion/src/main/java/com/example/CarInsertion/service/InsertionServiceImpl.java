package com.example.CarInsertion.service;

import com.example.CarInsertion.model.Car;
import com.example.CarInsertion.model.InsertionDTO;
import com.example.CarInsertion.model.Offer;
import com.example.CarInsertion.model.Utilities;
import com.example.CarInsertion.repository.CarOfferUtRepo;
import com.example.CarInsertion.repository.CarRepo;
import com.example.CarInsertion.repository.OfferRepo;
import com.example.CarInsertion.repository.UtilitiesRepo;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InsertionServiceImpl implements InsertionService{
    private final CarRepo carRepo;
    private final OfferRepo offerRepo;
    private final UtilitiesRepo utilitiesRepo;
    private final CarOfferUtRepo carOfferUtRepo;

    public InsertionServiceImpl(CarRepo carRepo, OfferRepo offerRepo, UtilitiesRepo utilitiesRepo, CarOfferUtRepo carOfferUtRepo) {
        this.carRepo = carRepo;
        this.offerRepo = offerRepo;
        this.utilitiesRepo = utilitiesRepo;
        this.carOfferUtRepo = carOfferUtRepo;
    }

    @Override
    public InsertionDTO insert(InsertionDTO dto) {
        Offer offer = dto.getOffer();
        Utilities ut = dto.getUtilities();
        Car car = dto.getCar();
        Offer resultOffer = offerRepo.save(offer);
        Utilities resultUt = utilitiesRepo.save(ut);
        car.setOffer_oid(resultOffer);
        car.setOptionals_utid(resultUt);
        Car resultCar = carRepo.save(dto.getCar());
        return new InsertionDTO(resultCar, resultOffer, resultUt);
    }

    @Override
    public int update(InsertionDTO dto) {
        Offer offer = dto.getOffer();
        Utilities ut = dto.getUtilities();
        Car car = dto.getCar();
        int cars = carRepo.updateCarBy(car.getCid(), car.getPlateNum(), car.getYear(), car.getPollutionLevel(),
                car.getFuel(), car.getBrand(), car.getPassengers(), car.getModel(), car.getInsurance(),
                car.getClassification(), car.getCarDoorNumber(), car.getEngine(), car.getTransmission());
        int offers = offerRepo.updateOfferBy(offer.getOid(), offer.getAvailable(), offer.getFromDate(), offer.getToDate(),
                offer.getPricePerHour(), offer.getRenterUsername(), offer.getZoneLocation());
        int uts = utilitiesRepo.updateUtilitiesBy(ut.getUtid(), ut.getAirConditioning(), ut.getAssistant(), ut.getBluetooth(),
                ut.getCdPlayer(), ut.getCruiseControl(), ut.getDisplay(), ut.getNavigationSystem(), ut.getParkingAssistant(),
                ut.getParkingCamera(), ut.getRadioAMFM(), ut.getStartAndStop(), ut.getSurroundAudio(), ut.getUsbPorts(),
                ut.getDescription());
        if (cars == 0 && offers == 0 && uts == 0) {
            return 0;
        }
        return 1;
    }

    @Override
    public List<InsertionDTO> retrieveCars(String username) {
        return carOfferUtRepo.getCarOfferUtFromUsername(username);
    }
}
