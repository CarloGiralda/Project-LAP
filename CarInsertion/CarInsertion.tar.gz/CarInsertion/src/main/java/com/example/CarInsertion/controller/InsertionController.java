package com.example.CarInsertion.controller;

import com.example.CarInsertion.model.Car;
import com.example.CarInsertion.model.InsertionDTO;
import com.example.CarInsertion.model.Offer;
import com.example.CarInsertion.model.Utilities;
import com.example.CarInsertion.service.InsertionService;
import jakarta.ws.rs.GET;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping(path = "/carinsert")
@RestController
public class InsertionController {
    private InsertionService insertionService;
    private InsertionDTO dto;

    public InsertionController(InsertionService insertionService) {
        super();
        this.dto = new InsertionDTO();
        this.insertionService = insertionService;
    }

    @PostMapping(path = "/insertoffer")
    public ResponseEntity<String> saveOfferForm(@RequestBody Offer offer, @RequestHeader("Logged-In-User") String username) {
        if (offer.hasEmptyFields()) {
            return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
        }
        this.dto.setOffer(offer);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping(path = "/insertcar")
    public ResponseEntity<String> saveCarForm(@RequestBody Car car, @RequestHeader("Logged-In-User") String username) {
        if (car.hasEmptyFields()) {
            return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
        }
        this.dto.setCar(car);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping(path = "/insertutilities")
    public ResponseEntity<String> saveUtilitiesForm(@RequestBody Utilities ut, @RequestHeader("Logged-In-User") String username) {
        if (ut.hasEmptyFields()) {
            return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
        }
        this.dto.setUtilities(ut);
        insertionService.insert(this.dto);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping(path = "/listcars")
    public ResponseEntity<?> retrieveCarsByUsername(@RequestBody String user, @RequestHeader("Logged-In-User") String username) {
        List<InsertionDTO> cars = insertionService.retrieveCars(user);
        return new ResponseEntity<>(cars, HttpStatus.OK);
    }

    @PostMapping(path = "/modify")
    public ResponseEntity<String> saveModification(@RequestBody InsertionDTO dto, @RequestHeader("Logged-In-User") String username) {
        insertionService.update(dto);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
