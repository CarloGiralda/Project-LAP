package com.example.CarInsertion.controller;

import com.example.CarInsertion.model.Car;
import com.example.CarInsertion.model.InsertionDTO;
import com.example.CarInsertion.model.Offer;
import com.example.CarInsertion.model.Utilities;
import com.example.CarInsertion.service.InsertionService;
import jakarta.ws.rs.GET;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
public class InsertionController {
    private InsertionService insertionService;
    private InsertionDTO dto;

    public InsertionController(InsertionService insertionService) {
        super();
        this.insertionService = insertionService;
    }

    @GetMapping(path = "/insertoffer")
    public ResponseEntity<String> getOfferForm() {
        dto = new InsertionDTO();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping(path = "/insertcar")
    public ResponseEntity<String> getCarForm(@RequestBody Offer offer) {
        if (offer != null) {
            dto.setOffer(offer);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
    }

    @PostMapping(path = "/insertutilities")
    public ResponseEntity<String> getUtilitiesForm(@RequestBody Car car) {
        if (car != null) {
            dto.setCar(car);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
    }

    @PostMapping(path = "/success")
    public ResponseEntity<String> success(@RequestBody Utilities ut) {
        if (ut != null) {
            dto.setUtilities(ut);
            insertionService.insert(dto);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
    }
}
