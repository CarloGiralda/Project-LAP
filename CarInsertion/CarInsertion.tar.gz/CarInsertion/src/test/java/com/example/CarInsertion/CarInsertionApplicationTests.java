package com.example.CarInsertion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarInsertionApplicationTests {

	@Test
	void contextLoads() {
	}

}
