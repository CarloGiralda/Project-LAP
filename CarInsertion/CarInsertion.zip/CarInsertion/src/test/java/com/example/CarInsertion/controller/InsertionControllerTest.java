package com.example.CarInsertion.controller;

import com.example.CarInsertion.model.Car;
import com.example.CarInsertion.model.InsertionDTO;
import com.example.CarInsertion.model.Offer;
import com.example.CarInsertion.model.Utilities;
import com.example.CarInsertion.service.InsertionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;

import static org.mockito.Mockito.when;

@WebMvcTest(controllers = InsertionController.class)
public class InsertionControllerTest {
    @MockBean
    private InsertionService insertionService;
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void shouldStoreOffer() throws Exception {
        // create an offer object to pass it to the page
        Offer offer = new Offer(1602288000L, 1602288000L, "10.5", "test@gmail.com", "Roma");

        // convert it into an object that is accepted by subsequent operations
        ObjectMapper omof = new ObjectMapper();
        omof.findAndRegisterModules();
        String offerAsString = omof.writeValueAsString(offer);

        // test if the controller works fine if an input object is provided
        mockMvc.perform(MockMvcRequestBuilders.post("/carinsert/insertoffer")
                        .header("Logged-In-User", "test@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(offerAsString))
                .andExpect(MockMvcResultMatchers.status().is(200));

        // create a malformed offer object to pass it to the page
        Offer malformedOffer = new Offer();
        malformedOffer.setFromDate(1602288000L);
        malformedOffer.setToDate(1602288000L);

        // convert it into an object that is accepted by subsequent operations
        String malformedOfferAsString = omof.writeValueAsString(malformedOffer);

        // test if the controller works fine if a malformed object is provided
        mockMvc.perform(MockMvcRequestBuilders.post("/carinsert/insertoffer")
                        .header("Logged-In-User", "test@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(malformedOfferAsString))
                .andExpect(MockMvcResultMatchers.status().is(412));
    }

    @Test
    public void shouldStoreCar() throws Exception {
        // create a car object to pass it to the page
        Car car = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", "nothing", Car.Classification.CityCar, 4L, Car.Engine.Electric, Car.Transmission.Automatic);

        // convert it into an object that is accepted by subsequent operations
        ObjectMapper omcar = new ObjectMapper();
        omcar.findAndRegisterModules();
        String carAsString = omcar.writeValueAsString(car);

        // test if the controller works fine if an input object is provided
        mockMvc.perform(MockMvcRequestBuilders.post("/carinsert/insertcar")
                        .header("Logged-In-User", "test@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(carAsString))
                .andExpect(MockMvcResultMatchers.status().is(200));

        // create an malformed car object to pass it to the page
        Car malformedCar = new Car();
        malformedCar.setPlateNum("PK543WQ");
        malformedCar.setPassengers(4L);
        malformedCar.setYear(2002L);

        // convert it into an object that is accepted by subsequent operations
        String malformedCarAsString = omcar.writeValueAsString(malformedCar);

        // test if the controller works fine if a malformed object is provided
        mockMvc.perform(MockMvcRequestBuilders.post("/carinsert/insertcar")
                        .header("Logged-In-User", "test@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(malformedCarAsString))
                .andExpect(MockMvcResultMatchers.status().is(412));
    }

    @Test
    public void shouldStoreUtilitiesAndSaveAll() throws Exception {
        Offer offer = new Offer(1602288000L, 1602288000L, "10.5", "test@gmail.com", "Roma");
        Car car = new Car("PK543WQ", 2002L, Car.PollutionLevel.EURO4, Car.Fuel.Methane, "Tesla", 4L,
                "S", "nothing", Car.Classification.CityCar, 4L, Car.Engine.Electric, Car.Transmission.Automatic);
        // create a utilities object to pass it to the page
        Utilities ut = new Utilities(Utilities.Assistant.Android, true, true, true, false,
                true, true, true, true, false, true, true,
                true, "BELLA");

        InsertionDTO expectedResponse = new InsertionDTO(car, offer, ut);

        // convert it into an object that is accepted by subsequent operations
        ObjectMapper omut = new ObjectMapper();
        omut.findAndRegisterModules();
        String utAsString = omut.writeValueAsString(ut);

        when(insertionService.insert(ArgumentMatchers.any(InsertionDTO.class))).thenReturn(expectedResponse);

        // test if the controller works fine if an input object is provided
        mockMvc.perform(MockMvcRequestBuilders.post("/carinsert/insertutilities")
                        .header("Logged-In-User", "test@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(utAsString))
                .andExpect(MockMvcResultMatchers.status().is(200));

        // create a malformed utilities object to pass it to the page
        Utilities malformedUt = new Utilities();
        malformedUt.setAirConditioning(true);
        malformedUt.setCdPlayer(true);

        // convert it into an object that is accepted by subsequent operations
        String malformedUtAsString = omut.writeValueAsString(malformedUt);

        // test if the controller works fine if a malformed object is provided
        mockMvc.perform(MockMvcRequestBuilders.post("/carinsert/insertutilities")
                        .header("Logged-In-User", "test@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(malformedUtAsString))
                .andExpect(MockMvcResultMatchers.status().is(412));
    }
}
