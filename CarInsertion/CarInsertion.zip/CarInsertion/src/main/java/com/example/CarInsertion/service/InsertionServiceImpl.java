package com.example.CarInsertion.service;

import com.example.CarInsertion.model.Car;
import com.example.CarInsertion.model.InsertionDTO;
import com.example.CarInsertion.model.Offer;
import com.example.CarInsertion.model.Utilities;
import com.example.CarInsertion.repository.CarOfferUtRepo;
import com.example.CarInsertion.repository.CarRepo;
import com.example.CarInsertion.repository.OfferRepo;
import com.example.CarInsertion.repository.UtilitiesRepo;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InsertionServiceImpl implements InsertionService{
    private final CarRepo carRepo;
    private final OfferRepo offerRepo;
    private final UtilitiesRepo utilitiesRepo;
    private final CarOfferUtRepo carOfferUtRepo;

    public InsertionServiceImpl(CarRepo carRepo, OfferRepo offerRepo, UtilitiesRepo utilitiesRepo, CarOfferUtRepo carOfferUtRepo) {
        this.carRepo = carRepo;
        this.offerRepo = offerRepo;
        this.utilitiesRepo = utilitiesRepo;
        this.carOfferUtRepo = carOfferUtRepo;
    }

    @Override
    public InsertionDTO insert(InsertionDTO dto) {
        Offer offer = dto.getOffer();
        Utilities ut = dto.getUtilities();
        Car car = dto.getCar();
        Offer resultOffer = offerRepo.save(offer);
        Utilities resultUt = utilitiesRepo.save(ut);
        car.setOffer_oid(resultOffer);
        car.setUtilities_utid(resultUt);
        Car resultCar = carRepo.save(dto.getCar());
        return new InsertionDTO(resultCar, resultOffer, resultUt);
    }

    @Override
    @Transactional
    public int update(InsertionDTO dto) {
        Offer offer = dto.getOffer();
        Utilities ut = dto.getUtilities();
        Car car = dto.getCar();
        Long offerid = carRepo.findOfferOid(car.getCid()).getOid();
        Long utid = carRepo.findUtilitiesUtid(car.getCid()).getUtid();
        offer.setOid(offerid);
        ut.setUtid(utid);
        int carRes = carOfferUtRepo.updateCar(car);
        int offerRes = carOfferUtRepo.updateOffer(offer);
        int utRes = carOfferUtRepo.updateUtilities(ut);

        if (carRes == 1 && offerRes == 1 && utRes == 1) {
            return 1;
        }
        return 0;
    }

    @Override
    public List<InsertionDTO> retrieveCars(String username) {
        return carOfferUtRepo.getCarOfferUtFromUsername(username);
    }
}
