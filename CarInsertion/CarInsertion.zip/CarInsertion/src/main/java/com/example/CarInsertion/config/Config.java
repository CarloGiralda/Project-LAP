package com.example.CarInsertion.config;

import com.example.CarInsertion.repository.CarOfferUtRepo;
import com.example.CarInsertion.repository.CarOfferUtRepoImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
    @Bean
    public CarOfferUtRepo insertRepo() {
        return new CarOfferUtRepoImpl();
    }
}
