package com.example.CarInsertion.init;

import com.example.CarInsertion.model.Car;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class DataInitJson {
    private List<Car> cars;
    /*private List<Offer> offers;
    private List<Utilities> utilities;*/
}
