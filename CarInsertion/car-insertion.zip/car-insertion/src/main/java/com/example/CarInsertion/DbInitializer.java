package com.example.CarInsertion;

import com.example.CarInsertion.model.Car;
import com.example.CarInsertion.model.InsertionDTO;
import com.example.CarInsertion.model.Offer;
import com.example.CarInsertion.model.Utilities;
import com.example.CarInsertion.repository.OfferRepo;
import com.example.CarInsertion.repository.UtilitiesRepo;
import lombok.AllArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.example.CarInsertion.repository.CarRepo;

import java.io.IOException;
import java.io.InputStream;

@Component
@AllArgsConstructor
public class DbInitializer implements CommandLineRunner {

    private final CarRepo carRepository;
    private final OfferRepo offerRepository;
    private final UtilitiesRepo utilitiesRepository;

    @Override
    public void run(String... args) throws Exception {


        Utilities utilities1 = getUtilities();
        Offer offer = getOffer();
        Car car = getCar(offer, utilities1);

        offerRepository.save(offer);
        utilitiesRepository.save(utilities1);
        carRepository.save(car);

    }

    private static Car getCar(Offer offer, Utilities utilities1) throws IOException {
        Car car = new Car();
        car.setClassification(Car.Classification.values()[0]); // CityCar
        car.setEngine(Car.Engine.values()[0]); // Electric
        car.setFuel(Car.Fuel.values()[0]); // Gas
        car.setPollutionLevel(Car.PollutionLevel.values()[4]); // EURO6
        car.setTransmission(Car.Transmission.values()[1]); // Automatic
        car.setCarDoorNumber(5L);
        car.setCid(1L);
        car.setOffer_oid(offer);
        car.setPassengers(5L);
        car.setUtilities_utid(utilities1);
        car.setYear(2021L);
        car.setBrand("Renault");
        car.setModel("Clio");
        car.setPlateNum("AAAAAA");
        byte[] imageData = CarImageLoader.loadImageFromFile("static/img/renault-clio.jpg");

        car.setImage(imageData);

        return car;
    }

    private static Utilities getUtilities() {
        Utilities utilities1 = new Utilities();
        utilities1.setAirConditioning(true);
        utilities1.setAndroid(true);
        utilities1.setApple(true);
        utilities1.setBluetooth(true);
        utilities1.setCdPlayer(false);
        utilities1.setCruiseControl(true);
        utilities1.setDisplay(true);
        utilities1.setNavigationSystem(true);
        utilities1.setParkingAssistant(true);
        utilities1.setParkingCamera(true);
        utilities1.setRadioAMFM(true);
        utilities1.setStartAndStop(true);
        utilities1.setSurroundAudio(true);
        utilities1.setUsbPorts(true);
        utilities1.setUtid(1L);
        utilities1.setDescription("a good car to drive");
        return utilities1;
    }

    private static Offer getOffer(){
        Offer offer = new Offer();
        offer.setAvailable(true);
        offer.setFromDate(1706745600000L);
        offer.setToDate(1709251140000L);
        offer.setPricePerHour("15");
        offer.setRenterUsername("bordin.2081387@studenti.uniroma1.it");
        offer.setZoneLocation("41.898380/12.481499");
        return offer;
    }



}
